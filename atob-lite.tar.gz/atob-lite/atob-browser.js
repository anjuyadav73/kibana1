module.exports = function _atob(str) {
  return atob(str)
}
