/*
 * Export `addContext` function
 *
 */
module.exports = require('./src/addContext');
