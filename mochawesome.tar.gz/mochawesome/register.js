/**
 * Export `register` hook
 * @example
 * $ mocha --require mochawesome/register tests
 *
 */
module.exports = require('./src/register');
