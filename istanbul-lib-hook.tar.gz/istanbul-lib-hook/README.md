# istanbul-lib-hook

[![Greenkeeper badge](https://badges.greenkeeper.io/istanbuljs/istanbul-lib-hook.svg)](https://greenkeeper.io/)
[![Build Status](https://travis-ci.org/istanbuljs/istanbul-lib-hook.svg?branch=master)](https://travis-ci.org/istanbuljs/istanbul-lib-hook)

Hooks for require, vm and script used in istanbul
