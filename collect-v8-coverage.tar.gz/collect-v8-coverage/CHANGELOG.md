# 1.0.0 (2019-12-16)

### Features

- initial commit ([57e2041](https://github.com/SimenB/collect-v8-coverage/commit/57e20413f385d7730c5684b1852c14777583807e))
