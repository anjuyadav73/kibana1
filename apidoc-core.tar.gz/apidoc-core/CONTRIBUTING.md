# Contributing to apidoc-core

* Target the `dev` branch for your PR
* Add a test if possible
* Use `npm test`
