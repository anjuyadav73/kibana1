# apidoc-core

Core parser library to generate apidoc result following the [apidoc-spec](https://github.com/apidoc/apidoc-spec).

![Build Status](https://github.com/apidoc/apidoc-core/workflows/validate/badge.svg)
[![Dependency Status](https://david-dm.org/apidoc/apidoc-core.svg)](https://david-dm.org/apidoc/apidoc-core)
[![NPM version](https://badge.fury.io/js/apidoc-core.svg)](http://badge.fury.io/js/apidoc-core)

If you are an end user, please proceed to [apidoc](https://github.com/apidoc/apidoc) or [apidoc-documentation](http://apidocjs.com).
