A smaller version of @cspotcode/source-map which includes only the consumer, not the generator.

**NOTE**: the type declarations are incorrect.  They include declarations for things from @cspotcode/source-map
which are omitted from this package.

This is a delibrate, pragmatic choice.  The declarations for things which *are* included -- the consumer -- should
be correct.
