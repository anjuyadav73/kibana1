'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('ExecutionEnvironment');
module.exports = require('./index.js').ExecutionEnvironment;
