'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('createMemoryHistory');
module.exports = require('./index.js').createMemoryHistory;
