// This file is currently only a placeholder to allow TypeScript packages to import the
// interface types that are declared in index.d.ts for the "interfaces" submodule.
