const FileDataSource = require('./file_data_source');
const TestData = require('./test_data');

module.exports = {
  FileDataSource,
  TestData,
};
