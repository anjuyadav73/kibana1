/// <reference types="node" />
import * as http from 'http';
import { DiagnosticResult } from './types';
export declare class ElasticsearchClientError extends Error {
    constructor(message: string);
}
export declare class TimeoutError extends ElasticsearchClientError {
    meta?: DiagnosticResult;
    constructor(message: string, meta?: DiagnosticResult);
}
export declare class ConnectionError extends ElasticsearchClientError {
    meta?: DiagnosticResult;
    constructor(message: string, meta?: DiagnosticResult);
}
export declare class NoLivingConnectionsError extends ElasticsearchClientError {
    meta: DiagnosticResult;
    constructor(message: string, meta: DiagnosticResult);
}
export declare class SerializationError extends ElasticsearchClientError {
    data: Record<string, any>;
    constructor(message: string, data: Record<string, any>);
}
export declare class DeserializationError extends ElasticsearchClientError {
    data: string;
    constructor(message: string, data: string);
}
export declare class ConfigurationError extends ElasticsearchClientError {
    constructor(message: string);
}
export declare class ResponseError extends ElasticsearchClientError {
    meta: DiagnosticResult;
    constructor(meta: DiagnosticResult);
    get body(): any | undefined;
    get statusCode(): number | undefined;
    get headers(): http.IncomingHttpHeaders | undefined;
}
export declare class RequestAbortedError extends ElasticsearchClientError {
    meta?: DiagnosticResult;
    constructor(message: string, meta?: DiagnosticResult);
}
export declare class ProductNotSupportedError extends ElasticsearchClientError {
    meta?: DiagnosticResult;
    constructor(product: string, meta?: DiagnosticResult);
}
