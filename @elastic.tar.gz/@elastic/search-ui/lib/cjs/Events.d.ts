import { onAutocompleteHook, onAutocompleteResultClickHook, onResultClickHook, onSearchHook } from "./SearchDriver";
import { APIConnector, AutocompleteQueryConfig, QueryConfig, SearchQuery, AutocompleteSearchQuery, ResponseState, AutocompleteResponseState } from "./types";
declare type EventOptions = {
    apiConnector?: APIConnector;
    onSearch?: onSearchHook;
    onAutocomplete?: onAutocompleteHook;
    onResultClick?: onResultClickHook;
    onAutocompleteResultClick?: onAutocompleteResultClickHook;
};
declare class Events {
    search: (query: SearchQuery, queryConfig: QueryConfig) => Promise<ResponseState>;
    autocomplete: (query: AutocompleteSearchQuery, queryConfig: AutocompleteQueryConfig) => Promise<AutocompleteResponseState>;
    resultClick: (resultParams: any) => void;
    autocompleteResultClick: (resultParams: any) => void;
    constructor({ apiConnector, onSearch, onAutocomplete, onResultClick, onAutocompleteResultClick }?: EventOptions);
}
export default Events;
