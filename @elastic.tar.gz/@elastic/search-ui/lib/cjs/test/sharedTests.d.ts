export function itResetsCurrent(fn: any): void;
export function itResetsFilters(fn: any): void;
export function itFetchesResults(fn: any): void;
export function itUpdatesURLState(MockedURLManager: any, fn: any): void;
