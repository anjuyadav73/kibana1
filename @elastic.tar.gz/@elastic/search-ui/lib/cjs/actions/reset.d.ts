/**
 * Reset search experience to initial state
 *
 */
export default function reset(): void;
