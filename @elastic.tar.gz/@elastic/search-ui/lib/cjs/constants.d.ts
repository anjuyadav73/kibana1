export declare const INVALID_CREDENTIALS = "Invalid credentials";
