declare const _default: {
    encode(value: any, encode: any): string;
    decode(value: any, decode: any): any;
};
export default _default;
