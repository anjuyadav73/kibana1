/// <reference types="react" />
import { FacetViewProps } from "./types";
declare function SingleLinksFacet({ className, label, onRemove, onSelect, options }: FacetViewProps): JSX.Element;
export default SingleLinksFacet;
