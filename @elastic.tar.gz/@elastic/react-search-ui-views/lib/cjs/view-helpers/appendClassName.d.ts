export default function appendClassName(baseClassName?: string | string[] | undefined, newClassName?: string | string[] | undefined): string;
