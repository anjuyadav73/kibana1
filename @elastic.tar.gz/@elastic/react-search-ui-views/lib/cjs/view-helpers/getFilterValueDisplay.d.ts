export default function getFilterValueDisplay(filterValue: any): string;
