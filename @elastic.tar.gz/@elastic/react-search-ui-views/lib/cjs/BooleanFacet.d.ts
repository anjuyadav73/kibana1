/// <reference types="react" />
import { FacetViewProps } from "./types";
declare function BooleanFacet({ className, label, options, onChange, onRemove, values }: FacetViewProps): JSX.Element;
export default BooleanFacet;
