/// <reference types="react" />
import { FacetViewProps } from "./types";
declare function SingleSelectFacet({ className, label, onChange, options }: FacetViewProps): JSX.Element;
export default SingleSelectFacet;
