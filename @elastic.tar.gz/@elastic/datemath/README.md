# datemath

Datemath string parser used in Kibana. This is published to NPM for use in a limited number of locations outside of Kibana, but is not regularly updated and may get seriously out of date.

If you file an issue in elastic/kibana we can probably update it for you if needed, though you probably shouldn't depend on this package for anything important.
