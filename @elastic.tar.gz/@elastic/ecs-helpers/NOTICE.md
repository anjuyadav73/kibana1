@elastic/ecs-helpers
Copyright 2019-2021 Elasticsearch B.V.
