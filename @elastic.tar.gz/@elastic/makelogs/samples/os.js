'use strict';

module.exports = [
  'osx',
  'ios',
  'win xp',
  'win 7',
  'win 8'
];
