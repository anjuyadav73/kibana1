module.exports = {
  trailingComma: "none",
  arrowParens: "avoid"
};
