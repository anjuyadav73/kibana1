'use strict'

var util = require('hast-util-raw')

module.exports = raw

function raw() {
  return util
}
