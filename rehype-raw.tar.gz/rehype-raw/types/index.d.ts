// TypeScript Version: 3.4

import {Plugin} from 'unified'

declare const rehypeRaw: Plugin<[]>

export = rehypeRaw
