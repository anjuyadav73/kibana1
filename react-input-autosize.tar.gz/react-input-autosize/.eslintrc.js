module.exports = {
	extends: 'keystone-react',
	parser: 'babel-eslint',
};
