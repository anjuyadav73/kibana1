/* eslint-disable import/named */
import { unstable_batchedUpdates } from 'react-native'

export { unstable_batchedUpdates }
