declare module 'multicast-dns' {
    function init(opts: any)
    export = init
}