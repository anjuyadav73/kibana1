# istanbul-lib-source-maps

[![Build Status](https://travis-ci.org/istanbuljs/istanbuljs.svg?branch=master)](https://travis-ci.org/istanbuljs/istanbuljs)

Source map support for istanbuljs.

## Debugging

_istanbul-lib-source-maps_ uses the [debug](https://www.npmjs.com/package/debug) module.
Run your application with the environment variable `DEBUG=istanbuljs`, to receive debug
output.
