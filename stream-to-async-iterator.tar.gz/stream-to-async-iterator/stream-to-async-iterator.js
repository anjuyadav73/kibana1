'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * @type {Object.<string, Symbol>}
 */
var states = exports.states = {
    notReadable: Symbol('not readable'),
    readable: Symbol('readable'),
    ended: Symbol('ended'),
    errored: Symbol('errored')
};

/**
 * @typedef {Object} StreamAsyncToIterator~Options
 * @property {number} [size] - the size of each read from the stream for each iteration
 */


/**
 * @typedef {Object} StreamAsyncToIterator~Iteration
 * @property {boolean} done
 * @property {*} value
 */

/**
 * Wraps a stream into an object that can be used as an async iterator.
 *
 * This will keep a stream in a paused state, and will only read from the stream on each
 * iteration. A size can be supplied to set an explicit call to `stream.read([size])` in
 * the options for each iteration.
 */
var StreamAsyncToIterator = function () {
    /**
     * @param {Readable} stream
     * @param {StreamAsyncToIterator~Options} [options]
     */
    function StreamAsyncToIterator(stream) {
        var _this = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

        _classCallCheck(this, StreamAsyncToIterator);

        /**
         * The underlying readable stream
         * @private
         * @type {Readable}
         */
        this._stream = stream;

        /**
         * Contains stream's error when stream has error'ed out
         * @private
         * @type {?Error}
         */
        this._error = null;

        /**
         * The current state of the iterator (not readable, readable, ended, errored)
         * @private
         * @type {Symbol}
         */
        this._state = states.notReadable;

        /**
         * @private
         * @type {?number}
         */
        this._size = options.size;

        /**
         * The rejections of promises to call when stream errors out
         * @private
         * @type {Set.<function(err: Error)>}
         */
        this._rejections = new Set();

        var handleStreamError = function handleStreamError(err) {
            _this._error = err;
            _this._state = states.errored;
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = _this._rejections[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var reject = _step.value;

                    reject(err);
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }
        };

        var handleStreamEnd = function handleStreamEnd() {
            _this._state = states.ended;
        };

        stream.once('error', handleStreamError);
        stream.once('end', handleStreamEnd);
    }

    _createClass(StreamAsyncToIterator, [{
        key: 'next',


        /**
         * Returns the next iteration of data. Rejects if the stream errored out.
         * @returns {Promise<StreamAsyncToIterator~Iteration>}
         */
        value: function () {
            var _ref = _asyncToGenerator(regeneratorRuntime.mark(function _callee() {
                var data;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                        switch (_context.prev = _context.next) {
                            case 0:
                                if (!(this._state === states.notReadable)) {
                                    _context.next = 6;
                                    break;
                                }

                                _context.next = 3;
                                return Promise.race([this._untilReadable(), this._untilEnd()]);

                            case 3:
                                return _context.abrupt('return', this.next());

                            case 6:
                                if (!(this._state === states.ended)) {
                                    _context.next = 10;
                                    break;
                                }

                                return _context.abrupt('return', { done: true, value: null });

                            case 10:
                                if (!(this._state === states.errored)) {
                                    _context.next = 14;
                                    break;
                                }

                                throw this._error;

                            case 14:
                                //stream.read returns null if not readable or when stream has ended

                                data = this._size ? this._stream.read(this._size) : this._stream.read();

                                if (!(data !== null)) {
                                    _context.next = 19;
                                    break;
                                }

                                return _context.abrupt('return', { done: false, value: data });

                            case 19:
                                //we're no longer readable, need to find out what state we're in
                                this._state = states.notReadable;
                                return _context.abrupt('return', this.next());

                            case 21:
                            case 'end':
                                return _context.stop();
                        }
                    }
                }, _callee, this);
            }));

            function next() {
                return _ref.apply(this, arguments);
            }

            return next;
        }()

        /**
         * Waits until the stream is readable. Rejects if the stream errored out.
         * @private
         * @returns {Promise}
         */

    }, {
        key: '_untilReadable',
        value: function _untilReadable() {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
                var handleReadable = function handleReadable() {
                    _this2._state = states.readable;
                    _this2._rejections.delete(reject);
                    resolve();
                };

                _this2._stream.once('readable', handleReadable);
                _this2._rejections.add(reject);
            });
        }

        /**
         * Waits until the stream is ended. Rejects if the stream errored out.
         * @private
         * @returns {Promise}
         */

    }, {
        key: '_untilEnd',
        value: function _untilEnd() {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
                var handleEnd = function handleEnd() {
                    _this3._state = states.ended;
                    _this3._rejections.delete(reject);
                    resolve();
                };
                _this3._stream.once('end', handleEnd);
                _this3._rejections.add(reject);
            });
        }
    }]);

    return StreamAsyncToIterator;
}();

exports.default = StreamAsyncToIterator;


Object.defineProperty(StreamAsyncToIterator.prototype, Symbol.asyncIterator, {
    configurable: true,
    value: function value() {
        return this;
    }
});

//# sourceMappingURL=stream-to-async-iterator.js.map