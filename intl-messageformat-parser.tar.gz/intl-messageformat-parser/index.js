'use strict';

exports = module.exports = require('./lib/parser')['default'];
exports['default'] = exports;
