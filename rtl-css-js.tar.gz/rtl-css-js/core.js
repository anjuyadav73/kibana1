/* eslint import/no-unresolved:0 */
// this file just makes it easier to require dist/core
module.exports = require('./dist/cjs/core.js')
