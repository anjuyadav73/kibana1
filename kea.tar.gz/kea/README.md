[![NPM Version](https://img.shields.io/npm/v/kea.svg)](https://www.npmjs.com/package/kea)
[![minified](https://badgen.net/bundlephobia/min/kea)](https://bundlephobia.com/result?p=kea)
[![minified + gzipped](https://badgen.net/bundlephobia/minzip/kea)](https://bundlephobia.com/result?p=kea)
[![Backers on Open Collective](https://opencollective.com/kea/backers/badge.svg)](#backers)
[![Sponsors on Open Collective](https://opencollective.com/kea/sponsors/badge.svg)](#sponsors)

![Kea Logo](https://kea.js.org/img/logo.svg)

# Kea v2

Open the [documentation](https://kea.js.org/) and read from there.

## Thank you to our backers!

<a href="https://opencollective.com/kea/sponsor/0/website" target="_blank"><img src="https://opencollective.com/kea/sponsor/0/avatar.svg"></a>
<a href="https://opencollective.com/kea/sponsor/1/website" target="_blank"><img src="https://opencollective.com/kea/sponsor/1/avatar.svg"></a>
<a href="https://opencollective.com/kea/sponsor/2/website" target="_blank"><img src="https://opencollective.com/kea/sponsor/2/avatar.svg"></a>
<a href="https://opencollective.com/kea#backers" target="_blank"><img src="https://opencollective.com/kea/backers.svg?width=890"></a>

## Contributors

This project exists thanks to all the people who contribute. [[Contribute]](CONTRIBUTING.md).
<a href="graphs/contributors"><img src="https://opencollective.com/kea/contributors.svg?width=890" /></a>

