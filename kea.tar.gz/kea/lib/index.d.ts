import { AnyAction, Reducer, Middleware, compose, StoreEnhancer, Store, Action } from 'redux';
import React, { ComponentType, FunctionComponent, Context as Context$1, ReactNode } from 'react';

declare type AnyComponent = ComponentType | FunctionComponent;
declare type Selector = (state?: any, props?: any) => any;
declare type RequiredPathCreator<T = string> = (key: T) => PathType;
declare type PathCreator<T = string> = (key?: T) => PathType;
declare type PathType = (string | number | boolean)[];
declare type Props = Record<string, any>;
declare type LogicEventType = 'beforeMount' | 'afterMount' | 'beforeUnmount' | 'afterUnmount';
declare type PartialRecord<K extends keyof any, T> = Partial<Record<K, T>>;
interface Logic {
    key: any;
    actionCreators: Record<string, any>;
    actionKeys: Record<string, string>;
    actionTypes: Record<string, string>;
    actions: Record<string, any>;
    cache: Record<string, any>;
    connections: {
        [pathString: string]: BuiltLogic;
    };
    constants: Record<string, string>;
    defaults: Record<string, any>;
    listeners: Record<string, ListenerFunctionWrapper[]>;
    path: PathType;
    pathString: string;
    props: any;
    propTypes: Record<string, any>;
    reducers: Record<string, any>;
    reducerOptions: Record<string, any>;
    reducer: any;
    selector?: Selector;
    selectors: Record<string, Selector>;
    sharedListeners?: Record<string, ListenerFunction>;
    values: Record<string, any>;
    events: PartialRecord<LogicEventType, () => void>;
    __keaTypeGenInternalSelectorTypes: Record<string, any>;
    __keaTypeGenInternalReducerActions: Record<string, any>;
}
interface BuiltLogicAdditions<LogicType extends Logic> {
    _isKeaBuild: boolean;
    mount(callback?: (logic: LogicType) => any): () => void;
    extend: <ExtendLogicType extends Logic = LogicType>(extendedInput: LogicInput<ExtendLogicType>) => ExtendLogicType & LogicWrapperAdditions<ExtendLogicType>;
    wrapper: LogicWrapper;
}
interface LogicWrapperAdditions<LogicType extends Logic> {
    _isKea: boolean;
    _isKeaWithKey: boolean;
    inputs: LogicInput[];
    <T extends LogicType['props'] | AnyComponent>(props: T): T extends LogicType['props'] ? LogicType & BuiltLogicAdditions<LogicType> : FunctionComponent;
    (): LogicType & BuiltLogicAdditions<LogicType>;
    wrap: (Component: AnyComponent) => KeaComponent;
    build: (props?: LogicType['props'], autoConnectInListener?: boolean) => LogicType & BuiltLogicAdditions<LogicType>;
    mount: (callback?: any) => () => void;
    extend: <ExtendLogicType extends Logic = LogicType>(extendedInput: LogicInput<ExtendLogicType>) => ExtendLogicType & LogicWrapperAdditions<ExtendLogicType>;
}
declare type BuiltLogic<LogicType extends Logic = Logic> = LogicType & BuiltLogicAdditions<LogicType>;
declare type LogicWrapper<LogicType extends Logic = Logic> = LogicType & LogicWrapperAdditions<LogicType>;
declare type ActionDefinitions<LogicType extends Logic> = Record<string, any | (() => any)> | LogicType['actionCreators'];
declare type ReducerActions<LogicType extends Logic, ReducerType> = {
    [K in keyof LogicType['actionCreators']]?: (state: ReducerType, payload: ReturnType<LogicType['actionCreators'][K]>['payload']) => ReducerType;
} & {
    [K in keyof LogicType['__keaTypeGenInternalReducerActions']]?: (state: ReducerType, payload: ReturnType<LogicType['__keaTypeGenInternalReducerActions'][K]>['payload']) => ReducerType;
};
declare type ReducerDefault<Reducer extends () => any, P extends Props> = ReturnType<Reducer> | ((state: any, props: P) => ReturnType<Reducer>);
declare type ReducerDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['reducers']]?: [ReducerDefault<LogicType['reducers'][K], LogicType['props']>, any, any, ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>] | [ReducerDefault<LogicType['reducers'][K], LogicType['props']>, any, ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>] | [ReducerDefault<LogicType['reducers'][K], LogicType['props']>, ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>] | [ReducerDefault<LogicType['reducers'][K], LogicType['props']>] | ReducerActions<LogicType, ReturnType<LogicType['reducers'][K]>>;
};
declare type ReducerFunction<S = any> = (state: S, action: AnyAction, fullState: any) => S;
declare type SelectorTuple = [] | [Selector] | [Selector, Selector] | [Selector, Selector, Selector] | [Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector] | [Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector, Selector];
declare type SelectorDefinition<Selectors, SelectorFunction extends any> = [(s: Selectors) => SelectorTuple, SelectorFunction] | [(s: Selectors) => SelectorTuple, SelectorFunction, any];
declare type SelectorDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['__keaTypeGenInternalSelectorTypes']]?: SelectorDefinition<LogicType['selectors'], LogicType['__keaTypeGenInternalSelectorTypes'][K]>;
} | {
    [key: string]: SelectorDefinition<LogicType['selectors'], any>;
};
declare type BreakPointFunction = (() => void) & ((ms: number) => Promise<void>);
declare type ListenerDefinitionsForRecord<A extends Record<string, (...args: any) => any>> = {
    [K in keyof A]?: ListenerFunction<ReturnType<A[K]>> | ListenerFunction<ReturnType<A[K]>>[];
};
declare type ListenerDefinitions<LogicType extends Logic> = ListenerDefinitionsForRecord<LogicType['actionCreators']> & ListenerDefinitionsForRecord<LogicType['__keaTypeGenInternalReducerActions']>;
declare type ListenerFunction<A extends AnyAction = any> = (payload: A['payload'], breakpoint: BreakPointFunction, action: A, previousState: any) => void | Promise<void>;
declare type ListenerFunctionWrapper = (action: any, previousState: any) => void;
declare type SharedListenerDefinitions = Record<string, ListenerFunction>;
declare type WindowValuesDefinitions<LogicType extends Logic> = Record<string, (window: Window) => any>;
declare type LoaderFunctions<LogicType extends Logic, ReducerReturnType> = {
    [K in keyof LogicType['actionCreators']]?: (payload: ReturnType<LogicType['actionCreators'][K]>['payload'], breakpoint: BreakPointFunction, action: ReturnType<LogicType['actionCreators'][K]>) => ReducerReturnType | Promise<ReducerReturnType>;
};
declare type LoaderDefinitions<LogicType extends Logic> = {
    [K in keyof LogicType['reducers']]?: (LoaderFunctions<LogicType, ReturnType<LogicType['reducers'][K]>> | {
        __default: ReturnType<LogicType['reducers'][K]>;
    }) | [ReturnType<LogicType['reducers'][K]>, LoaderFunctions<LogicType, ReturnType<LogicType['reducers'][K]>>];
};
declare type LogicInput<LogicType extends Logic = Logic> = {
    inherit?: LogicWrapper[];
    extend?: LogicInput[];
    key?: (props: LogicType['props']) => any;
    path?: (LogicType['key'] extends undefined ? PathCreator<LogicType['key']> : RequiredPathCreator<LogicType['key']>) | PathType;
    connect?: any;
    constants?: (logic: LogicType) => string[] | string[];
    actions?: ActionDefinitions<LogicType> | ((logic: LogicType) => ActionDefinitions<LogicType>);
    reducers?: ReducerDefinitions<LogicType> | ((logic: LogicType) => ReducerDefinitions<LogicType>);
    selectors?: SelectorDefinitions<LogicType> | ((logic: LogicType) => SelectorDefinitions<LogicType>);
    listeners?: ListenerDefinitions<LogicType> | ((logic: LogicType) => ListenerDefinitions<LogicType>);
    sharedListeners?: SharedListenerDefinitions | ((logic: LogicType) => SharedListenerDefinitions);
    events?: PartialRecord<LogicEventType, (() => void) | (() => void)[]> | ((logic: LogicType) => PartialRecord<LogicEventType, (() => void) | (() => void)[]>);
    defaults?: ((logic: LogicType) => (state: any, props: LogicType['props']) => Record<string, any>) | ((logic: LogicType) => Record<string, any>) | Record<string, any>;
    loaders?: LoaderDefinitions<LogicType> | ((logic: LogicType) => LoaderDefinitions<LogicType>);
    windowValues?: WindowValuesDefinitions<LogicType> | ((logic: LogicType) => WindowValuesDefinitions<LogicType>);
    urlToAction?: (logic: LogicType) => any;
    actionToUrl?: (logic: LogicType) => any;
    [key: string]: unknown;
};
interface MakeLogicType<Values = Record<string, unknown>, Actions = Record<string, AnyFunction>, LogicProps = Props> extends Logic {
    actionCreators: {
        [ActionKey in keyof Actions]: Actions[ActionKey] extends AnyFunction ? ActionCreatorForPayloadBuilder<Actions[ActionKey]> : never;
    };
    actionKeys: Record<string, string>;
    actionTypes: {
        [ActionKey in keyof Actions]: string;
    };
    actions: {
        [ActionKey in keyof Actions]: Actions[ActionKey] extends AnyFunction ? ActionForPayloadBuilder<Actions[ActionKey]> : never;
    };
    defaults: Values;
    props: LogicProps;
    reducer: ReducerFunction<Values>;
    reducers: {
        [Value in keyof Values]: ReducerFunction<Values[Value]>;
    };
    selector: (state: any, props: LogicProps) => Values;
    selectors: {
        [Value in keyof Values]: (state: any, props: LogicProps) => Values[Value];
    };
    values: Values;
    __keaTypeGenInternalSelectorTypes: {
        [K in keyof Values]: (...args: any) => Values[K];
    };
}
declare type AnyFunction = (...args: any) => any;
declare type ActionCreatorForPayloadBuilder<B extends AnyFunction> = (...args: Parameters<B>) => {
    type: string;
    payload: ReturnType<B>;
};
declare type ActionForPayloadBuilder<B extends AnyFunction> = (...args: Parameters<B>) => void;
interface CreateStoreOptions {
    paths: string[];
    reducers: Record<string, Reducer>;
    preloadedState: undefined;
    middleware: Middleware[];
    compose: typeof compose;
    enhancers: StoreEnhancer[];
    plugins: KeaPlugin[];
}
interface InternalContextOptions {
    debug: boolean;
    autoMount: boolean;
    autoConnect: boolean;
    proxyFields: boolean;
    flatDefaults: boolean;
    attachStrategy: 'dispatch' | 'replace';
    detachStrategy: 'dispatch' | 'replace' | 'persist';
    defaultPath: string[];
}
interface ContextOptions extends Partial<InternalContextOptions> {
    plugins?: KeaPlugin[];
    createStore?: boolean | Partial<CreateStoreOptions>;
    defaults?: Record<string, any>;
    skipPlugins?: string[];
}
declare type BuildStep = (logic: BuiltLogic, input: LogicInput) => void;
interface KeaComponent extends FunctionComponent {
    _wrapper: LogicWrapper;
    _wrappedComponent: AnyComponent;
}
interface PluginEvents {
    afterOpenContext?: (context: Context, options: ContextOptions) => void;
    afterPlugin?: () => void;
    beforeReduxStore?: (options: CreateStoreOptions) => void;
    afterReduxStore?: (options: CreateStoreOptions, store: Store) => void;
    beforeKea?: (input: LogicInput) => void;
    beforeBuild?: (logic: BuiltLogic, inputs: LogicInput[]) => void;
    beforeLogic?: (logic: BuiltLogic, input: LogicInput) => void;
    afterLogic?: (logic: BuiltLogic, input: LogicInput) => void;
    afterBuild?: (logic: BuiltLogic, inputs: LogicInput[]) => void;
    beforeMount?: (logic: BuiltLogic) => void;
    afterMount?: (logic: BuiltLogic) => void;
    beforeAttach?: (logic: BuiltLogic) => void;
    afterAttach?: (logic: BuiltLogic) => void;
    beforeUnmount?: (logic: BuiltLogic) => void;
    afterUnmount?: (logic: BuiltLogic) => void;
    beforeDetach?: (logic: BuiltLogic) => void;
    afterDetach?: (logic: BuiltLogic) => void;
    beforeWrapper?: (input: LogicInput, Klass: AnyComponent) => void;
    afterWrapper?: (input: LogicInput, Klass: AnyComponent, Kea: KeaComponent) => void;
    beforeRender?: (logic: BuiltLogic, props: Props) => void;
    beforeCloseContext?: (context: Context) => void;
}
declare type PluginEventArrays = {
    [K in keyof PluginEvents]: PluginEvents[K][];
};
interface KeaPlugin {
    name: string;
    defaults?: () => Record<string, any>;
    buildOrder?: Record<string, {
        before?: string;
        after?: string;
    }>;
    buildSteps?: Record<string, BuildStep>;
    events?: PluginEvents;
}
interface Context {
    plugins: {
        activated: KeaPlugin[];
        buildOrder: string[];
        buildSteps: Record<string, BuildStep[]>;
        events: PluginEventArrays;
        logicFields: Record<string, string>;
        contexts: Record<string, Record<string, any>>;
    };
    input: {
        logicPathCreators: Map<LogicInput, PathCreator<any>>;
        logicPathCounter: number;
        defaults: Record<string, any> | undefined;
    };
    build: {
        cache: Record<string, BuiltLogic>;
        heap: Logic[];
    };
    mount: {
        counter: Record<string, number>;
        mounted: Record<string, BuiltLogic>;
    };
    run: {
        heap: {
            action?: Action;
            type: 'action' | 'listener';
            logic: Logic;
        }[];
    };
    react: {
        contexts: WeakMap<LogicWrapper, Context$1<BuiltLogic | undefined>>;
    };
    reducers: {
        tree: any;
        roots: any;
        redux: any;
        whitelist: false | Record<string, boolean>;
        combined: ReducerFunction | undefined;
    };
    store: Store;
    __store: Store | undefined;
    options: InternalContextOptions;
}

declare function kea<LogicType extends Logic = Logic>(input: LogicInput<LogicType>): LogicType & LogicWrapperAdditions<LogicType>;
declare function connect<LogicType extends Logic = Logic>(input: LogicInput['connect']): LogicType & LogicWrapperAdditions<LogicType>;

declare function useKea(input: LogicInput, deps?: never[]): LogicWrapper;
declare function useValues<L extends BuiltLogic | LogicWrapper>(logic: L): L['values'];
declare function useAllValues<L extends BuiltLogic | LogicWrapper>(logic: L): L['values'];
declare function useActions<L extends BuiltLogic | LogicWrapper>(logic: L): L['actions'];
declare function useMountedLogic(logic: BuiltLogic | LogicWrapper): BuiltLogic;

declare type BindPropsProps = {
    logic: LogicWrapper;
    props: LogicWrapper['props'];
    children: ReactNode;
};
declare function BindLogic({ logic, props, children }: BindPropsProps): JSX.Element;

declare function Provider({ children }: {
    children: React.ReactNode;
}): JSX.Element;

declare function getContext(): Context;
declare function openContext(options?: ContextOptions, initial?: boolean): Context;
declare function closeContext(): void;
declare function resetContext(options?: ContextOptions, initial?: boolean): Context;
declare function getPluginContext(name: string): Record<string, any>;
declare function setPluginContext(name: string, pluginContext: Record<string, any>): void;

declare function getStore(opts?: {}): Store | void;

declare function keaReducer(pathStart?: string): ReducerFunction;

declare function activatePlugin(pluginToActivate: KeaPlugin | (() => KeaPlugin)): void;

interface KeaReduxAction {
    type: string;
    payload: any;
}
interface KeaAction {
    (...args: any[]): KeaReduxAction;
    _isKeaAction: boolean;
    toString(): string;
}
declare function createAction(type: string, payloadCreator: (...args: any[]) => any): KeaAction;

declare function addConnection(logic: Logic, otherLogic: Logic): void;

declare const isBreakpoint: (error: Error) => boolean;

declare const ATTACH_REDUCER: "@KEA/ATTACH_REDUCER";
declare const DETACH_REDUCER: "@KEA/DETACH_REDUCER";

export { ATTACH_REDUCER, AnyComponent, BindLogic, BreakPointFunction, BuiltLogic, BuiltLogicAdditions, Context, ContextOptions, CreateStoreOptions, DETACH_REDUCER, InternalContextOptions, KeaComponent, KeaPlugin, ListenerFunction, ListenerFunctionWrapper, Logic, LogicEventType, LogicInput, LogicWrapper, LogicWrapperAdditions, MakeLogicType, PartialRecord, PathCreator, PathType, PluginEventArrays, PluginEvents, Props, Provider, ReducerFunction, RequiredPathCreator, Selector, activatePlugin, addConnection, closeContext, connect, createAction, getContext, getPluginContext, getStore, isBreakpoint, kea, keaReducer, openContext, resetContext, setPluginContext, useActions, useAllValues, useKea, useMountedLogic, useValues };
