import { logicType } from './logicType';
interface Session {
    user: number;
    type: string;
}
export declare const logic: logicType<Session> & import("../src").LogicWrapperAdditions<logicType<Session>>;
export {};
