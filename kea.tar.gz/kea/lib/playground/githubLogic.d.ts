import { githubLogicType } from './githubLogicType';
export declare type Repository = {
    id: number;
    stargazers_count: number;
    html_url: string;
    full_name: string;
    forks: number;
};
export declare const githubLogic: githubLogicType<Repository> & import("../src").LogicWrapperAdditions<githubLogicType<Repository>>;
