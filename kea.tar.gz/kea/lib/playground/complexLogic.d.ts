import { complexLogicType } from './complexLogicType';
declare type FormInstance = {};
declare type AntdFieldData = {
    name: number;
    key: number;
};
declare type ActionType = {
    name?: string;
    steps?: string[];
};
declare type ActionForm = {
    name?: string;
    steps?: string[];
};
export declare const complexLogic: complexLogicType<ActionType, ActionForm, FormInstance, AntdFieldData> & import("../src").LogicWrapperAdditions<complexLogicType<ActionType, ActionForm, FormInstance, AntdFieldData>>;
export {};
