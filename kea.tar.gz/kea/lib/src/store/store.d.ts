import { Store } from 'redux';
export declare function getStore(opts?: {}): Store | void;
