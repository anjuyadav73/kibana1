import { KeaPlugin } from '../types';
export declare const corePlugin: KeaPlugin;
