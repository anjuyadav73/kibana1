import { Logic, LogicInput } from '../../types';
export declare function createReducers(logic: Logic, input: LogicInput): void;
