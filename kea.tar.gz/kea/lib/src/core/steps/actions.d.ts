import { Logic, LogicInput } from '../../types';
export declare function createActions(logic: Logic, input: LogicInput): void;
