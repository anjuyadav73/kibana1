import { Logic, LogicInput } from '../../types';
export declare function createActionCreators(logic: Logic, input: LogicInput): void;
export declare function createActionType(key: string, pathString: string): string;
