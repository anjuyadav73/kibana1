import { Logic, LogicInput } from '../../types';
export declare function createConstants(logic: Logic, input: LogicInput): void;
export default function convertConstants(constants: string[]): Record<string, string>;
