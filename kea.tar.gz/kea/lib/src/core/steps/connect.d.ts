import { BuiltLogic, Logic, LogicInput, LogicWrapper, Selector } from '../../types';
export declare function createConnect(logic: Logic, input: LogicInput): void;
declare type LogicMapping = (Logic | BuiltLogic | LogicWrapper | Selector | Record<string, any> | string[])[];
declare type DeconstructedLogicMapping = [Logic | BuiltLogic | LogicWrapper | Selector | Record<string, any>, string, string][];
export declare function deconstructMapping(mapping: LogicMapping): DeconstructedLogicMapping;
export {};
