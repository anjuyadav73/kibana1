import { Logic, LogicInput } from '../../types';
export declare function createDefaults(logic: Logic, input: LogicInput): void;
