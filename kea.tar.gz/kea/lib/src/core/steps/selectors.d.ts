import { Logic, LogicInput } from '../../types';
export declare function createSelectors(logic: Logic, input: LogicInput): void;
