import { Logic, LogicInput } from '../../types';
export declare function createValues(logic: Logic, input: LogicInput): void;
