import { Logic, LogicInput } from '../../types';
export declare function createReducerSelectors(logic: Logic, input: LogicInput): void;
