import { Logic, LogicInput } from '../../types';
export declare function createEvents(logic: Logic, input: LogicInput): void;
