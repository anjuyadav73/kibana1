import { Logic } from '../../types';
export declare function addConnection(logic: Logic, otherLogic: Logic): void;
