interface KeaReduxAction {
    type: string;
    payload: any;
}
interface KeaAction {
    (...args: any[]): KeaReduxAction;
    _isKeaAction: boolean;
    toString(): string;
}
export declare function createAction(type: string, payloadCreator: (...args: any[]) => any): KeaAction;
export {};
