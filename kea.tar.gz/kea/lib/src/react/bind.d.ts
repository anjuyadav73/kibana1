import { BuiltLogic, LogicWrapper } from '../types';
import * as React from 'react';
export declare type BindPropsProps = {
    logic: LogicWrapper;
    props: LogicWrapper['props'];
    children: React.ReactNode;
};
export declare function getOrCreateContextForLogicWrapper(logic: LogicWrapper): React.Context<BuiltLogic<import("../types").Logic> | undefined>;
export declare function BindLogic({ logic, props, children }: BindPropsProps): JSX.Element;
