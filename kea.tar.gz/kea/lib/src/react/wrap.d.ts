import { AnyComponent, KeaComponent, LogicWrapper } from '../types';
export declare function wrapComponent(Component: AnyComponent, wrapper: LogicWrapper): KeaComponent;
