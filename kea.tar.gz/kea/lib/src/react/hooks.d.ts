import { LogicInput, LogicWrapper, BuiltLogic } from '../types';
export declare function useKea(input: LogicInput, deps?: never[]): LogicWrapper;
export declare function useValues<L extends BuiltLogic | LogicWrapper>(logic: L): L['values'];
export declare function useAllValues<L extends BuiltLogic | LogicWrapper>(logic: L): L['values'];
export declare function useActions<L extends BuiltLogic | LogicWrapper>(logic: L): L['actions'];
export declare function isWrapper(toBeDetermined: BuiltLogic | LogicWrapper): toBeDetermined is LogicWrapper;
export declare function useMountedLogic(logic: BuiltLogic | LogicWrapper): BuiltLogic;
