import React from 'react';
export declare function Provider({ children }: {
    children: React.ReactNode;
}): JSX.Element;
