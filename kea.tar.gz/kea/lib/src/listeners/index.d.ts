import { KeaPlugin } from '../types';
export declare const LISTENERS_BREAKPOINT = "kea-listeners breakpoint broke";
export declare const isBreakpoint: (error: Error) => boolean;
export declare const listenersPlugin: KeaPlugin;
