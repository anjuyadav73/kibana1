import { LogicInput, PathType, Props } from '../types';
export declare function getPathForInput(input: LogicInput, props?: Props): PathType;
export declare function getPathStringForInput(input: LogicInput, props: Props): string;
