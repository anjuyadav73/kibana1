import { Logic, LogicInput, LogicWrapper, LogicWrapperAdditions } from '../types';
export declare function proxyFieldToLogic(wrapper: LogicWrapper, key: keyof Logic): void;
export declare function proxyFields(wrapper: LogicWrapper): void;
export declare function kea<LogicType extends Logic = Logic>(input: LogicInput<LogicType>): LogicType & LogicWrapperAdditions<LogicType>;
export declare function connect<LogicType extends Logic = Logic>(input: LogicInput['connect']): LogicType & LogicWrapperAdditions<LogicType>;
