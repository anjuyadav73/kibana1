import { LogicWrapper, Props, LogicInput, BuiltLogic } from '../types';
export declare function getBuiltLogic(inputs: LogicInput[], props: Props | undefined, wrapper: LogicWrapper, autoConnectInListener?: boolean): BuiltLogic;
