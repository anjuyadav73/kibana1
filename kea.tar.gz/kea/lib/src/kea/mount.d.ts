import { BuiltLogic, Logic } from '../types';
export declare function mountLogic(logic: Logic, count?: number): void;
export declare function unmountLogic(logic: BuiltLogic): void;
