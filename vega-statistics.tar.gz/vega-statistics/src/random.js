export var random = Math.random;

export function setRandom(r) {
  random = r;
}
