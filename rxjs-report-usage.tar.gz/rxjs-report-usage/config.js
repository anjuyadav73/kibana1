// To obtain the IDs, visit the preview page. The form ID is in the URL and the
// entry ID is in the input or textarea's name attribute. Note that the form ID
// is not the ID that's shown in the form editor's URL.

module.exports = {
  entryId: "entry.1902140047",
  formId: "1FAIpQLSeSs5nNqxZiQjGj2_rQTeuro_41-cvIovaPqwL7yhIj5xJv7g"
};
