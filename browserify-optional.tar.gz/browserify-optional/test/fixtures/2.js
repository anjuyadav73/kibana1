try {
  var a = 2, x = require('y');
} catch (e) {
  var x = require('z');
}
