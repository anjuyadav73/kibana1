try {
  var mocha = require('mocha');
} catch (e) {}
