This holds a very small subset of the `@opentelemetry/core` package, instead of
having a dependency on it. "Very small" here is just the `TraceState` class, as
opposed to a ~2.6M dependency.
