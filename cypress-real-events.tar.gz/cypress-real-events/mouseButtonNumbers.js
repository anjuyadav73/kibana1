"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mouseButtonNumbers = void 0;
exports.mouseButtonNumbers = {
    "none": 0,
    "left": 1,
    "right": 2,
    "middle": 4,
    "back": 8,
    "forward": 16,
};
