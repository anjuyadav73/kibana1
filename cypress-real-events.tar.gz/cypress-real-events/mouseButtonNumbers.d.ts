export declare const mouseButtonNumbers: {
    none: number;
    left: number;
    right: number;
    middle: number;
    back: number;
    forward: number;
};
