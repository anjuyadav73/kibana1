export declare function fireCdpCommand(command: string, params: Record<string, unknown>): Promise<void>;
