declare class TimeoutError extends Error {
    constructor(util: Function, timeout: number);
}
export { TimeoutError };
