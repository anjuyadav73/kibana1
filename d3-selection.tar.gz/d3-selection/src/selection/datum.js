export default function(value) {
  return arguments.length
      ? this.property("__data__", value)
      : this.node().__data__;
}
