
1.0.3 / 2017-07-25
==================

  * With the posibility of the MutationEvent being deprecated, check if exists prior to usage (#8)

1.0.2 / 2015-07-07
==================

  * fix delete as a reserved word issue on IE8 (#4, @kaesonho)

1.0.1 / 2015-03-10
==================

  * package: re-add the "component" section
  * package: use public git URL

1.0.0 / 2014-12-09
==================

  * Move away from `component.json`; into webmodules organization.
  * Add a MutationObserver polyfill for IE9-10. (written by the Polymer contributors)
  * Change license from MIT to BSD to match the Polymer polyfill license.

0.0.1 / 2013-02-09
==================

  * Initial release
