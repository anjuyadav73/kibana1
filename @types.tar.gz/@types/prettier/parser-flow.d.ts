import { Parser } from './';

declare const parser: {
    parsers: {
        flow: Parser;
    };
};
export = parser;
