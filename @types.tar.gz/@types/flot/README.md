# Installation
> `npm install --save @types/flot`

# Summary
This package contains type definitions for Flot (http://www.flotcharts.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/flot

Additional Details
 * Last updated: Mon, 11 Dec 2017 23:33:53 GMT
 * Dependencies: jquery
 * Global values: none

# Credits
These definitions were written by  Matt Burland <https://github.com/burlandm>, Timo Mühlbach <https://github.com/Anticom>, Ariel Kuechler <https://github.com/admiralsmaster>.
