# Installation
> `npm install --save @types/d3-scale`

# Summary
This package contains type definitions for D3JS d3-scale module (https://github.com/d3/d3-scale/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-scale/v3.

### Additional Details
 * Last updated: Sat, 26 Jun 2021 11:31:29 GMT
 * Dependencies: [@types/d3-time](https://npmjs.com/package/@types/d3-time)
 * Global values: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [rulonder](https://github.com/rulonder), and [Nathan Bierema](https://github.com/Methuselah96).
