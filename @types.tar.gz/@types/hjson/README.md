# Installation
> `npm install --save @types/hjson`

# Summary
This package contains type definitions for hjson (https://github.com/hjson/hjson-js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hjson.

### Additional Details
 * Last updated: Tue, 23 Jun 2020 16:00:07 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Mark van Straten](https://github.com/crunchie84), and [Ashik Meerankutty](https://github.com/ashikmeerankutty).
