# Installation
> `npm install --save @types/js-search`

# Summary
This package contains type definitions for js-search (https://github.com/bvaughn/js-search).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/js-search

Additional Details
 * Last updated: Mon, 01 May 2017 22:22:59 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Guo Yunhe <https://github.com/guoyunhe>.
