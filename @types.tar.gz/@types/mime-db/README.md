# Installation
> `npm install --save @types/mime-db`

# Summary
This package contains type definitions for mime-db (https://github.com/jshttp/mime-db).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mime-db

Additional Details
 * Last updated: Mon, 15 May 2017 22:20:54 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by AJP <https://github.com/AJamesPhillips>.
