# Installation
> `npm install --save @types/redux-actions`

# Summary
This package contains type definitions for redux-actions ( https://github.com/redux-utilities/redux-actions ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/redux-actions

Additional Details
 * Last updated: Wed, 08 May 2019 18:15:11 GMT
 * Dependencies: none
 * Global values: ReduxActions

# Credits
These definitions were written by Jack Hsu <https://github.com/jaysoo>, Alex Gorbatchev <https://github.com/alexgorbatchev>, Alec Hill <https://github.com/alechill>, Alexey Pelykh <https://github.com/alexey-pelykh>, Thiago de Andrade <https://github.com/7hi4g0>, Ziyu <https://github.com/oddui>.
