# Installation
> `npm install --save @types/d3-color`

# Summary
This package contains type definitions for D3JS d3-color module (https://github.com/d3/d3-color/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-color.

### Additional Details
 * Last updated: Tue, 17 Nov 2020 23:36:35 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [Hugues Stefanski](https://github.com/ledragon), and [Nathan Bierema](https://github.com/Methuselah96).
