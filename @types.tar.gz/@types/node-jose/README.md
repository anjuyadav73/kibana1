# Installation
> `npm install --save @types/node-jose`

# Summary
This package contains type definitions for node-jose (https://github.com/cisco/node-jose).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/node-jose.

### Additional Details
 * Last updated: Tue, 22 Mar 2022 04:31:43 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Nadun Indunil](https://github.com/nadunindunil).
