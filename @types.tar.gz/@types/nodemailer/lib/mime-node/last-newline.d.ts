/// <reference types="node" />

import { Transform } from 'stream';

declare class LastNewline extends Transform {
    lastByte: boolean;
}

export = LastNewline;
