# Installation
> `npm install --save @types/cacheable-request`

# Summary
This package contains type definitions for cacheable-request ( https://github.com/lukechilds/cacheable-request#readme ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cacheable-request

Additional Details
 * Last updated: Mon, 25 Mar 2019 16:32:10 GMT
 * Dependencies: @types/keyv, @types/http-cache-semantics, @types/responselike, @types/node
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>, Paul Melnikow <https://github.com/paulmelnikow>.
