// Type definitions for refractor 3.0
// Project: https://github.com/wooorm/refractor#readme
// Definitions by: Ifiok Jr. <https://github.com/ifiokjr>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 2.8

import refractor = require('./core');
export = refractor;
