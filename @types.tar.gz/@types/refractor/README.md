# Installation
> `npm install --save @types/refractor`

# Summary
This package contains type definitions for refractor (https://github.com/wooorm/refractor#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/refractor.

### Additional Details
 * Last updated: Mon, 31 Aug 2020 07:51:08 GMT
 * Dependencies: [@types/prismjs](https://npmjs.com/package/@types/prismjs)
 * Global values: none

# Credits
These definitions were written by [Ifiok Jr.](https://github.com/ifiokjr).
