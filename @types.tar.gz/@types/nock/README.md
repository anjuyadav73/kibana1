# Installation
> `npm install --save @types/nock`

# Summary
This package contains type definitions for nock ( https://github.com/nock/nock ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/nock

Additional Details
 * Last updated: Tue, 14 May 2019 20:53:20 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by bonnici <https://github.com/bonnici>, Horiuchi_H <https://github.com/horiuchi>, afharo <https://github.com/afharo>, Matt R. Wilson <https://github.com/mastermatt>, Garanzha Dmitriy <https://github.com/damour>, GP <https://github.com/paambaati>.
