# Installation
> `npm install --save @types/xml-crypto`

# Summary
This package contains type definitions for xml-crypto (https://github.com/yaronn/xml-crypto#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/xml-crypto.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 17:02:20 GMT
 * Dependencies: [@types/xpath](https://npmjs.com/package/@types/xpath), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Eric Heikes](https://github.com/eheikes), and [Max Chehab](https://github.com/maxchehab).
