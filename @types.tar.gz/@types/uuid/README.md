# Installation
> `npm install --save @types/uuid`

# Summary
This package contains type definitions for uuid (https://github.com/kelektiv/node-uuid).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uuid

Additional Details
 * Last updated: Thu, 30 Aug 2018 00:13:56 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Oliver Hoffmann <https://github.com/iamolivinius>, Felipe Ochoa <https://github.com/felipeochoa>, Chris Barth <https://github.com/cjbarth>.
