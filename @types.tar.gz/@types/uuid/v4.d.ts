import { v4 } from './interfaces';

declare const v4: v4;

export = v4;
