# Installation
> `npm install --save @types/archiver`

# Summary
This package contains type definitions for archiver (https://github.com/archiverjs/node-archiver).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/archiver.

### Additional Details
 * Last updated: Fri, 07 Jan 2022 10:01:22 GMT
 * Dependencies: [@types/glob](https://npmjs.com/package/@types/glob)
 * Global values: none

# Credits
These definitions were written by [ Esri
//                  Dolan Miu](https://github.com/dolanmiu), [Crevil](https://github.com/crevil), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
