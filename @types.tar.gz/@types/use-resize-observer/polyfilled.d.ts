import useResizeObserver = require('./index');

export default useResizeObserver;
