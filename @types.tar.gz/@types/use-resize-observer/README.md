# Installation
> `npm install --save @types/use-resize-observer`

# Summary
This package contains type definitions for use-resize-observer (https://github.com/ZeeCoder/use-resize-observer#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/use-resize-observer.

### Additional Details
 * Last updated: Fri, 17 Jan 2020 18:02:33 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: none

# Credits
These definitions were written by PetrSvirak (https://github.com/PetrSvirak).
