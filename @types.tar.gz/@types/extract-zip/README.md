# Installation
> `npm install --save @types/extract-zip`

# Summary
This package contains type definitions for extract-zip (https://github.com/maxogden/extract-zip).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/extract-zip

Additional Details
 * Last updated: Fri, 31 Mar 2017 19:23:23 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Mizunashi Mana <https://github.com/mizunashi-mana>.
