# Installation
> `npm install --save @types/minimist`

# Summary
This package contains type definitions for minimist (https://github.com/substack/minimist).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/minimist.

### Additional Details
 * Last updated: Wed, 07 Jul 2021 00:01:41 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Bart van der Schoor](https://github.com/Bartvds), [Necroskillz](https://github.com/Necroskillz), [kamranayub](https://github.com/kamranayub), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
