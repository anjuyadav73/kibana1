# Installation
> `npm install --save @types/pngjs`

# Summary
This package contains type definitions for pngjs (https://github.com/lukeapage/pngjs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/pngjs.

### Additional Details
 * Last updated: Sun, 22 Mar 2020 20:51:30 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43), [Florian Keller](https://github.com/ffflorian), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
