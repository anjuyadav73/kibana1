# Installation
> `npm install --save @types/retry`

# Summary
This package contains type definitions for retry (https://github.com/tim-kos/node-retry).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/retry

Additional Details
 * Last updated: Thu, 03 Jan 2019 17:45:51 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Stan Goldmann <https://github.com/krenor>, BendingBender <https://github.com/BendingBender>.
