# Installation
> `npm install --save @types/color-name`

# Summary
This package contains type definitions for color-name ( https://github.com/colorjs/color-name ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/color-name

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:48 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Junyoung Clare Jang <https://github.com/Ailrun>.
