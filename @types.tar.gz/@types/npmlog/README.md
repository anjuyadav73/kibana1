# Installation
> `npm install --save @types/npmlog`

# Summary
This package contains type definitions for npmlog (https://github.com/npm/npmlog#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/npmlog

Additional Details
 * Last updated: Wed, 26 Jun 2019 17:12:38 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Daniel Schmidt <https://github.com/DanielMSchmidt>, Zhu Zijia <https://github.com/littlepiggy03>, and Joseph Wynn <https://github.com/wildlyinaccurate>.
