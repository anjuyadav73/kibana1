# Installation
> `npm install --save @types/zen-observable`

# Summary
This package contains type definitions for zen-observable (https://github.com/zenparsing/zen-observable).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/zen-observable

Additional Details
 * Last updated: Tue, 26 Jun 2018 01:10:51 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Kombu <https://github.com/aicest>, JounQin <https://github.com/JounQin>, Thomas <https://github.com/itomtom>.
