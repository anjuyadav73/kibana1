# Installation
> `npm install --save @types/cookiejar`

# Summary
This package contains type definitions for CookieJar (https://github.com/bmeck/node-cookiejar).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cookiejar

Additional Details
 * Last updated: Fri, 06 Jul 2018 21:56:16 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Rafal Proszowski <https://github.com/paroxp>.
