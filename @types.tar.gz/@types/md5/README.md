# Installation
> `npm install --save @types/md5`

# Summary
This package contains type definitions for md5 (https://github.com/pvorb/node-md5).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/md5.

### Additional Details
 * Last updated: Sat, 11 Apr 2020 03:17:10 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Bill Sourour](https://github.com/arcdev1), [Cameron Crothers](https://github.com/jprogrammer), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
