# Installation
> `npm install --save @types/opn`

# Summary
This package contains type definitions for opn (https://github.com/sindresorhus/opn).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/opn

Additional Details
 * Last updated: Tue, 14 Nov 2017 19:26:15 GMT
 * Dependencies: child_process, node
 * Global values: none

# Credits
These definitions were written by Shinnosuke Watanabe <https://github.com/shinnn>, Maxime LUCE <https://github.com/SomaticIT>, Tommy Lent <https://github.com/tlent>.
