# Installation
> `npm install --save @types/hapi__inert`

# Summary
This package contains type definitions for @hapi/inert (https://github.com/hapijs/inert/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hapi__inert.

### Additional Details
 * Last updated: Thu, 08 Jul 2021 14:22:44 GMT
 * Dependencies: [@types/hapi__hapi](https://npmjs.com/package/@types/hapi__hapi)
 * Global values: none

# Credits
These definitions were written by [Steve Ognibene](https://github.com/nycdotnet), [Alexander James Phillips](https://github.com/AJamesPhillips), and [Silas Rech](https://github.com/lenovouser).
