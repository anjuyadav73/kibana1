# Installation
> `npm install --save @types/adm-zip`

# Summary
This package contains type definitions for adm-zip (https://github.com/cthackers/adm-zip).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/adm-zip.

### Additional Details
 * Last updated: Fri, 01 Apr 2022 08:01:43 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [John Vilk](https://github.com/jvilk), [Abner Oliveira](https://github.com/abner), [BendingBender](https://github.com/BendingBender), [Matthew Sainsbury](https://github.com/mattsains), and [Lei Nelissen](https://github.com/LeiNelissen).
