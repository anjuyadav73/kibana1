# Installation
> `npm install --save @types/hapi__shot`

# Summary
This package contains type definitions for @hapi/shot (https://github.com/hapijs/shot).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hapi__shot.

### Additional Details
 * Last updated: Fri, 25 Sep 2020 23:55:57 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [AJP](https://github.com/AJamesPhillips), [Simon Schick](https://github.com/SimonSchick), and [Silas Rech](https://github.com/lenovouser).
