# Installation
> `npm install --save @types/hapi__mimos`

# Summary
This package contains type definitions for @hapi/mimos ( https://github.com/hapijs/mimos ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hapi__mimos

Additional Details
 * Last updated: Fri, 12 Apr 2019 00:14:23 GMT
 * Dependencies: @types/mime-db
 * Global values: none

# Credits
These definitions were written by AJP <https://github.com/AJamesPhillips>, Silas Rech <https://github.com/lenovouser>.
