# Installation
> `npm install --save @types/minipass`

# Summary
This package contains type definitions for minipass (https://github.com/isaacs/minipass#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/minipass

Additional Details
 * Last updated: Thu, 17 Aug 2017 20:28:47 GMT
 * Dependencies: events, node
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
