# Installation
> `npm install --save @types/mock-fs`

# Summary
This package contains type definitions for mock-fs (https://github.com/tschaub/mock-fs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mock-fs.

### Additional Details
 * Last updated: Wed, 07 Jul 2021 00:01:42 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Wim Looman](https://github.com/Nemo157), [Qubo](https://github.com/tkqubo), [Porama Ruengrairatanaroj](https://github.com/Seally), and [Chris Shaw](https://github.com/cshawaus).
