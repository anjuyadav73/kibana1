import mock = require('../index');

export = mock;
