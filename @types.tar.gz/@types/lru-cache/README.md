# Installation
> `npm install --save @types/lru-cache`

# Summary
This package contains type definitions for lru-cache ( https://github.com/isaacs/node-lru-cache ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lru-cache

Additional Details
 * Last updated: Sat, 23 Feb 2019 00:30:37 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bart van der Schoor <https://github.com/Bartvds>, BendingBender <https://github.com/BendingBender>.
