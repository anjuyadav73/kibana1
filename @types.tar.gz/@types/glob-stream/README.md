# Installation
> `npm install --save @types/glob-stream`

# Summary
This package contains type definitions for glob-stream (https://github.com/wearefractal/glob-stream).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/glob-stream

Additional Details
 * Last updated: Sun, 03 Dec 2017 16:26:41 GMT
 * Dependencies: glob, node
 * Global values: none

# Credits
These definitions were written by Bart van der Schoor <https://github.com/Bartvds>, mrmlnc <https://github.com/mrmlnc>.
