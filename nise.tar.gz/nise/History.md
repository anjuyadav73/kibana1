
1.4.1 / 2018-06-03
==================

  * Fix issue where no parsererror is returned on invalid XML (#55)

1.4.0 / 2018-06-01
==================

  * Throw an explicit error if the header value is not a string (#53)
  * Pass responseType for defaked XHR (#45)
  * Correctly handle case where fake XHR returns invalid XML (#50)



Older releases need descriptions
================================
Feel free to help out with a PR!
