# @probe.gl/stats

Logging and instrumentation tools for JavaScript

[probe.gl](https://uber-web.github.io/probe.gl/#/documentation/overview/docs) is a collection of logging, instrumentation, bench-marking and test tools for JavaScript applications.

For documentation please visit the [website](https://uber-web.github.io/probe.gl/#/documentation/overview).
