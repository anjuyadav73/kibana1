All changelogs can be found in [Releases](https://github.com/piotrwitek/utility-types/releases)
