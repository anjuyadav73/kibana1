import interrupt from "../interrupt.js";

export default function(name) {
  return this.each(function() {
    interrupt(this, name);
  });
}
