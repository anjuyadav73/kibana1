function _of(x) {
  return [x];
}
module.exports = _of;