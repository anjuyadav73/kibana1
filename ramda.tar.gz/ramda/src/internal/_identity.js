function _identity(x) {
  return x;
}
module.exports = _identity;