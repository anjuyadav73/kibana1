function _isString(x) {
  return Object.prototype.toString.call(x) === '[object String]';
}
module.exports = _isString;