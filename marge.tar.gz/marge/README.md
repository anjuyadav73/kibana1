# marge
merge command line arguments with an on-disk configuration file
