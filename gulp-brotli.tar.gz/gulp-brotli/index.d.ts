/// <reference types="node" />
import * as stream from 'stream';
import * as zlib from 'zlib';
declare type CompressFunctionType = typeof compress;
interface IExportedApi extends CompressFunctionType {
    compress: CompressFunctionType;
    decompress: typeof decompress;
}
interface IOptions extends zlib.BrotliOptions {
    extension?: string;
}
interface ICompressionOptions extends IOptions {
    skipLarger?: boolean;
}
declare function compress(options?: ICompressionOptions): stream.Transform;
declare function decompress(options?: IOptions): stream.Transform;
declare const exportedApi: IExportedApi;
export = exportedApi;
