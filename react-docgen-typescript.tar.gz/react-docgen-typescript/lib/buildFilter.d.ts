import { ParserOptions, PropFilter } from './parser';
export declare function buildFilter(opts: ParserOptions): PropFilter;
