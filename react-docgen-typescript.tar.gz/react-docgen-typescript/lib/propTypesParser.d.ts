import { ComponentDoc } from './parser';
/**
 * This method exists for backward compatibility only.
 * Use *parse* method from *parser* file.
 */
export declare function parse(fileName: string): ComponentDoc[];
