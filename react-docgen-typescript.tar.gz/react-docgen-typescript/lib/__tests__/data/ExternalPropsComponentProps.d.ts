/** ExternalPropsComponentProps props  */
export interface ExternalPropsComponentProps {
    /** prop1 description */
    prop1: string;
}
/** ExternalOptionalComponentProps props  */
export interface ExternalOptionalComponentProps {
    /** prop1 description */
    prop1?: string;
}
