export declare const defaultProps: {
    name: string;
};
