declare const PROPERTY1_DEFAULT = "hello";
declare const PROPERTY2_DEFAULT = "goodbye";
declare const PROPERTY3_DEFAULT = 10;
declare const PROPERTY4_DEFAULT = "this is a string";
declare const PROPERTY5_DEFAULT = true;
export { PROPERTY1_DEFAULT, PROPERTY2_DEFAULT, PROPERTY3_DEFAULT, PROPERTY4_DEFAULT, PROPERTY5_DEFAULT };
