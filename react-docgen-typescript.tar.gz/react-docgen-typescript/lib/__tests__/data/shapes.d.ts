import * as PropTypes from 'prop-types';
export declare const SomeShape: PropTypes.Requireable<PropTypes.InferProps<{}>>;
