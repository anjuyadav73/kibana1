# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2021-05-25

### Commits

- Initial package creation [`6f74bd8`](https://github.com/es-shims/Object.hasOwn/commit/6f74bd8cd669cd5964358ef85b51466baea34af7)
- Initial commit [`cea8e05`](https://github.com/es-shims/Object.hasOwn/commit/cea8e058018ccd8ba31b15eebfe2b8181deb9946)
