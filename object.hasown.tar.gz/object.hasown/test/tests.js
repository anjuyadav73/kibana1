'use strict';

// eslint-disable-next-line no-unused-vars
module.exports = function runTests(hasOwn, t) {
	// TODO
};
