// Minimum TypeScript Version: 3.0

import buffer from './buffer'

export default buffer
