'use strict'

module.exports = require('./buffer.js')
