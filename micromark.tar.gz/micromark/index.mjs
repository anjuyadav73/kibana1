export {default} from './buffer.mjs'
