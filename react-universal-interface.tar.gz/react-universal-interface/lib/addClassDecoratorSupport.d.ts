declare const addClassDecoratorSupport: (Comp: any) => any;
export default addClassDecoratorSupport;
