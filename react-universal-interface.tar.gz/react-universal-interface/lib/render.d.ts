declare const render: (props: any, data: any, ...more: any[]) => any;
export default render;
