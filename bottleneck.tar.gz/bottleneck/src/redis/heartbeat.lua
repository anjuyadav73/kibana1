process_tick(now, true)
