const packagejson = require('../package.json')

console.log(JSON.stringify({version: packagejson.version}))
