
module.exports = require('./src/components/Docs');
