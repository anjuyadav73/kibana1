module.exports = {
  extends: '@case/eslint-config',
  env: {
    jest: true
  }
}
