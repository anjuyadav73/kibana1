var x = 5, y = require('fs'), z = 555;
var html = y.readFileSync(__dirname + '/robot.html', 'utf8');
console.log(html);
