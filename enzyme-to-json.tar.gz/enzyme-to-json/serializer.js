"use strict";

var _createSerializer = _interopRequireDefault(require("./createSerializer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = (0, _createSerializer.default)();