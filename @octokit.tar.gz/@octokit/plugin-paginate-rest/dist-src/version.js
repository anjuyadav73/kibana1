export const VERSION = "1.1.2";
