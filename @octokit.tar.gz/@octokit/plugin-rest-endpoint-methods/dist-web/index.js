import { Deprecation } from 'deprecation';

var endpointsByScope = {
    actions: {
        cancelWorkflowRun: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id/cancel"
        },
        createOrUpdateSecretForRepo: {
            method: "PUT",
            params: {
                encrypted_value: { type: "string" },
                key_id: { type: "string" },
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/secrets/:name"
        },
        createRegistrationToken: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/runners/registration-token"
        },
        createRemoveToken: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/runners/remove-token"
        },
        deleteArtifact: {
            method: "DELETE",
            params: {
                artifact_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/artifacts/:artifact_id"
        },
        deleteSecretFromRepo: {
            method: "DELETE",
            params: {
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/secrets/:name"
        },
        downloadArtifact: {
            method: "GET",
            params: {
                archive_format: { required: true, type: "string" },
                artifact_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/artifacts/:artifact_id/:archive_format"
        },
        getArtifact: {
            method: "GET",
            params: {
                artifact_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/artifacts/:artifact_id"
        },
        getPublicKey: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/secrets/public-key"
        },
        getSecret: {
            method: "GET",
            params: {
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/secrets/:name"
        },
        getSelfHostedRunner: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                runner_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runners/:runner_id"
        },
        getWorkflow: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                workflow_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/workflows/:workflow_id"
        },
        getWorkflowJob: {
            method: "GET",
            params: {
                job_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/jobs/:job_id"
        },
        getWorkflowRun: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id"
        },
        listDownloadsForSelfHostedRunnerApplication: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/runners/downloads"
        },
        listJobsForWorkflowRun: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id/jobs"
        },
        listRepoWorkflowRuns: {
            method: "GET",
            params: {
                actor: { type: "string" },
                branch: { type: "string" },
                event: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                status: { enum: ["completed", "status", "conclusion"], type: "string" }
            },
            url: "/repos/:owner/:repo/actions/runs"
        },
        listRepoWorkflows: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/workflows"
        },
        listSecretsForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/secrets"
        },
        listSelfHostedRunnersForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/runners"
        },
        listWorkflowJobLogs: {
            method: "GET",
            params: {
                job_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/actions/jobs/:job_id/logs"
        },
        listWorkflowRunArtifacts: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id/artifacts"
        },
        listWorkflowRunLogs: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id/logs"
        },
        listWorkflowRuns: {
            method: "GET",
            params: {
                actor: { type: "string" },
                branch: { type: "string" },
                event: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                status: { enum: ["completed", "status", "conclusion"], type: "string" },
                workflow_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/workflows/:workflow_id/runs"
        },
        reRunWorkflow: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                run_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runs/:run_id/rerun"
        },
        removeSelfHostedRunner: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                runner_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/actions/runners/:runner_id"
        }
    },
    activity: {
        checkStarringRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/user/starred/:owner/:repo"
        },
        deleteRepoSubscription: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/subscription"
        },
        deleteThreadSubscription: {
            method: "DELETE",
            params: { thread_id: { required: true, type: "integer" } },
            url: "/notifications/threads/:thread_id/subscription"
        },
        getRepoSubscription: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/subscription"
        },
        getThread: {
            method: "GET",
            params: { thread_id: { required: true, type: "integer" } },
            url: "/notifications/threads/:thread_id"
        },
        getThreadSubscription: {
            method: "GET",
            params: { thread_id: { required: true, type: "integer" } },
            url: "/notifications/threads/:thread_id/subscription"
        },
        listEventsForOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/events/orgs/:org"
        },
        listEventsForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/events"
        },
        listFeeds: { method: "GET", params: {}, url: "/feeds" },
        listNotifications: {
            method: "GET",
            params: {
                all: { type: "boolean" },
                before: { type: "string" },
                page: { type: "integer" },
                participating: { type: "boolean" },
                per_page: { type: "integer" },
                since: { type: "string" }
            },
            url: "/notifications"
        },
        listNotificationsForRepo: {
            method: "GET",
            params: {
                all: { type: "boolean" },
                before: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                participating: { type: "boolean" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                since: { type: "string" }
            },
            url: "/repos/:owner/:repo/notifications"
        },
        listPublicEvents: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/events"
        },
        listPublicEventsForOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/events"
        },
        listPublicEventsForRepoNetwork: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/networks/:owner/:repo/events"
        },
        listPublicEventsForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/events/public"
        },
        listReceivedEventsForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/received_events"
        },
        listReceivedPublicEventsForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/received_events/public"
        },
        listRepoEvents: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/events"
        },
        listReposStarredByAuthenticatedUser: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/user/starred"
        },
        listReposStarredByUser: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                sort: { enum: ["created", "updated"], type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/starred"
        },
        listReposWatchedByUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/subscriptions"
        },
        listStargazersForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stargazers"
        },
        listWatchedReposForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/subscriptions"
        },
        listWatchersForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/subscribers"
        },
        markAsRead: {
            method: "PUT",
            params: { last_read_at: { type: "string" } },
            url: "/notifications"
        },
        markNotificationsAsReadForRepo: {
            method: "PUT",
            params: {
                last_read_at: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/notifications"
        },
        markThreadAsRead: {
            method: "PATCH",
            params: { thread_id: { required: true, type: "integer" } },
            url: "/notifications/threads/:thread_id"
        },
        setRepoSubscription: {
            method: "PUT",
            params: {
                ignored: { type: "boolean" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                subscribed: { type: "boolean" }
            },
            url: "/repos/:owner/:repo/subscription"
        },
        setThreadSubscription: {
            method: "PUT",
            params: {
                ignored: { type: "boolean" },
                thread_id: { required: true, type: "integer" }
            },
            url: "/notifications/threads/:thread_id/subscription"
        },
        starRepo: {
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/user/starred/:owner/:repo"
        },
        unstarRepo: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/user/starred/:owner/:repo"
        }
    },
    apps: {
        addRepoToInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "PUT",
            params: {
                installation_id: { required: true, type: "integer" },
                repository_id: { required: true, type: "integer" }
            },
            url: "/user/installations/:installation_id/repositories/:repository_id"
        },
        checkAccountIsAssociatedWithAny: {
            method: "GET",
            params: { account_id: { required: true, type: "integer" } },
            url: "/marketplace_listing/accounts/:account_id"
        },
        checkAccountIsAssociatedWithAnyStubbed: {
            method: "GET",
            params: { account_id: { required: true, type: "integer" } },
            url: "/marketplace_listing/stubbed/accounts/:account_id"
        },
        checkAuthorization: {
            deprecated: "octokit.apps.checkAuthorization() is deprecated, see https://developer.github.com/v3/apps/oauth_applications/#check-an-authorization",
            method: "GET",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        checkToken: {
            headers: { accept: "application/vnd.github.doctor-strange-preview+json" },
            method: "POST",
            params: {
                access_token: { type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/token"
        },
        createContentAttachment: {
            headers: { accept: "application/vnd.github.corsair-preview+json" },
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                content_reference_id: { required: true, type: "integer" },
                title: { required: true, type: "string" }
            },
            url: "/content_references/:content_reference_id/attachments"
        },
        createFromManifest: {
            headers: { accept: "application/vnd.github.fury-preview+json" },
            method: "POST",
            params: { code: { required: true, type: "string" } },
            url: "/app-manifests/:code/conversions"
        },
        createInstallationToken: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "POST",
            params: {
                installation_id: { required: true, type: "integer" },
                permissions: { type: "object" },
                repository_ids: { type: "integer[]" }
            },
            url: "/app/installations/:installation_id/access_tokens"
        },
        deleteAuthorization: {
            headers: { accept: "application/vnd.github.doctor-strange-preview+json" },
            method: "DELETE",
            params: {
                access_token: { type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/grant"
        },
        deleteInstallation: {
            headers: {
                accept: "application/vnd.github.gambit-preview+json,application/vnd.github.machine-man-preview+json"
            },
            method: "DELETE",
            params: { installation_id: { required: true, type: "integer" } },
            url: "/app/installations/:installation_id"
        },
        deleteToken: {
            headers: { accept: "application/vnd.github.doctor-strange-preview+json" },
            method: "DELETE",
            params: {
                access_token: { type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/token"
        },
        findOrgInstallation: {
            deprecated: "octokit.apps.findOrgInstallation() has been renamed to octokit.apps.getOrgInstallation() (2019-04-10)",
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org/installation"
        },
        findRepoInstallation: {
            deprecated: "octokit.apps.findRepoInstallation() has been renamed to octokit.apps.getRepoInstallation() (2019-04-10)",
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/installation"
        },
        findUserInstallation: {
            deprecated: "octokit.apps.findUserInstallation() has been renamed to octokit.apps.getUserInstallation() (2019-04-10)",
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { username: { required: true, type: "string" } },
            url: "/users/:username/installation"
        },
        getAuthenticated: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: {},
            url: "/app"
        },
        getBySlug: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { app_slug: { required: true, type: "string" } },
            url: "/apps/:app_slug"
        },
        getInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { installation_id: { required: true, type: "integer" } },
            url: "/app/installations/:installation_id"
        },
        getOrgInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org/installation"
        },
        getRepoInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/installation"
        },
        getUserInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { username: { required: true, type: "string" } },
            url: "/users/:username/installation"
        },
        listAccountsUserOrOrgOnPlan: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                plan_id: { required: true, type: "integer" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/marketplace_listing/plans/:plan_id/accounts"
        },
        listAccountsUserOrOrgOnPlanStubbed: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                plan_id: { required: true, type: "integer" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/marketplace_listing/stubbed/plans/:plan_id/accounts"
        },
        listInstallationReposForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: {
                installation_id: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/user/installations/:installation_id/repositories"
        },
        listInstallations: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/app/installations"
        },
        listInstallationsForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/installations"
        },
        listMarketplacePurchasesForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/marketplace_purchases"
        },
        listMarketplacePurchasesForAuthenticatedUserStubbed: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/marketplace_purchases/stubbed"
        },
        listPlans: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/marketplace_listing/plans"
        },
        listPlansStubbed: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/marketplace_listing/stubbed/plans"
        },
        listRepos: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/installation/repositories"
        },
        removeRepoFromInstallation: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "DELETE",
            params: {
                installation_id: { required: true, type: "integer" },
                repository_id: { required: true, type: "integer" }
            },
            url: "/user/installations/:installation_id/repositories/:repository_id"
        },
        resetAuthorization: {
            deprecated: "octokit.apps.resetAuthorization() is deprecated, see https://developer.github.com/v3/apps/oauth_applications/#reset-an-authorization",
            method: "POST",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        resetToken: {
            headers: { accept: "application/vnd.github.doctor-strange-preview+json" },
            method: "PATCH",
            params: {
                access_token: { type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/token"
        },
        revokeAuthorizationForApplication: {
            deprecated: "octokit.apps.revokeAuthorizationForApplication() is deprecated, see https://developer.github.com/v3/apps/oauth_applications/#revoke-an-authorization-for-an-application",
            method: "DELETE",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        revokeGrantForApplication: {
            deprecated: "octokit.apps.revokeGrantForApplication() is deprecated, see https://developer.github.com/v3/apps/oauth_applications/#revoke-a-grant-for-an-application",
            method: "DELETE",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/grants/:access_token"
        },
        revokeInstallationToken: {
            headers: { accept: "application/vnd.github.gambit-preview+json" },
            method: "DELETE",
            params: {},
            url: "/installation/token"
        }
    },
    checks: {
        create: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "POST",
            params: {
                actions: { type: "object[]" },
                "actions[].description": { required: true, type: "string" },
                "actions[].identifier": { required: true, type: "string" },
                "actions[].label": { required: true, type: "string" },
                completed_at: { type: "string" },
                conclusion: {
                    enum: [
                        "success",
                        "failure",
                        "neutral",
                        "cancelled",
                        "timed_out",
                        "action_required"
                    ],
                    type: "string"
                },
                details_url: { type: "string" },
                external_id: { type: "string" },
                head_sha: { required: true, type: "string" },
                name: { required: true, type: "string" },
                output: { type: "object" },
                "output.annotations": { type: "object[]" },
                "output.annotations[].annotation_level": {
                    enum: ["notice", "warning", "failure"],
                    required: true,
                    type: "string"
                },
                "output.annotations[].end_column": { type: "integer" },
                "output.annotations[].end_line": { required: true, type: "integer" },
                "output.annotations[].message": { required: true, type: "string" },
                "output.annotations[].path": { required: true, type: "string" },
                "output.annotations[].raw_details": { type: "string" },
                "output.annotations[].start_column": { type: "integer" },
                "output.annotations[].start_line": { required: true, type: "integer" },
                "output.annotations[].title": { type: "string" },
                "output.images": { type: "object[]" },
                "output.images[].alt": { required: true, type: "string" },
                "output.images[].caption": { type: "string" },
                "output.images[].image_url": { required: true, type: "string" },
                "output.summary": { required: true, type: "string" },
                "output.text": { type: "string" },
                "output.title": { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                started_at: { type: "string" },
                status: { enum: ["queued", "in_progress", "completed"], type: "string" }
            },
            url: "/repos/:owner/:repo/check-runs"
        },
        createSuite: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "POST",
            params: {
                head_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-suites"
        },
        get: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                check_run_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-runs/:check_run_id"
        },
        getSuite: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                check_suite_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-suites/:check_suite_id"
        },
        listAnnotations: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                check_run_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-runs/:check_run_id/annotations"
        },
        listForRef: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                check_name: { type: "string" },
                filter: { enum: ["latest", "all"], type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                status: { enum: ["queued", "in_progress", "completed"], type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref/check-runs"
        },
        listForSuite: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                check_name: { type: "string" },
                check_suite_id: { required: true, type: "integer" },
                filter: { enum: ["latest", "all"], type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                status: { enum: ["queued", "in_progress", "completed"], type: "string" }
            },
            url: "/repos/:owner/:repo/check-suites/:check_suite_id/check-runs"
        },
        listSuitesForRef: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "GET",
            params: {
                app_id: { type: "integer" },
                check_name: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref/check-suites"
        },
        rerequestSuite: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "POST",
            params: {
                check_suite_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-suites/:check_suite_id/rerequest"
        },
        setSuitesPreferences: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "PATCH",
            params: {
                auto_trigger_checks: { type: "object[]" },
                "auto_trigger_checks[].app_id": { required: true, type: "integer" },
                "auto_trigger_checks[].setting": { required: true, type: "boolean" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/check-suites/preferences"
        },
        update: {
            headers: { accept: "application/vnd.github.antiope-preview+json" },
            method: "PATCH",
            params: {
                actions: { type: "object[]" },
                "actions[].description": { required: true, type: "string" },
                "actions[].identifier": { required: true, type: "string" },
                "actions[].label": { required: true, type: "string" },
                check_run_id: { required: true, type: "integer" },
                completed_at: { type: "string" },
                conclusion: {
                    enum: [
                        "success",
                        "failure",
                        "neutral",
                        "cancelled",
                        "timed_out",
                        "action_required"
                    ],
                    type: "string"
                },
                details_url: { type: "string" },
                external_id: { type: "string" },
                name: { type: "string" },
                output: { type: "object" },
                "output.annotations": { type: "object[]" },
                "output.annotations[].annotation_level": {
                    enum: ["notice", "warning", "failure"],
                    required: true,
                    type: "string"
                },
                "output.annotations[].end_column": { type: "integer" },
                "output.annotations[].end_line": { required: true, type: "integer" },
                "output.annotations[].message": { required: true, type: "string" },
                "output.annotations[].path": { required: true, type: "string" },
                "output.annotations[].raw_details": { type: "string" },
                "output.annotations[].start_column": { type: "integer" },
                "output.annotations[].start_line": { required: true, type: "integer" },
                "output.annotations[].title": { type: "string" },
                "output.images": { type: "object[]" },
                "output.images[].alt": { required: true, type: "string" },
                "output.images[].caption": { type: "string" },
                "output.images[].image_url": { required: true, type: "string" },
                "output.summary": { required: true, type: "string" },
                "output.text": { type: "string" },
                "output.title": { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                started_at: { type: "string" },
                status: { enum: ["queued", "in_progress", "completed"], type: "string" }
            },
            url: "/repos/:owner/:repo/check-runs/:check_run_id"
        }
    },
    codesOfConduct: {
        getConductCode: {
            headers: { accept: "application/vnd.github.scarlet-witch-preview+json" },
            method: "GET",
            params: { key: { required: true, type: "string" } },
            url: "/codes_of_conduct/:key"
        },
        getForRepo: {
            headers: { accept: "application/vnd.github.scarlet-witch-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/community/code_of_conduct"
        },
        listConductCodes: {
            headers: { accept: "application/vnd.github.scarlet-witch-preview+json" },
            method: "GET",
            params: {},
            url: "/codes_of_conduct"
        }
    },
    emojis: { get: { method: "GET", params: {}, url: "/emojis" } },
    gists: {
        checkIsStarred: {
            method: "GET",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id/star"
        },
        create: {
            method: "POST",
            params: {
                description: { type: "string" },
                files: { required: true, type: "object" },
                "files.content": { type: "string" },
                public: { type: "boolean" }
            },
            url: "/gists"
        },
        createComment: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                gist_id: { required: true, type: "string" }
            },
            url: "/gists/:gist_id/comments"
        },
        delete: {
            method: "DELETE",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id"
        },
        deleteComment: {
            method: "DELETE",
            params: {
                comment_id: { required: true, type: "integer" },
                gist_id: { required: true, type: "string" }
            },
            url: "/gists/:gist_id/comments/:comment_id"
        },
        fork: {
            method: "POST",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id/forks"
        },
        get: {
            method: "GET",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id"
        },
        getComment: {
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                gist_id: { required: true, type: "string" }
            },
            url: "/gists/:gist_id/comments/:comment_id"
        },
        getRevision: {
            method: "GET",
            params: {
                gist_id: { required: true, type: "string" },
                sha: { required: true, type: "string" }
            },
            url: "/gists/:gist_id/:sha"
        },
        list: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" }
            },
            url: "/gists"
        },
        listComments: {
            method: "GET",
            params: {
                gist_id: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/gists/:gist_id/comments"
        },
        listCommits: {
            method: "GET",
            params: {
                gist_id: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/gists/:gist_id/commits"
        },
        listForks: {
            method: "GET",
            params: {
                gist_id: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/gists/:gist_id/forks"
        },
        listPublic: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" }
            },
            url: "/gists/public"
        },
        listPublicForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/gists"
        },
        listStarred: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" }
            },
            url: "/gists/starred"
        },
        star: {
            method: "PUT",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id/star"
        },
        unstar: {
            method: "DELETE",
            params: { gist_id: { required: true, type: "string" } },
            url: "/gists/:gist_id/star"
        },
        update: {
            method: "PATCH",
            params: {
                description: { type: "string" },
                files: { type: "object" },
                "files.content": { type: "string" },
                "files.filename": { type: "string" },
                gist_id: { required: true, type: "string" }
            },
            url: "/gists/:gist_id"
        },
        updateComment: {
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_id: { required: true, type: "integer" },
                gist_id: { required: true, type: "string" }
            },
            url: "/gists/:gist_id/comments/:comment_id"
        }
    },
    git: {
        createBlob: {
            method: "POST",
            params: {
                content: { required: true, type: "string" },
                encoding: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/blobs"
        },
        createCommit: {
            method: "POST",
            params: {
                author: { type: "object" },
                "author.date": { type: "string" },
                "author.email": { type: "string" },
                "author.name": { type: "string" },
                committer: { type: "object" },
                "committer.date": { type: "string" },
                "committer.email": { type: "string" },
                "committer.name": { type: "string" },
                message: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                parents: { required: true, type: "string[]" },
                repo: { required: true, type: "string" },
                signature: { type: "string" },
                tree: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/commits"
        },
        createRef: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/refs"
        },
        createTag: {
            method: "POST",
            params: {
                message: { required: true, type: "string" },
                object: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                tag: { required: true, type: "string" },
                tagger: { type: "object" },
                "tagger.date": { type: "string" },
                "tagger.email": { type: "string" },
                "tagger.name": { type: "string" },
                type: {
                    enum: ["commit", "tree", "blob"],
                    required: true,
                    type: "string"
                }
            },
            url: "/repos/:owner/:repo/git/tags"
        },
        createTree: {
            method: "POST",
            params: {
                base_tree: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                tree: { required: true, type: "object[]" },
                "tree[].content": { type: "string" },
                "tree[].mode": {
                    enum: ["100644", "100755", "040000", "160000", "120000"],
                    type: "string"
                },
                "tree[].path": { type: "string" },
                "tree[].sha": { allowNull: true, type: "string" },
                "tree[].type": { enum: ["blob", "tree", "commit"], type: "string" }
            },
            url: "/repos/:owner/:repo/git/trees"
        },
        deleteRef: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/refs/:ref"
        },
        getBlob: {
            method: "GET",
            params: {
                file_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/blobs/:file_sha"
        },
        getCommit: {
            method: "GET",
            params: {
                commit_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/commits/:commit_sha"
        },
        getRef: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/ref/:ref"
        },
        getTag: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                tag_sha: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/tags/:tag_sha"
        },
        getTree: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                recursive: { enum: ["1"], type: "integer" },
                repo: { required: true, type: "string" },
                tree_sha: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/trees/:tree_sha"
        },
        listMatchingRefs: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/matching-refs/:ref"
        },
        listRefs: {
            method: "GET",
            params: {
                namespace: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/refs/:namespace"
        },
        updateRef: {
            method: "PATCH",
            params: {
                force: { type: "boolean" },
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/git/refs/:ref"
        }
    },
    gitignore: {
        getTemplate: {
            method: "GET",
            params: { name: { required: true, type: "string" } },
            url: "/gitignore/templates/:name"
        },
        listTemplates: { method: "GET", params: {}, url: "/gitignore/templates" }
    },
    interactions: {
        addOrUpdateRestrictionsForOrg: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "PUT",
            params: {
                limit: {
                    enum: ["existing_users", "contributors_only", "collaborators_only"],
                    required: true,
                    type: "string"
                },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/interaction-limits"
        },
        addOrUpdateRestrictionsForRepo: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "PUT",
            params: {
                limit: {
                    enum: ["existing_users", "contributors_only", "collaborators_only"],
                    required: true,
                    type: "string"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/interaction-limits"
        },
        getRestrictionsForOrg: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org/interaction-limits"
        },
        getRestrictionsForRepo: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/interaction-limits"
        },
        removeRestrictionsForOrg: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "DELETE",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org/interaction-limits"
        },
        removeRestrictionsForRepo: {
            headers: { accept: "application/vnd.github.sombra-preview+json" },
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/interaction-limits"
        }
    },
    issues: {
        addAssignees: {
            method: "POST",
            params: {
                assignees: { type: "string[]" },
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/assignees"
        },
        addLabels: {
            method: "POST",
            params: {
                issue_number: { required: true, type: "integer" },
                labels: { required: true, type: "string[]" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/labels"
        },
        checkAssignee: {
            method: "GET",
            params: {
                assignee: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/assignees/:assignee"
        },
        create: {
            method: "POST",
            params: {
                assignee: { type: "string" },
                assignees: { type: "string[]" },
                body: { type: "string" },
                labels: { type: "string[]" },
                milestone: { type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                title: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues"
        },
        createComment: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/comments"
        },
        createLabel: {
            method: "POST",
            params: {
                color: { required: true, type: "string" },
                description: { type: "string" },
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/labels"
        },
        createMilestone: {
            method: "POST",
            params: {
                description: { type: "string" },
                due_on: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                state: { enum: ["open", "closed"], type: "string" },
                title: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/milestones"
        },
        deleteComment: {
            method: "DELETE",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments/:comment_id"
        },
        deleteLabel: {
            method: "DELETE",
            params: {
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/labels/:name"
        },
        deleteMilestone: {
            method: "DELETE",
            params: {
                milestone_number: { required: true, type: "integer" },
                number: {
                    alias: "milestone_number",
                    deprecated: true,
                    type: "integer"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/milestones/:milestone_number"
        },
        get: {
            method: "GET",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number"
        },
        getComment: {
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments/:comment_id"
        },
        getEvent: {
            method: "GET",
            params: {
                event_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/events/:event_id"
        },
        getLabel: {
            method: "GET",
            params: {
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/labels/:name"
        },
        getMilestone: {
            method: "GET",
            params: {
                milestone_number: { required: true, type: "integer" },
                number: {
                    alias: "milestone_number",
                    deprecated: true,
                    type: "integer"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/milestones/:milestone_number"
        },
        list: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                filter: {
                    enum: ["assigned", "created", "mentioned", "subscribed", "all"],
                    type: "string"
                },
                labels: { type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" },
                sort: { enum: ["created", "updated", "comments"], type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/issues"
        },
        listAssignees: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/assignees"
        },
        listComments: {
            method: "GET",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                since: { type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/comments"
        },
        listCommentsForRepo: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                since: { type: "string" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments"
        },
        listEvents: {
            method: "GET",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/events"
        },
        listEventsForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/events"
        },
        listEventsForTimeline: {
            headers: { accept: "application/vnd.github.mockingbird-preview+json" },
            method: "GET",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/timeline"
        },
        listForAuthenticatedUser: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                filter: {
                    enum: ["assigned", "created", "mentioned", "subscribed", "all"],
                    type: "string"
                },
                labels: { type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" },
                sort: { enum: ["created", "updated", "comments"], type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/user/issues"
        },
        listForOrg: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                filter: {
                    enum: ["assigned", "created", "mentioned", "subscribed", "all"],
                    type: "string"
                },
                labels: { type: "string" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" },
                sort: { enum: ["created", "updated", "comments"], type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/orgs/:org/issues"
        },
        listForRepo: {
            method: "GET",
            params: {
                assignee: { type: "string" },
                creator: { type: "string" },
                direction: { enum: ["asc", "desc"], type: "string" },
                labels: { type: "string" },
                mentioned: { type: "string" },
                milestone: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                since: { type: "string" },
                sort: { enum: ["created", "updated", "comments"], type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/repos/:owner/:repo/issues"
        },
        listLabelsForMilestone: {
            method: "GET",
            params: {
                milestone_number: { required: true, type: "integer" },
                number: {
                    alias: "milestone_number",
                    deprecated: true,
                    type: "integer"
                },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/milestones/:milestone_number/labels"
        },
        listLabelsForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/labels"
        },
        listLabelsOnIssue: {
            method: "GET",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/labels"
        },
        listMilestonesForRepo: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                sort: { enum: ["due_on", "completeness"], type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/repos/:owner/:repo/milestones"
        },
        lock: {
            method: "PUT",
            params: {
                issue_number: { required: true, type: "integer" },
                lock_reason: {
                    enum: ["off-topic", "too heated", "resolved", "spam"],
                    type: "string"
                },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/lock"
        },
        removeAssignees: {
            method: "DELETE",
            params: {
                assignees: { type: "string[]" },
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/assignees"
        },
        removeLabel: {
            method: "DELETE",
            params: {
                issue_number: { required: true, type: "integer" },
                name: { required: true, type: "string" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/labels/:name"
        },
        removeLabels: {
            method: "DELETE",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/labels"
        },
        replaceLabels: {
            method: "PUT",
            params: {
                issue_number: { required: true, type: "integer" },
                labels: { type: "string[]" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/labels"
        },
        unlock: {
            method: "DELETE",
            params: {
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/lock"
        },
        update: {
            method: "PATCH",
            params: {
                assignee: { type: "string" },
                assignees: { type: "string[]" },
                body: { type: "string" },
                issue_number: { required: true, type: "integer" },
                labels: { type: "string[]" },
                milestone: { allowNull: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                state: { enum: ["open", "closed"], type: "string" },
                title: { type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number"
        },
        updateComment: {
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments/:comment_id"
        },
        updateLabel: {
            method: "PATCH",
            params: {
                color: { type: "string" },
                current_name: { required: true, type: "string" },
                description: { type: "string" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/labels/:current_name"
        },
        updateMilestone: {
            method: "PATCH",
            params: {
                description: { type: "string" },
                due_on: { type: "string" },
                milestone_number: { required: true, type: "integer" },
                number: {
                    alias: "milestone_number",
                    deprecated: true,
                    type: "integer"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                state: { enum: ["open", "closed"], type: "string" },
                title: { type: "string" }
            },
            url: "/repos/:owner/:repo/milestones/:milestone_number"
        }
    },
    licenses: {
        get: {
            method: "GET",
            params: { license: { required: true, type: "string" } },
            url: "/licenses/:license"
        },
        getForRepo: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/license"
        },
        list: {
            deprecated: "octokit.licenses.list() has been renamed to octokit.licenses.listCommonlyUsed() (2019-03-05)",
            method: "GET",
            params: {},
            url: "/licenses"
        },
        listCommonlyUsed: { method: "GET", params: {}, url: "/licenses" }
    },
    markdown: {
        render: {
            method: "POST",
            params: {
                context: { type: "string" },
                mode: { enum: ["markdown", "gfm"], type: "string" },
                text: { required: true, type: "string" }
            },
            url: "/markdown"
        },
        renderRaw: {
            headers: { "content-type": "text/plain; charset=utf-8" },
            method: "POST",
            params: { data: { mapTo: "data", required: true, type: "string" } },
            url: "/markdown/raw"
        }
    },
    meta: { get: { method: "GET", params: {}, url: "/meta" } },
    migrations: {
        cancelImport: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/import"
        },
        deleteArchiveForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "DELETE",
            params: { migration_id: { required: true, type: "integer" } },
            url: "/user/migrations/:migration_id/archive"
        },
        deleteArchiveForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "DELETE",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/migrations/:migration_id/archive"
        },
        downloadArchiveForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/migrations/:migration_id/archive"
        },
        getArchiveForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: { migration_id: { required: true, type: "integer" } },
            url: "/user/migrations/:migration_id/archive"
        },
        getArchiveForOrg: {
            deprecated: "octokit.migrations.getArchiveForOrg() has been renamed to octokit.migrations.downloadArchiveForOrg() (2020-01-27)",
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/migrations/:migration_id/archive"
        },
        getCommitAuthors: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                since: { type: "string" }
            },
            url: "/repos/:owner/:repo/import/authors"
        },
        getImportProgress: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/import"
        },
        getLargeFiles: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/import/large_files"
        },
        getStatusForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: { migration_id: { required: true, type: "integer" } },
            url: "/user/migrations/:migration_id"
        },
        getStatusForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/migrations/:migration_id"
        },
        listForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/migrations"
        },
        listForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/migrations"
        },
        listReposForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/migrations/:migration_id/repositories"
        },
        listReposForUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "GET",
            params: {
                migration_id: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/user/:migration_id/repositories"
        },
        mapCommitAuthor: {
            method: "PATCH",
            params: {
                author_id: { required: true, type: "integer" },
                email: { type: "string" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/import/authors/:author_id"
        },
        setLfsPreference: {
            method: "PATCH",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                use_lfs: { enum: ["opt_in", "opt_out"], required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/import/lfs"
        },
        startForAuthenticatedUser: {
            method: "POST",
            params: {
                exclude_attachments: { type: "boolean" },
                lock_repositories: { type: "boolean" },
                repositories: { required: true, type: "string[]" }
            },
            url: "/user/migrations"
        },
        startForOrg: {
            method: "POST",
            params: {
                exclude_attachments: { type: "boolean" },
                lock_repositories: { type: "boolean" },
                org: { required: true, type: "string" },
                repositories: { required: true, type: "string[]" }
            },
            url: "/orgs/:org/migrations"
        },
        startImport: {
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                tfvc_project: { type: "string" },
                vcs: {
                    enum: ["subversion", "git", "mercurial", "tfvc"],
                    type: "string"
                },
                vcs_password: { type: "string" },
                vcs_url: { required: true, type: "string" },
                vcs_username: { type: "string" }
            },
            url: "/repos/:owner/:repo/import"
        },
        unlockRepoForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "DELETE",
            params: {
                migration_id: { required: true, type: "integer" },
                repo_name: { required: true, type: "string" }
            },
            url: "/user/migrations/:migration_id/repos/:repo_name/lock"
        },
        unlockRepoForOrg: {
            headers: { accept: "application/vnd.github.wyandotte-preview+json" },
            method: "DELETE",
            params: {
                migration_id: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                repo_name: { required: true, type: "string" }
            },
            url: "/orgs/:org/migrations/:migration_id/repos/:repo_name/lock"
        },
        updateImport: {
            method: "PATCH",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                vcs_password: { type: "string" },
                vcs_username: { type: "string" }
            },
            url: "/repos/:owner/:repo/import"
        }
    },
    oauthAuthorizations: {
        checkAuthorization: {
            deprecated: "octokit.oauthAuthorizations.checkAuthorization() has been renamed to octokit.apps.checkAuthorization() (2019-11-05)",
            method: "GET",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        createAuthorization: {
            deprecated: "octokit.oauthAuthorizations.createAuthorization() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#create-a-new-authorization",
            method: "POST",
            params: {
                client_id: { type: "string" },
                client_secret: { type: "string" },
                fingerprint: { type: "string" },
                note: { required: true, type: "string" },
                note_url: { type: "string" },
                scopes: { type: "string[]" }
            },
            url: "/authorizations"
        },
        deleteAuthorization: {
            deprecated: "octokit.oauthAuthorizations.deleteAuthorization() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#delete-an-authorization",
            method: "DELETE",
            params: { authorization_id: { required: true, type: "integer" } },
            url: "/authorizations/:authorization_id"
        },
        deleteGrant: {
            deprecated: "octokit.oauthAuthorizations.deleteGrant() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#delete-a-grant",
            method: "DELETE",
            params: { grant_id: { required: true, type: "integer" } },
            url: "/applications/grants/:grant_id"
        },
        getAuthorization: {
            deprecated: "octokit.oauthAuthorizations.getAuthorization() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#get-a-single-authorization",
            method: "GET",
            params: { authorization_id: { required: true, type: "integer" } },
            url: "/authorizations/:authorization_id"
        },
        getGrant: {
            deprecated: "octokit.oauthAuthorizations.getGrant() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#get-a-single-grant",
            method: "GET",
            params: { grant_id: { required: true, type: "integer" } },
            url: "/applications/grants/:grant_id"
        },
        getOrCreateAuthorizationForApp: {
            deprecated: "octokit.oauthAuthorizations.getOrCreateAuthorizationForApp() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#get-or-create-an-authorization-for-a-specific-app",
            method: "PUT",
            params: {
                client_id: { required: true, type: "string" },
                client_secret: { required: true, type: "string" },
                fingerprint: { type: "string" },
                note: { type: "string" },
                note_url: { type: "string" },
                scopes: { type: "string[]" }
            },
            url: "/authorizations/clients/:client_id"
        },
        getOrCreateAuthorizationForAppAndFingerprint: {
            deprecated: "octokit.oauthAuthorizations.getOrCreateAuthorizationForAppAndFingerprint() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#get-or-create-an-authorization-for-a-specific-app-and-fingerprint",
            method: "PUT",
            params: {
                client_id: { required: true, type: "string" },
                client_secret: { required: true, type: "string" },
                fingerprint: { required: true, type: "string" },
                note: { type: "string" },
                note_url: { type: "string" },
                scopes: { type: "string[]" }
            },
            url: "/authorizations/clients/:client_id/:fingerprint"
        },
        getOrCreateAuthorizationForAppFingerprint: {
            deprecated: "octokit.oauthAuthorizations.getOrCreateAuthorizationForAppFingerprint() has been renamed to octokit.oauthAuthorizations.getOrCreateAuthorizationForAppAndFingerprint() (2018-12-27)",
            method: "PUT",
            params: {
                client_id: { required: true, type: "string" },
                client_secret: { required: true, type: "string" },
                fingerprint: { required: true, type: "string" },
                note: { type: "string" },
                note_url: { type: "string" },
                scopes: { type: "string[]" }
            },
            url: "/authorizations/clients/:client_id/:fingerprint"
        },
        listAuthorizations: {
            deprecated: "octokit.oauthAuthorizations.listAuthorizations() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#list-your-authorizations",
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/authorizations"
        },
        listGrants: {
            deprecated: "octokit.oauthAuthorizations.listGrants() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#list-your-grants",
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/applications/grants"
        },
        resetAuthorization: {
            deprecated: "octokit.oauthAuthorizations.resetAuthorization() has been renamed to octokit.apps.resetAuthorization() (2019-11-05)",
            method: "POST",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        revokeAuthorizationForApplication: {
            deprecated: "octokit.oauthAuthorizations.revokeAuthorizationForApplication() has been renamed to octokit.apps.revokeAuthorizationForApplication() (2019-11-05)",
            method: "DELETE",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/tokens/:access_token"
        },
        revokeGrantForApplication: {
            deprecated: "octokit.oauthAuthorizations.revokeGrantForApplication() has been renamed to octokit.apps.revokeGrantForApplication() (2019-11-05)",
            method: "DELETE",
            params: {
                access_token: { required: true, type: "string" },
                client_id: { required: true, type: "string" }
            },
            url: "/applications/:client_id/grants/:access_token"
        },
        updateAuthorization: {
            deprecated: "octokit.oauthAuthorizations.updateAuthorization() is deprecated, see https://developer.github.com/v3/oauth_authorizations/#update-an-existing-authorization",
            method: "PATCH",
            params: {
                add_scopes: { type: "string[]" },
                authorization_id: { required: true, type: "integer" },
                fingerprint: { type: "string" },
                note: { type: "string" },
                note_url: { type: "string" },
                remove_scopes: { type: "string[]" },
                scopes: { type: "string[]" }
            },
            url: "/authorizations/:authorization_id"
        }
    },
    orgs: {
        addOrUpdateMembership: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                role: { enum: ["admin", "member"], type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/memberships/:username"
        },
        blockUser: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/blocks/:username"
        },
        checkBlockedUser: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/blocks/:username"
        },
        checkMembership: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/members/:username"
        },
        checkPublicMembership: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/public_members/:username"
        },
        concealMembership: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/public_members/:username"
        },
        convertMemberToOutsideCollaborator: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/outside_collaborators/:username"
        },
        createHook: {
            method: "POST",
            params: {
                active: { type: "boolean" },
                config: { required: true, type: "object" },
                "config.content_type": { type: "string" },
                "config.insecure_ssl": { type: "string" },
                "config.secret": { type: "string" },
                "config.url": { required: true, type: "string" },
                events: { type: "string[]" },
                name: { required: true, type: "string" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/hooks"
        },
        createInvitation: {
            method: "POST",
            params: {
                email: { type: "string" },
                invitee_id: { type: "integer" },
                org: { required: true, type: "string" },
                role: {
                    enum: ["admin", "direct_member", "billing_manager"],
                    type: "string"
                },
                team_ids: { type: "integer[]" }
            },
            url: "/orgs/:org/invitations"
        },
        deleteHook: {
            method: "DELETE",
            params: {
                hook_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/hooks/:hook_id"
        },
        get: {
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org"
        },
        getHook: {
            method: "GET",
            params: {
                hook_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/hooks/:hook_id"
        },
        getMembership: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/memberships/:username"
        },
        getMembershipForAuthenticatedUser: {
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/user/memberships/orgs/:org"
        },
        list: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "integer" }
            },
            url: "/organizations"
        },
        listBlockedUsers: {
            method: "GET",
            params: { org: { required: true, type: "string" } },
            url: "/orgs/:org/blocks"
        },
        listForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/orgs"
        },
        listForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/orgs"
        },
        listHooks: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/hooks"
        },
        listInstallations: {
            headers: { accept: "application/vnd.github.machine-man-preview+json" },
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/installations"
        },
        listInvitationTeams: {
            method: "GET",
            params: {
                invitation_id: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/invitations/:invitation_id/teams"
        },
        listMembers: {
            method: "GET",
            params: {
                filter: { enum: ["2fa_disabled", "all"], type: "string" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                role: { enum: ["all", "admin", "member"], type: "string" }
            },
            url: "/orgs/:org/members"
        },
        listMemberships: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                state: { enum: ["active", "pending"], type: "string" }
            },
            url: "/user/memberships/orgs"
        },
        listOutsideCollaborators: {
            method: "GET",
            params: {
                filter: { enum: ["2fa_disabled", "all"], type: "string" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/outside_collaborators"
        },
        listPendingInvitations: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/invitations"
        },
        listPublicMembers: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/public_members"
        },
        pingHook: {
            method: "POST",
            params: {
                hook_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/hooks/:hook_id/pings"
        },
        publicizeMembership: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/public_members/:username"
        },
        removeMember: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/members/:username"
        },
        removeMembership: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/memberships/:username"
        },
        removeOutsideCollaborator: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/outside_collaborators/:username"
        },
        unblockUser: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/blocks/:username"
        },
        update: {
            method: "PATCH",
            params: {
                billing_email: { type: "string" },
                company: { type: "string" },
                default_repository_permission: {
                    enum: ["read", "write", "admin", "none"],
                    type: "string"
                },
                description: { type: "string" },
                email: { type: "string" },
                has_organization_projects: { type: "boolean" },
                has_repository_projects: { type: "boolean" },
                location: { type: "string" },
                members_allowed_repository_creation_type: {
                    enum: ["all", "private", "none"],
                    type: "string"
                },
                members_can_create_internal_repositories: { type: "boolean" },
                members_can_create_private_repositories: { type: "boolean" },
                members_can_create_public_repositories: { type: "boolean" },
                members_can_create_repositories: { type: "boolean" },
                name: { type: "string" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org"
        },
        updateHook: {
            method: "PATCH",
            params: {
                active: { type: "boolean" },
                config: { type: "object" },
                "config.content_type": { type: "string" },
                "config.insecure_ssl": { type: "string" },
                "config.secret": { type: "string" },
                "config.url": { required: true, type: "string" },
                events: { type: "string[]" },
                hook_id: { required: true, type: "integer" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/hooks/:hook_id"
        },
        updateMembership: {
            method: "PATCH",
            params: {
                org: { required: true, type: "string" },
                state: { enum: ["active"], required: true, type: "string" }
            },
            url: "/user/memberships/orgs/:org"
        }
    },
    projects: {
        addCollaborator: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PUT",
            params: {
                permission: { enum: ["read", "write", "admin"], type: "string" },
                project_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/projects/:project_id/collaborators/:username"
        },
        createCard: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                column_id: { required: true, type: "integer" },
                content_id: { type: "integer" },
                content_type: { type: "string" },
                note: { type: "string" }
            },
            url: "/projects/columns/:column_id/cards"
        },
        createColumn: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                name: { required: true, type: "string" },
                project_id: { required: true, type: "integer" }
            },
            url: "/projects/:project_id/columns"
        },
        createForAuthenticatedUser: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                body: { type: "string" },
                name: { required: true, type: "string" }
            },
            url: "/user/projects"
        },
        createForOrg: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                body: { type: "string" },
                name: { required: true, type: "string" },
                org: { required: true, type: "string" }
            },
            url: "/orgs/:org/projects"
        },
        createForRepo: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                body: { type: "string" },
                name: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/projects"
        },
        delete: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "DELETE",
            params: { project_id: { required: true, type: "integer" } },
            url: "/projects/:project_id"
        },
        deleteCard: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "DELETE",
            params: { card_id: { required: true, type: "integer" } },
            url: "/projects/columns/cards/:card_id"
        },
        deleteColumn: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "DELETE",
            params: { column_id: { required: true, type: "integer" } },
            url: "/projects/columns/:column_id"
        },
        get: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: { project_id: { required: true, type: "integer" } },
            url: "/projects/:project_id"
        },
        getCard: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: { card_id: { required: true, type: "integer" } },
            url: "/projects/columns/cards/:card_id"
        },
        getColumn: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: { column_id: { required: true, type: "integer" } },
            url: "/projects/columns/:column_id"
        },
        listCards: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                archived_state: {
                    enum: ["all", "archived", "not_archived"],
                    type: "string"
                },
                column_id: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/projects/columns/:column_id/cards"
        },
        listCollaborators: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                affiliation: { enum: ["outside", "direct", "all"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                project_id: { required: true, type: "integer" }
            },
            url: "/projects/:project_id/collaborators"
        },
        listColumns: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                project_id: { required: true, type: "integer" }
            },
            url: "/projects/:project_id/columns"
        },
        listForOrg: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/orgs/:org/projects"
        },
        listForRepo: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/repos/:owner/:repo/projects"
        },
        listForUser: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                state: { enum: ["open", "closed", "all"], type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/projects"
        },
        moveCard: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                card_id: { required: true, type: "integer" },
                column_id: { type: "integer" },
                position: {
                    required: true,
                    type: "string",
                    validation: "^(top|bottom|after:\\d+)$"
                }
            },
            url: "/projects/columns/cards/:card_id/moves"
        },
        moveColumn: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "POST",
            params: {
                column_id: { required: true, type: "integer" },
                position: {
                    required: true,
                    type: "string",
                    validation: "^(first|last|after:\\d+)$"
                }
            },
            url: "/projects/columns/:column_id/moves"
        },
        removeCollaborator: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "DELETE",
            params: {
                project_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/projects/:project_id/collaborators/:username"
        },
        reviewUserPermissionLevel: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                project_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/projects/:project_id/collaborators/:username/permission"
        },
        update: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PATCH",
            params: {
                body: { type: "string" },
                name: { type: "string" },
                organization_permission: { type: "string" },
                private: { type: "boolean" },
                project_id: { required: true, type: "integer" },
                state: { enum: ["open", "closed"], type: "string" }
            },
            url: "/projects/:project_id"
        },
        updateCard: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PATCH",
            params: {
                archived: { type: "boolean" },
                card_id: { required: true, type: "integer" },
                note: { type: "string" }
            },
            url: "/projects/columns/cards/:card_id"
        },
        updateColumn: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PATCH",
            params: {
                column_id: { required: true, type: "integer" },
                name: { required: true, type: "string" }
            },
            url: "/projects/columns/:column_id"
        }
    },
    pulls: {
        checkIfMerged: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/merge"
        },
        create: {
            method: "POST",
            params: {
                base: { required: true, type: "string" },
                body: { type: "string" },
                draft: { type: "boolean" },
                head: { required: true, type: "string" },
                maintainer_can_modify: { type: "boolean" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                title: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls"
        },
        createComment: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                commit_id: { required: true, type: "string" },
                in_reply_to: {
                    deprecated: true,
                    description: "The comment ID to reply to. **Note**: This must be the ID of a top-level comment, not a reply to that comment. Replies to replies are not supported.",
                    type: "integer"
                },
                line: { type: "integer" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                position: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                side: { enum: ["LEFT", "RIGHT"], type: "string" },
                start_line: { type: "integer" },
                start_side: { enum: ["LEFT", "RIGHT", "side"], type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/comments"
        },
        createCommentReply: {
            deprecated: "octokit.pulls.createCommentReply() has been renamed to octokit.pulls.createComment() (2019-09-09)",
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                commit_id: { required: true, type: "string" },
                in_reply_to: {
                    deprecated: true,
                    description: "The comment ID to reply to. **Note**: This must be the ID of a top-level comment, not a reply to that comment. Replies to replies are not supported.",
                    type: "integer"
                },
                line: { type: "integer" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                position: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                side: { enum: ["LEFT", "RIGHT"], type: "string" },
                start_line: { type: "integer" },
                start_side: { enum: ["LEFT", "RIGHT", "side"], type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/comments"
        },
        createFromIssue: {
            deprecated: "octokit.pulls.createFromIssue() is deprecated, see https://developer.github.com/v3/pulls/#create-a-pull-request",
            method: "POST",
            params: {
                base: { required: true, type: "string" },
                draft: { type: "boolean" },
                head: { required: true, type: "string" },
                issue: { required: true, type: "integer" },
                maintainer_can_modify: { type: "boolean" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls"
        },
        createReview: {
            method: "POST",
            params: {
                body: { type: "string" },
                comments: { type: "object[]" },
                "comments[].body": { required: true, type: "string" },
                "comments[].path": { required: true, type: "string" },
                "comments[].position": { required: true, type: "integer" },
                commit_id: { type: "string" },
                event: {
                    enum: ["APPROVE", "REQUEST_CHANGES", "COMMENT"],
                    type: "string"
                },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews"
        },
        createReviewCommentReply: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/comments/:comment_id/replies"
        },
        createReviewRequest: {
            method: "POST",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                reviewers: { type: "string[]" },
                team_reviewers: { type: "string[]" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/requested_reviewers"
        },
        deleteComment: {
            method: "DELETE",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments/:comment_id"
        },
        deletePendingReview: {
            method: "DELETE",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id"
        },
        deleteReviewRequest: {
            method: "DELETE",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                reviewers: { type: "string[]" },
                team_reviewers: { type: "string[]" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/requested_reviewers"
        },
        dismissReview: {
            method: "PUT",
            params: {
                message: { required: true, type: "string" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id/dismissals"
        },
        get: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number"
        },
        getComment: {
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments/:comment_id"
        },
        getCommentsForReview: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id/comments"
        },
        getReview: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id"
        },
        list: {
            method: "GET",
            params: {
                base: { type: "string" },
                direction: { enum: ["asc", "desc"], type: "string" },
                head: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                sort: {
                    enum: ["created", "updated", "popularity", "long-running"],
                    type: "string"
                },
                state: { enum: ["open", "closed", "all"], type: "string" }
            },
            url: "/repos/:owner/:repo/pulls"
        },
        listComments: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                since: { type: "string" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/comments"
        },
        listCommentsForRepo: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                since: { type: "string" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments"
        },
        listCommits: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/commits"
        },
        listFiles: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/files"
        },
        listReviewRequests: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/requested_reviewers"
        },
        listReviews: {
            method: "GET",
            params: {
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews"
        },
        merge: {
            method: "PUT",
            params: {
                commit_message: { type: "string" },
                commit_title: { type: "string" },
                merge_method: { enum: ["merge", "squash", "rebase"], type: "string" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                sha: { type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/merge"
        },
        submitReview: {
            method: "POST",
            params: {
                body: { type: "string" },
                event: {
                    enum: ["APPROVE", "REQUEST_CHANGES", "COMMENT"],
                    required: true,
                    type: "string"
                },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id/events"
        },
        update: {
            method: "PATCH",
            params: {
                base: { type: "string" },
                body: { type: "string" },
                maintainer_can_modify: { type: "boolean" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                state: { enum: ["open", "closed"], type: "string" },
                title: { type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number"
        },
        updateBranch: {
            headers: { accept: "application/vnd.github.lydian-preview+json" },
            method: "PUT",
            params: {
                expected_head_sha: { type: "string" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/update-branch"
        },
        updateComment: {
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments/:comment_id"
        },
        updateReview: {
            method: "PUT",
            params: {
                body: { required: true, type: "string" },
                number: { alias: "pull_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                pull_number: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                review_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/pulls/:pull_number/reviews/:review_id"
        }
    },
    rateLimit: { get: { method: "GET", params: {}, url: "/rate_limit" } },
    reactions: {
        createForCommitComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments/:comment_id/reactions"
        },
        createForIssue: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/reactions"
        },
        createForIssueComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments/:comment_id/reactions"
        },
        createForPullRequestReviewComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments/:comment_id/reactions"
        },
        createForTeamDiscussion: {
            deprecated: "octokit.reactions.createForTeamDiscussion() has been renamed to octokit.reactions.createForTeamDiscussionLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/reactions"
        },
        createForTeamDiscussionComment: {
            deprecated: "octokit.reactions.createForTeamDiscussionComment() has been renamed to octokit.reactions.createForTeamDiscussionCommentLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        createForTeamDiscussionCommentInOrg: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        createForTeamDiscussionCommentLegacy: {
            deprecated: "octokit.reactions.createForTeamDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/reactions/#create-reaction-for-a-team-discussion-comment-legacy",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        createForTeamDiscussionInOrg: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/reactions"
        },
        createForTeamDiscussionLegacy: {
            deprecated: "octokit.reactions.createForTeamDiscussionLegacy() is deprecated, see https://developer.github.com/v3/reactions/#create-reaction-for-a-team-discussion-legacy",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "POST",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    required: true,
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/reactions"
        },
        delete: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "DELETE",
            params: { reaction_id: { required: true, type: "integer" } },
            url: "/reactions/:reaction_id"
        },
        listForCommitComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments/:comment_id/reactions"
        },
        listForIssue: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                issue_number: { required: true, type: "integer" },
                number: { alias: "issue_number", deprecated: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/:issue_number/reactions"
        },
        listForIssueComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/issues/comments/:comment_id/reactions"
        },
        listForPullRequestReviewComment: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pulls/comments/:comment_id/reactions"
        },
        listForTeamDiscussion: {
            deprecated: "octokit.reactions.listForTeamDiscussion() has been renamed to octokit.reactions.listForTeamDiscussionLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/reactions"
        },
        listForTeamDiscussionComment: {
            deprecated: "octokit.reactions.listForTeamDiscussionComment() has been renamed to octokit.reactions.listForTeamDiscussionCommentLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        listForTeamDiscussionCommentInOrg: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        listForTeamDiscussionCommentLegacy: {
            deprecated: "octokit.reactions.listForTeamDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/reactions/#list-reactions-for-a-team-discussion-comment-legacy",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number/reactions"
        },
        listForTeamDiscussionInOrg: {
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/reactions"
        },
        listForTeamDiscussionLegacy: {
            deprecated: "octokit.reactions.listForTeamDiscussionLegacy() is deprecated, see https://developer.github.com/v3/reactions/#list-reactions-for-a-team-discussion-legacy",
            headers: { accept: "application/vnd.github.squirrel-girl-preview+json" },
            method: "GET",
            params: {
                content: {
                    enum: [
                        "+1",
                        "-1",
                        "laugh",
                        "confused",
                        "heart",
                        "hooray",
                        "rocket",
                        "eyes"
                    ],
                    type: "string"
                },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/reactions"
        }
    },
    repos: {
        acceptInvitation: {
            method: "PATCH",
            params: { invitation_id: { required: true, type: "integer" } },
            url: "/user/repository_invitations/:invitation_id"
        },
        addCollaborator: {
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                repo: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/collaborators/:username"
        },
        addDeployKey: {
            method: "POST",
            params: {
                key: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                read_only: { type: "boolean" },
                repo: { required: true, type: "string" },
                title: { type: "string" }
            },
            url: "/repos/:owner/:repo/keys"
        },
        addProtectedBranchAdminEnforcement: {
            method: "POST",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/enforce_admins"
        },
        addProtectedBranchAppRestrictions: {
            method: "POST",
            params: {
                apps: { mapTo: "data", required: true, type: "string[]" },
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/apps"
        },
        addProtectedBranchRequiredSignatures: {
            headers: { accept: "application/vnd.github.zzzax-preview+json" },
            method: "POST",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_signatures"
        },
        addProtectedBranchRequiredStatusChecksContexts: {
            method: "POST",
            params: {
                branch: { required: true, type: "string" },
                contexts: { mapTo: "data", required: true, type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks/contexts"
        },
        addProtectedBranchTeamRestrictions: {
            method: "POST",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                teams: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        addProtectedBranchUserRestrictions: {
            method: "POST",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                users: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        checkCollaborator: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/collaborators/:username"
        },
        checkVulnerabilityAlerts: {
            headers: { accept: "application/vnd.github.dorian-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/vulnerability-alerts"
        },
        compareCommits: {
            method: "GET",
            params: {
                base: { required: true, type: "string" },
                head: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/compare/:base...:head"
        },
        createCommitComment: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                commit_sha: { required: true, type: "string" },
                line: { type: "integer" },
                owner: { required: true, type: "string" },
                path: { type: "string" },
                position: { type: "integer" },
                repo: { required: true, type: "string" },
                sha: { alias: "commit_sha", deprecated: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:commit_sha/comments"
        },
        createDeployment: {
            method: "POST",
            params: {
                auto_merge: { type: "boolean" },
                description: { type: "string" },
                environment: { type: "string" },
                owner: { required: true, type: "string" },
                payload: { type: "string" },
                production_environment: { type: "boolean" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                required_contexts: { type: "string[]" },
                task: { type: "string" },
                transient_environment: { type: "boolean" }
            },
            url: "/repos/:owner/:repo/deployments"
        },
        createDeploymentStatus: {
            method: "POST",
            params: {
                auto_inactive: { type: "boolean" },
                deployment_id: { required: true, type: "integer" },
                description: { type: "string" },
                environment: { enum: ["production", "staging", "qa"], type: "string" },
                environment_url: { type: "string" },
                log_url: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                state: {
                    enum: [
                        "error",
                        "failure",
                        "inactive",
                        "in_progress",
                        "queued",
                        "pending",
                        "success"
                    ],
                    required: true,
                    type: "string"
                },
                target_url: { type: "string" }
            },
            url: "/repos/:owner/:repo/deployments/:deployment_id/statuses"
        },
        createDispatchEvent: {
            method: "POST",
            params: {
                client_payload: { type: "object" },
                event_type: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/dispatches"
        },
        createFile: {
            deprecated: "octokit.repos.createFile() has been renamed to octokit.repos.createOrUpdateFile() (2019-06-07)",
            method: "PUT",
            params: {
                author: { type: "object" },
                "author.email": { required: true, type: "string" },
                "author.name": { required: true, type: "string" },
                branch: { type: "string" },
                committer: { type: "object" },
                "committer.email": { required: true, type: "string" },
                "committer.name": { required: true, type: "string" },
                content: { required: true, type: "string" },
                message: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { type: "string" }
            },
            url: "/repos/:owner/:repo/contents/:path"
        },
        createForAuthenticatedUser: {
            method: "POST",
            params: {
                allow_merge_commit: { type: "boolean" },
                allow_rebase_merge: { type: "boolean" },
                allow_squash_merge: { type: "boolean" },
                auto_init: { type: "boolean" },
                delete_branch_on_merge: { type: "boolean" },
                description: { type: "string" },
                gitignore_template: { type: "string" },
                has_issues: { type: "boolean" },
                has_projects: { type: "boolean" },
                has_wiki: { type: "boolean" },
                homepage: { type: "string" },
                is_template: { type: "boolean" },
                license_template: { type: "string" },
                name: { required: true, type: "string" },
                private: { type: "boolean" },
                team_id: { type: "integer" },
                visibility: {
                    enum: ["public", "private", "visibility", "internal"],
                    type: "string"
                }
            },
            url: "/user/repos"
        },
        createFork: {
            method: "POST",
            params: {
                organization: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/forks"
        },
        createHook: {
            method: "POST",
            params: {
                active: { type: "boolean" },
                config: { required: true, type: "object" },
                "config.content_type": { type: "string" },
                "config.insecure_ssl": { type: "string" },
                "config.secret": { type: "string" },
                "config.url": { required: true, type: "string" },
                events: { type: "string[]" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks"
        },
        createInOrg: {
            method: "POST",
            params: {
                allow_merge_commit: { type: "boolean" },
                allow_rebase_merge: { type: "boolean" },
                allow_squash_merge: { type: "boolean" },
                auto_init: { type: "boolean" },
                delete_branch_on_merge: { type: "boolean" },
                description: { type: "string" },
                gitignore_template: { type: "string" },
                has_issues: { type: "boolean" },
                has_projects: { type: "boolean" },
                has_wiki: { type: "boolean" },
                homepage: { type: "string" },
                is_template: { type: "boolean" },
                license_template: { type: "string" },
                name: { required: true, type: "string" },
                org: { required: true, type: "string" },
                private: { type: "boolean" },
                team_id: { type: "integer" },
                visibility: {
                    enum: ["public", "private", "visibility", "internal"],
                    type: "string"
                }
            },
            url: "/orgs/:org/repos"
        },
        createOrUpdateFile: {
            method: "PUT",
            params: {
                author: { type: "object" },
                "author.email": { required: true, type: "string" },
                "author.name": { required: true, type: "string" },
                branch: { type: "string" },
                committer: { type: "object" },
                "committer.email": { required: true, type: "string" },
                "committer.name": { required: true, type: "string" },
                content: { required: true, type: "string" },
                message: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { type: "string" }
            },
            url: "/repos/:owner/:repo/contents/:path"
        },
        createRelease: {
            method: "POST",
            params: {
                body: { type: "string" },
                draft: { type: "boolean" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                prerelease: { type: "boolean" },
                repo: { required: true, type: "string" },
                tag_name: { required: true, type: "string" },
                target_commitish: { type: "string" }
            },
            url: "/repos/:owner/:repo/releases"
        },
        createStatus: {
            method: "POST",
            params: {
                context: { type: "string" },
                description: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { required: true, type: "string" },
                state: {
                    enum: ["error", "failure", "pending", "success"],
                    required: true,
                    type: "string"
                },
                target_url: { type: "string" }
            },
            url: "/repos/:owner/:repo/statuses/:sha"
        },
        createUsingTemplate: {
            headers: { accept: "application/vnd.github.baptiste-preview+json" },
            method: "POST",
            params: {
                description: { type: "string" },
                name: { required: true, type: "string" },
                owner: { type: "string" },
                private: { type: "boolean" },
                template_owner: { required: true, type: "string" },
                template_repo: { required: true, type: "string" }
            },
            url: "/repos/:template_owner/:template_repo/generate"
        },
        declineInvitation: {
            method: "DELETE",
            params: { invitation_id: { required: true, type: "integer" } },
            url: "/user/repository_invitations/:invitation_id"
        },
        delete: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo"
        },
        deleteCommitComment: {
            method: "DELETE",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments/:comment_id"
        },
        deleteDownload: {
            method: "DELETE",
            params: {
                download_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/downloads/:download_id"
        },
        deleteFile: {
            method: "DELETE",
            params: {
                author: { type: "object" },
                "author.email": { type: "string" },
                "author.name": { type: "string" },
                branch: { type: "string" },
                committer: { type: "object" },
                "committer.email": { type: "string" },
                "committer.name": { type: "string" },
                message: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/contents/:path"
        },
        deleteHook: {
            method: "DELETE",
            params: {
                hook_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks/:hook_id"
        },
        deleteInvitation: {
            method: "DELETE",
            params: {
                invitation_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/invitations/:invitation_id"
        },
        deleteRelease: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                release_id: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/:release_id"
        },
        deleteReleaseAsset: {
            method: "DELETE",
            params: {
                asset_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/assets/:asset_id"
        },
        disableAutomatedSecurityFixes: {
            headers: { accept: "application/vnd.github.london-preview+json" },
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/automated-security-fixes"
        },
        disablePagesSite: {
            headers: { accept: "application/vnd.github.switcheroo-preview+json" },
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages"
        },
        disableVulnerabilityAlerts: {
            headers: { accept: "application/vnd.github.dorian-preview+json" },
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/vulnerability-alerts"
        },
        enableAutomatedSecurityFixes: {
            headers: { accept: "application/vnd.github.london-preview+json" },
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/automated-security-fixes"
        },
        enablePagesSite: {
            headers: { accept: "application/vnd.github.switcheroo-preview+json" },
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                source: { type: "object" },
                "source.branch": { enum: ["master", "gh-pages"], type: "string" },
                "source.path": { type: "string" }
            },
            url: "/repos/:owner/:repo/pages"
        },
        enableVulnerabilityAlerts: {
            headers: { accept: "application/vnd.github.dorian-preview+json" },
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/vulnerability-alerts"
        },
        get: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo"
        },
        getAppsWithAccessToProtectedBranch: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/apps"
        },
        getArchiveLink: {
            method: "GET",
            params: {
                archive_format: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/:archive_format/:ref"
        },
        getBranch: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch"
        },
        getBranchProtection: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection"
        },
        getClones: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                per: { enum: ["day", "week"], type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/traffic/clones"
        },
        getCodeFrequencyStats: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stats/code_frequency"
        },
        getCollaboratorPermissionLevel: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/collaborators/:username/permission"
        },
        getCombinedStatusForRef: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref/status"
        },
        getCommit: {
            method: "GET",
            params: {
                commit_sha: { alias: "ref", deprecated: true, type: "string" },
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { alias: "ref", deprecated: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref"
        },
        getCommitActivityStats: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stats/commit_activity"
        },
        getCommitComment: {
            method: "GET",
            params: {
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments/:comment_id"
        },
        getCommitRefSha: {
            deprecated: "octokit.repos.getCommitRefSha() is deprecated, see https://developer.github.com/v3/repos/commits/#get-a-single-commit",
            headers: { accept: "application/vnd.github.v3.sha" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref"
        },
        getContents: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                ref: { type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/contents/:path"
        },
        getContributorsStats: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stats/contributors"
        },
        getDeployKey: {
            method: "GET",
            params: {
                key_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/keys/:key_id"
        },
        getDeployment: {
            method: "GET",
            params: {
                deployment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/deployments/:deployment_id"
        },
        getDeploymentStatus: {
            method: "GET",
            params: {
                deployment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                status_id: { required: true, type: "integer" }
            },
            url: "/repos/:owner/:repo/deployments/:deployment_id/statuses/:status_id"
        },
        getDownload: {
            method: "GET",
            params: {
                download_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/downloads/:download_id"
        },
        getHook: {
            method: "GET",
            params: {
                hook_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks/:hook_id"
        },
        getLatestPagesBuild: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages/builds/latest"
        },
        getLatestRelease: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/latest"
        },
        getPages: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages"
        },
        getPagesBuild: {
            method: "GET",
            params: {
                build_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages/builds/:build_id"
        },
        getParticipationStats: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stats/participation"
        },
        getProtectedBranchAdminEnforcement: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/enforce_admins"
        },
        getProtectedBranchPullRequestReviewEnforcement: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_pull_request_reviews"
        },
        getProtectedBranchRequiredSignatures: {
            headers: { accept: "application/vnd.github.zzzax-preview+json" },
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_signatures"
        },
        getProtectedBranchRequiredStatusChecks: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks"
        },
        getProtectedBranchRestrictions: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions"
        },
        getPunchCardStats: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/stats/punch_card"
        },
        getReadme: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                ref: { type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/readme"
        },
        getRelease: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                release_id: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/:release_id"
        },
        getReleaseAsset: {
            method: "GET",
            params: {
                asset_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/assets/:asset_id"
        },
        getReleaseByTag: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                tag: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/tags/:tag"
        },
        getTeamsWithAccessToProtectedBranch: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        getTopPaths: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/traffic/popular/paths"
        },
        getTopReferrers: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/traffic/popular/referrers"
        },
        getUsersWithAccessToProtectedBranch: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        getViews: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                per: { enum: ["day", "week"], type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/traffic/views"
        },
        list: {
            method: "GET",
            params: {
                affiliation: { type: "string" },
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                sort: {
                    enum: ["created", "updated", "pushed", "full_name"],
                    type: "string"
                },
                type: {
                    enum: ["all", "owner", "public", "private", "member"],
                    type: "string"
                },
                visibility: { enum: ["all", "public", "private"], type: "string" }
            },
            url: "/user/repos"
        },
        listAppsWithAccessToProtectedBranch: {
            deprecated: "octokit.repos.listAppsWithAccessToProtectedBranch() has been renamed to octokit.repos.getAppsWithAccessToProtectedBranch() (2019-09-13)",
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/apps"
        },
        listAssetsForRelease: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                release_id: { required: true, type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/:release_id/assets"
        },
        listBranches: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                protected: { type: "boolean" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches"
        },
        listBranchesForHeadCommit: {
            headers: { accept: "application/vnd.github.groot-preview+json" },
            method: "GET",
            params: {
                commit_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:commit_sha/branches-where-head"
        },
        listCollaborators: {
            method: "GET",
            params: {
                affiliation: { enum: ["outside", "direct", "all"], type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/collaborators"
        },
        listCommentsForCommit: {
            method: "GET",
            params: {
                commit_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { alias: "commit_sha", deprecated: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:commit_sha/comments"
        },
        listCommitComments: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments"
        },
        listCommits: {
            method: "GET",
            params: {
                author: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                path: { type: "string" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                sha: { type: "string" },
                since: { type: "string" },
                until: { type: "string" }
            },
            url: "/repos/:owner/:repo/commits"
        },
        listContributors: {
            method: "GET",
            params: {
                anon: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/contributors"
        },
        listDeployKeys: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/keys"
        },
        listDeploymentStatuses: {
            method: "GET",
            params: {
                deployment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/deployments/:deployment_id/statuses"
        },
        listDeployments: {
            method: "GET",
            params: {
                environment: { type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { type: "string" },
                repo: { required: true, type: "string" },
                sha: { type: "string" },
                task: { type: "string" }
            },
            url: "/repos/:owner/:repo/deployments"
        },
        listDownloads: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/downloads"
        },
        listForOrg: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                sort: {
                    enum: ["created", "updated", "pushed", "full_name"],
                    type: "string"
                },
                type: {
                    enum: [
                        "all",
                        "public",
                        "private",
                        "forks",
                        "sources",
                        "member",
                        "internal"
                    ],
                    type: "string"
                }
            },
            url: "/orgs/:org/repos"
        },
        listForUser: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                sort: {
                    enum: ["created", "updated", "pushed", "full_name"],
                    type: "string"
                },
                type: { enum: ["all", "owner", "member"], type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/repos"
        },
        listForks: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" },
                sort: { enum: ["newest", "oldest", "stargazers"], type: "string" }
            },
            url: "/repos/:owner/:repo/forks"
        },
        listHooks: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks"
        },
        listInvitations: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/invitations"
        },
        listInvitationsForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/repository_invitations"
        },
        listLanguages: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/languages"
        },
        listPagesBuilds: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages/builds"
        },
        listProtectedBranchRequiredStatusChecksContexts: {
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks/contexts"
        },
        listProtectedBranchTeamRestrictions: {
            deprecated: "octokit.repos.listProtectedBranchTeamRestrictions() has been renamed to octokit.repos.getTeamsWithAccessToProtectedBranch() (2019-09-09)",
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        listProtectedBranchUserRestrictions: {
            deprecated: "octokit.repos.listProtectedBranchUserRestrictions() has been renamed to octokit.repos.getUsersWithAccessToProtectedBranch() (2019-09-09)",
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        listPublic: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "integer" }
            },
            url: "/repositories"
        },
        listPullRequestsAssociatedWithCommit: {
            headers: { accept: "application/vnd.github.groot-preview+json" },
            method: "GET",
            params: {
                commit_sha: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:commit_sha/pulls"
        },
        listReleases: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases"
        },
        listStatusesForRef: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                ref: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/commits/:ref/statuses"
        },
        listTags: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/tags"
        },
        listTeams: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/teams"
        },
        listTeamsWithAccessToProtectedBranch: {
            deprecated: "octokit.repos.listTeamsWithAccessToProtectedBranch() has been renamed to octokit.repos.getTeamsWithAccessToProtectedBranch() (2019-09-13)",
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        listTopics: {
            headers: { accept: "application/vnd.github.mercy-preview+json" },
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/topics"
        },
        listUsersWithAccessToProtectedBranch: {
            deprecated: "octokit.repos.listUsersWithAccessToProtectedBranch() has been renamed to octokit.repos.getUsersWithAccessToProtectedBranch() (2019-09-13)",
            method: "GET",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        merge: {
            method: "POST",
            params: {
                base: { required: true, type: "string" },
                commit_message: { type: "string" },
                head: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/merges"
        },
        pingHook: {
            method: "POST",
            params: {
                hook_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks/:hook_id/pings"
        },
        removeBranchProtection: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection"
        },
        removeCollaborator: {
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/collaborators/:username"
        },
        removeDeployKey: {
            method: "DELETE",
            params: {
                key_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/keys/:key_id"
        },
        removeProtectedBranchAdminEnforcement: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/enforce_admins"
        },
        removeProtectedBranchAppRestrictions: {
            method: "DELETE",
            params: {
                apps: { mapTo: "data", required: true, type: "string[]" },
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/apps"
        },
        removeProtectedBranchPullRequestReviewEnforcement: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_pull_request_reviews"
        },
        removeProtectedBranchRequiredSignatures: {
            headers: { accept: "application/vnd.github.zzzax-preview+json" },
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_signatures"
        },
        removeProtectedBranchRequiredStatusChecks: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks"
        },
        removeProtectedBranchRequiredStatusChecksContexts: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                contexts: { mapTo: "data", required: true, type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks/contexts"
        },
        removeProtectedBranchRestrictions: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions"
        },
        removeProtectedBranchTeamRestrictions: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                teams: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        removeProtectedBranchUserRestrictions: {
            method: "DELETE",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                users: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        replaceProtectedBranchAppRestrictions: {
            method: "PUT",
            params: {
                apps: { mapTo: "data", required: true, type: "string[]" },
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/apps"
        },
        replaceProtectedBranchRequiredStatusChecksContexts: {
            method: "PUT",
            params: {
                branch: { required: true, type: "string" },
                contexts: { mapTo: "data", required: true, type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks/contexts"
        },
        replaceProtectedBranchTeamRestrictions: {
            method: "PUT",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                teams: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/teams"
        },
        replaceProtectedBranchUserRestrictions: {
            method: "PUT",
            params: {
                branch: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                users: { mapTo: "data", required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/restrictions/users"
        },
        replaceTopics: {
            headers: { accept: "application/vnd.github.mercy-preview+json" },
            method: "PUT",
            params: {
                names: { required: true, type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/topics"
        },
        requestPageBuild: {
            method: "POST",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/pages/builds"
        },
        retrieveCommunityProfileMetrics: {
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/community/profile"
        },
        testPushHook: {
            method: "POST",
            params: {
                hook_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks/:hook_id/tests"
        },
        transfer: {
            method: "POST",
            params: {
                new_owner: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_ids: { type: "integer[]" }
            },
            url: "/repos/:owner/:repo/transfer"
        },
        update: {
            method: "PATCH",
            params: {
                allow_merge_commit: { type: "boolean" },
                allow_rebase_merge: { type: "boolean" },
                allow_squash_merge: { type: "boolean" },
                archived: { type: "boolean" },
                default_branch: { type: "string" },
                delete_branch_on_merge: { type: "boolean" },
                description: { type: "string" },
                has_issues: { type: "boolean" },
                has_projects: { type: "boolean" },
                has_wiki: { type: "boolean" },
                homepage: { type: "string" },
                is_template: { type: "boolean" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                private: { type: "boolean" },
                repo: { required: true, type: "string" },
                visibility: {
                    enum: ["public", "private", "visibility", "internal"],
                    type: "string"
                }
            },
            url: "/repos/:owner/:repo"
        },
        updateBranchProtection: {
            method: "PUT",
            params: {
                allow_deletions: { type: "boolean" },
                allow_force_pushes: { allowNull: true, type: "boolean" },
                branch: { required: true, type: "string" },
                enforce_admins: { allowNull: true, required: true, type: "boolean" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                required_linear_history: { type: "boolean" },
                required_pull_request_reviews: {
                    allowNull: true,
                    required: true,
                    type: "object"
                },
                "required_pull_request_reviews.dismiss_stale_reviews": {
                    type: "boolean"
                },
                "required_pull_request_reviews.dismissal_restrictions": {
                    type: "object"
                },
                "required_pull_request_reviews.dismissal_restrictions.teams": {
                    type: "string[]"
                },
                "required_pull_request_reviews.dismissal_restrictions.users": {
                    type: "string[]"
                },
                "required_pull_request_reviews.require_code_owner_reviews": {
                    type: "boolean"
                },
                "required_pull_request_reviews.required_approving_review_count": {
                    type: "integer"
                },
                required_status_checks: {
                    allowNull: true,
                    required: true,
                    type: "object"
                },
                "required_status_checks.contexts": { required: true, type: "string[]" },
                "required_status_checks.strict": { required: true, type: "boolean" },
                restrictions: { allowNull: true, required: true, type: "object" },
                "restrictions.apps": { type: "string[]" },
                "restrictions.teams": { required: true, type: "string[]" },
                "restrictions.users": { required: true, type: "string[]" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection"
        },
        updateCommitComment: {
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/comments/:comment_id"
        },
        updateFile: {
            deprecated: "octokit.repos.updateFile() has been renamed to octokit.repos.createOrUpdateFile() (2019-06-07)",
            method: "PUT",
            params: {
                author: { type: "object" },
                "author.email": { required: true, type: "string" },
                "author.name": { required: true, type: "string" },
                branch: { type: "string" },
                committer: { type: "object" },
                "committer.email": { required: true, type: "string" },
                "committer.name": { required: true, type: "string" },
                content: { required: true, type: "string" },
                message: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                path: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                sha: { type: "string" }
            },
            url: "/repos/:owner/:repo/contents/:path"
        },
        updateHook: {
            method: "PATCH",
            params: {
                active: { type: "boolean" },
                add_events: { type: "string[]" },
                config: { type: "object" },
                "config.content_type": { type: "string" },
                "config.insecure_ssl": { type: "string" },
                "config.secret": { type: "string" },
                "config.url": { required: true, type: "string" },
                events: { type: "string[]" },
                hook_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                remove_events: { type: "string[]" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/hooks/:hook_id"
        },
        updateInformationAboutPagesSite: {
            method: "PUT",
            params: {
                cname: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                source: {
                    enum: ['"gh-pages"', '"master"', '"master /docs"'],
                    type: "string"
                }
            },
            url: "/repos/:owner/:repo/pages"
        },
        updateInvitation: {
            method: "PATCH",
            params: {
                invitation_id: { required: true, type: "integer" },
                owner: { required: true, type: "string" },
                permissions: { enum: ["read", "write", "admin"], type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/invitations/:invitation_id"
        },
        updateProtectedBranchPullRequestReviewEnforcement: {
            method: "PATCH",
            params: {
                branch: { required: true, type: "string" },
                dismiss_stale_reviews: { type: "boolean" },
                dismissal_restrictions: { type: "object" },
                "dismissal_restrictions.teams": { type: "string[]" },
                "dismissal_restrictions.users": { type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                require_code_owner_reviews: { type: "boolean" },
                required_approving_review_count: { type: "integer" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_pull_request_reviews"
        },
        updateProtectedBranchRequiredStatusChecks: {
            method: "PATCH",
            params: {
                branch: { required: true, type: "string" },
                contexts: { type: "string[]" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                strict: { type: "boolean" }
            },
            url: "/repos/:owner/:repo/branches/:branch/protection/required_status_checks"
        },
        updateRelease: {
            method: "PATCH",
            params: {
                body: { type: "string" },
                draft: { type: "boolean" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                prerelease: { type: "boolean" },
                release_id: { required: true, type: "integer" },
                repo: { required: true, type: "string" },
                tag_name: { type: "string" },
                target_commitish: { type: "string" }
            },
            url: "/repos/:owner/:repo/releases/:release_id"
        },
        updateReleaseAsset: {
            method: "PATCH",
            params: {
                asset_id: { required: true, type: "integer" },
                label: { type: "string" },
                name: { type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" }
            },
            url: "/repos/:owner/:repo/releases/assets/:asset_id"
        },
        uploadReleaseAsset: {
            method: "POST",
            params: {
                data: { mapTo: "data", required: true, type: "string | object" },
                file: { alias: "data", deprecated: true, type: "string | object" },
                headers: { required: true, type: "object" },
                "headers.content-length": { required: true, type: "integer" },
                "headers.content-type": { required: true, type: "string" },
                label: { type: "string" },
                name: { required: true, type: "string" },
                url: { required: true, type: "string" }
            },
            url: ":url"
        }
    },
    search: {
        code: {
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: { enum: ["indexed"], type: "string" }
            },
            url: "/search/code"
        },
        commits: {
            headers: { accept: "application/vnd.github.cloak-preview+json" },
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: { enum: ["author-date", "committer-date"], type: "string" }
            },
            url: "/search/commits"
        },
        issues: {
            deprecated: "octokit.search.issues() has been renamed to octokit.search.issuesAndPullRequests() (2018-12-27)",
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: {
                    enum: [
                        "comments",
                        "reactions",
                        "reactions-+1",
                        "reactions--1",
                        "reactions-smile",
                        "reactions-thinking_face",
                        "reactions-heart",
                        "reactions-tada",
                        "interactions",
                        "created",
                        "updated"
                    ],
                    type: "string"
                }
            },
            url: "/search/issues"
        },
        issuesAndPullRequests: {
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: {
                    enum: [
                        "comments",
                        "reactions",
                        "reactions-+1",
                        "reactions--1",
                        "reactions-smile",
                        "reactions-thinking_face",
                        "reactions-heart",
                        "reactions-tada",
                        "interactions",
                        "created",
                        "updated"
                    ],
                    type: "string"
                }
            },
            url: "/search/issues"
        },
        labels: {
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                q: { required: true, type: "string" },
                repository_id: { required: true, type: "integer" },
                sort: { enum: ["created", "updated"], type: "string" }
            },
            url: "/search/labels"
        },
        repos: {
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: {
                    enum: ["stars", "forks", "help-wanted-issues", "updated"],
                    type: "string"
                }
            },
            url: "/search/repositories"
        },
        topics: {
            method: "GET",
            params: { q: { required: true, type: "string" } },
            url: "/search/topics"
        },
        users: {
            method: "GET",
            params: {
                order: { enum: ["desc", "asc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                q: { required: true, type: "string" },
                sort: { enum: ["followers", "repositories", "joined"], type: "string" }
            },
            url: "/search/users"
        }
    },
    teams: {
        addMember: {
            deprecated: "octokit.teams.addMember() has been renamed to octokit.teams.addMemberLegacy() (2020-01-16)",
            method: "PUT",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        addMemberLegacy: {
            deprecated: "octokit.teams.addMemberLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#add-team-member-legacy",
            method: "PUT",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        addOrUpdateMembership: {
            deprecated: "octokit.teams.addOrUpdateMembership() has been renamed to octokit.teams.addOrUpdateMembershipLegacy() (2020-01-16)",
            method: "PUT",
            params: {
                role: { enum: ["member", "maintainer"], type: "string" },
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        addOrUpdateMembershipInOrg: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                role: { enum: ["member", "maintainer"], type: "string" },
                team_slug: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/memberships/:username"
        },
        addOrUpdateMembershipLegacy: {
            deprecated: "octokit.teams.addOrUpdateMembershipLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#add-or-update-team-membership-legacy",
            method: "PUT",
            params: {
                role: { enum: ["member", "maintainer"], type: "string" },
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        addOrUpdateProject: {
            deprecated: "octokit.teams.addOrUpdateProject() has been renamed to octokit.teams.addOrUpdateProjectLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PUT",
            params: {
                permission: { enum: ["read", "write", "admin"], type: "string" },
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        addOrUpdateProjectInOrg: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                permission: { enum: ["read", "write", "admin"], type: "string" },
                project_id: { required: true, type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/projects/:project_id"
        },
        addOrUpdateProjectLegacy: {
            deprecated: "octokit.teams.addOrUpdateProjectLegacy() is deprecated, see https://developer.github.com/v3/teams/#add-or-update-team-project-legacy",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "PUT",
            params: {
                permission: { enum: ["read", "write", "admin"], type: "string" },
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        addOrUpdateRepo: {
            deprecated: "octokit.teams.addOrUpdateRepo() has been renamed to octokit.teams.addOrUpdateRepoLegacy() (2020-01-16)",
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        addOrUpdateRepoInOrg: {
            method: "PUT",
            params: {
                org: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                repo: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/repos/:owner/:repo"
        },
        addOrUpdateRepoLegacy: {
            deprecated: "octokit.teams.addOrUpdateRepoLegacy() is deprecated, see https://developer.github.com/v3/teams/#add-or-update-team-repository-legacy",
            method: "PUT",
            params: {
                owner: { required: true, type: "string" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        checkManagesRepo: {
            deprecated: "octokit.teams.checkManagesRepo() has been renamed to octokit.teams.checkManagesRepoLegacy() (2020-01-16)",
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        checkManagesRepoInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/repos/:owner/:repo"
        },
        checkManagesRepoLegacy: {
            deprecated: "octokit.teams.checkManagesRepoLegacy() is deprecated, see https://developer.github.com/v3/teams/#check-if-a-team-manages-a-repository-legacy",
            method: "GET",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        create: {
            method: "POST",
            params: {
                description: { type: "string" },
                maintainers: { type: "string[]" },
                name: { required: true, type: "string" },
                org: { required: true, type: "string" },
                parent_team_id: { type: "integer" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                privacy: { enum: ["secret", "closed"], type: "string" },
                repo_names: { type: "string[]" }
            },
            url: "/orgs/:org/teams"
        },
        createDiscussion: {
            deprecated: "octokit.teams.createDiscussion() has been renamed to octokit.teams.createDiscussionLegacy() (2020-01-16)",
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                private: { type: "boolean" },
                team_id: { required: true, type: "integer" },
                title: { required: true, type: "string" }
            },
            url: "/teams/:team_id/discussions"
        },
        createDiscussionComment: {
            deprecated: "octokit.teams.createDiscussionComment() has been renamed to octokit.teams.createDiscussionCommentLegacy() (2020-01-16)",
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments"
        },
        createDiscussionCommentInOrg: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments"
        },
        createDiscussionCommentLegacy: {
            deprecated: "octokit.teams.createDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/teams/discussion_comments/#create-a-comment-legacy",
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments"
        },
        createDiscussionInOrg: {
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                org: { required: true, type: "string" },
                private: { type: "boolean" },
                team_slug: { required: true, type: "string" },
                title: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions"
        },
        createDiscussionLegacy: {
            deprecated: "octokit.teams.createDiscussionLegacy() is deprecated, see https://developer.github.com/v3/teams/discussions/#create-a-discussion-legacy",
            method: "POST",
            params: {
                body: { required: true, type: "string" },
                private: { type: "boolean" },
                team_id: { required: true, type: "integer" },
                title: { required: true, type: "string" }
            },
            url: "/teams/:team_id/discussions"
        },
        delete: {
            deprecated: "octokit.teams.delete() has been renamed to octokit.teams.deleteLegacy() (2020-01-16)",
            method: "DELETE",
            params: { team_id: { required: true, type: "integer" } },
            url: "/teams/:team_id"
        },
        deleteDiscussion: {
            deprecated: "octokit.teams.deleteDiscussion() has been renamed to octokit.teams.deleteDiscussionLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        deleteDiscussionComment: {
            deprecated: "octokit.teams.deleteDiscussionComment() has been renamed to octokit.teams.deleteDiscussionCommentLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        deleteDiscussionCommentInOrg: {
            method: "DELETE",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments/:comment_number"
        },
        deleteDiscussionCommentLegacy: {
            deprecated: "octokit.teams.deleteDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/teams/discussion_comments/#delete-a-comment-legacy",
            method: "DELETE",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        deleteDiscussionInOrg: {
            method: "DELETE",
            params: {
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number"
        },
        deleteDiscussionLegacy: {
            deprecated: "octokit.teams.deleteDiscussionLegacy() is deprecated, see https://developer.github.com/v3/teams/discussions/#delete-a-discussion-legacy",
            method: "DELETE",
            params: {
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        deleteInOrg: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug"
        },
        deleteLegacy: {
            deprecated: "octokit.teams.deleteLegacy() is deprecated, see https://developer.github.com/v3/teams/#delete-team-legacy",
            method: "DELETE",
            params: { team_id: { required: true, type: "integer" } },
            url: "/teams/:team_id"
        },
        get: {
            deprecated: "octokit.teams.get() has been renamed to octokit.teams.getLegacy() (2020-01-16)",
            method: "GET",
            params: { team_id: { required: true, type: "integer" } },
            url: "/teams/:team_id"
        },
        getByName: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug"
        },
        getDiscussion: {
            deprecated: "octokit.teams.getDiscussion() has been renamed to octokit.teams.getDiscussionLegacy() (2020-01-16)",
            method: "GET",
            params: {
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        getDiscussionComment: {
            deprecated: "octokit.teams.getDiscussionComment() has been renamed to octokit.teams.getDiscussionCommentLegacy() (2020-01-16)",
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        getDiscussionCommentInOrg: {
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments/:comment_number"
        },
        getDiscussionCommentLegacy: {
            deprecated: "octokit.teams.getDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/teams/discussion_comments/#get-a-single-comment-legacy",
            method: "GET",
            params: {
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        getDiscussionInOrg: {
            method: "GET",
            params: {
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number"
        },
        getDiscussionLegacy: {
            deprecated: "octokit.teams.getDiscussionLegacy() is deprecated, see https://developer.github.com/v3/teams/discussions/#get-a-single-discussion-legacy",
            method: "GET",
            params: {
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        getLegacy: {
            deprecated: "octokit.teams.getLegacy() is deprecated, see https://developer.github.com/v3/teams/#get-team-legacy",
            method: "GET",
            params: { team_id: { required: true, type: "integer" } },
            url: "/teams/:team_id"
        },
        getMember: {
            deprecated: "octokit.teams.getMember() has been renamed to octokit.teams.getMemberLegacy() (2020-01-16)",
            method: "GET",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        getMemberLegacy: {
            deprecated: "octokit.teams.getMemberLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#get-team-member-legacy",
            method: "GET",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        getMembership: {
            deprecated: "octokit.teams.getMembership() has been renamed to octokit.teams.getMembershipLegacy() (2020-01-16)",
            method: "GET",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        getMembershipInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/memberships/:username"
        },
        getMembershipLegacy: {
            deprecated: "octokit.teams.getMembershipLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#get-team-membership-legacy",
            method: "GET",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        list: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" }
            },
            url: "/orgs/:org/teams"
        },
        listChild: {
            deprecated: "octokit.teams.listChild() has been renamed to octokit.teams.listChildLegacy() (2020-01-16)",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/teams"
        },
        listChildInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/teams"
        },
        listChildLegacy: {
            deprecated: "octokit.teams.listChildLegacy() is deprecated, see https://developer.github.com/v3/teams/#list-child-teams-legacy",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/teams"
        },
        listDiscussionComments: {
            deprecated: "octokit.teams.listDiscussionComments() has been renamed to octokit.teams.listDiscussionCommentsLegacy() (2020-01-16)",
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments"
        },
        listDiscussionCommentsInOrg: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments"
        },
        listDiscussionCommentsLegacy: {
            deprecated: "octokit.teams.listDiscussionCommentsLegacy() is deprecated, see https://developer.github.com/v3/teams/discussion_comments/#list-comments-legacy",
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                discussion_number: { required: true, type: "integer" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments"
        },
        listDiscussions: {
            deprecated: "octokit.teams.listDiscussions() has been renamed to octokit.teams.listDiscussionsLegacy() (2020-01-16)",
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions"
        },
        listDiscussionsInOrg: {
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions"
        },
        listDiscussionsLegacy: {
            deprecated: "octokit.teams.listDiscussionsLegacy() is deprecated, see https://developer.github.com/v3/teams/discussions/#list-discussions-legacy",
            method: "GET",
            params: {
                direction: { enum: ["asc", "desc"], type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions"
        },
        listForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/teams"
        },
        listMembers: {
            deprecated: "octokit.teams.listMembers() has been renamed to octokit.teams.listMembersLegacy() (2020-01-16)",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                role: { enum: ["member", "maintainer", "all"], type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/members"
        },
        listMembersInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                role: { enum: ["member", "maintainer", "all"], type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/members"
        },
        listMembersLegacy: {
            deprecated: "octokit.teams.listMembersLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#list-team-members-legacy",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                role: { enum: ["member", "maintainer", "all"], type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/members"
        },
        listPendingInvitations: {
            deprecated: "octokit.teams.listPendingInvitations() has been renamed to octokit.teams.listPendingInvitationsLegacy() (2020-01-16)",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/invitations"
        },
        listPendingInvitationsInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/invitations"
        },
        listPendingInvitationsLegacy: {
            deprecated: "octokit.teams.listPendingInvitationsLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#list-pending-team-invitations-legacy",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/invitations"
        },
        listProjects: {
            deprecated: "octokit.teams.listProjects() has been renamed to octokit.teams.listProjectsLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects"
        },
        listProjectsInOrg: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/projects"
        },
        listProjectsLegacy: {
            deprecated: "octokit.teams.listProjectsLegacy() is deprecated, see https://developer.github.com/v3/teams/#list-team-projects-legacy",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects"
        },
        listRepos: {
            deprecated: "octokit.teams.listRepos() has been renamed to octokit.teams.listReposLegacy() (2020-01-16)",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos"
        },
        listReposInOrg: {
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/repos"
        },
        listReposLegacy: {
            deprecated: "octokit.teams.listReposLegacy() is deprecated, see https://developer.github.com/v3/teams/#list-team-repos-legacy",
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos"
        },
        removeMember: {
            deprecated: "octokit.teams.removeMember() has been renamed to octokit.teams.removeMemberLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        removeMemberLegacy: {
            deprecated: "octokit.teams.removeMemberLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#remove-team-member-legacy",
            method: "DELETE",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/members/:username"
        },
        removeMembership: {
            deprecated: "octokit.teams.removeMembership() has been renamed to octokit.teams.removeMembershipLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        removeMembershipInOrg: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/memberships/:username"
        },
        removeMembershipLegacy: {
            deprecated: "octokit.teams.removeMembershipLegacy() is deprecated, see https://developer.github.com/v3/teams/members/#remove-team-membership-legacy",
            method: "DELETE",
            params: {
                team_id: { required: true, type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/teams/:team_id/memberships/:username"
        },
        removeProject: {
            deprecated: "octokit.teams.removeProject() has been renamed to octokit.teams.removeProjectLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        removeProjectInOrg: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                project_id: { required: true, type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/projects/:project_id"
        },
        removeProjectLegacy: {
            deprecated: "octokit.teams.removeProjectLegacy() is deprecated, see https://developer.github.com/v3/teams/#remove-team-project-legacy",
            method: "DELETE",
            params: {
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        removeRepo: {
            deprecated: "octokit.teams.removeRepo() has been renamed to octokit.teams.removeRepoLegacy() (2020-01-16)",
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        removeRepoInOrg: {
            method: "DELETE",
            params: {
                org: { required: true, type: "string" },
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/repos/:owner/:repo"
        },
        removeRepoLegacy: {
            deprecated: "octokit.teams.removeRepoLegacy() is deprecated, see https://developer.github.com/v3/teams/#remove-team-repository-legacy",
            method: "DELETE",
            params: {
                owner: { required: true, type: "string" },
                repo: { required: true, type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/repos/:owner/:repo"
        },
        reviewProject: {
            deprecated: "octokit.teams.reviewProject() has been renamed to octokit.teams.reviewProjectLegacy() (2020-01-16)",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        reviewProjectInOrg: {
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                org: { required: true, type: "string" },
                project_id: { required: true, type: "integer" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/projects/:project_id"
        },
        reviewProjectLegacy: {
            deprecated: "octokit.teams.reviewProjectLegacy() is deprecated, see https://developer.github.com/v3/teams/#review-a-team-project-legacy",
            headers: { accept: "application/vnd.github.inertia-preview+json" },
            method: "GET",
            params: {
                project_id: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/projects/:project_id"
        },
        update: {
            deprecated: "octokit.teams.update() has been renamed to octokit.teams.updateLegacy() (2020-01-16)",
            method: "PATCH",
            params: {
                description: { type: "string" },
                name: { required: true, type: "string" },
                parent_team_id: { type: "integer" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                privacy: { enum: ["secret", "closed"], type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id"
        },
        updateDiscussion: {
            deprecated: "octokit.teams.updateDiscussion() has been renamed to octokit.teams.updateDiscussionLegacy() (2020-01-16)",
            method: "PATCH",
            params: {
                body: { type: "string" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" },
                title: { type: "string" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        updateDiscussionComment: {
            deprecated: "octokit.teams.updateDiscussionComment() has been renamed to octokit.teams.updateDiscussionCommentLegacy() (2020-01-16)",
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        updateDiscussionCommentInOrg: {
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number/comments/:comment_number"
        },
        updateDiscussionCommentLegacy: {
            deprecated: "octokit.teams.updateDiscussionCommentLegacy() is deprecated, see https://developer.github.com/v3/teams/discussion_comments/#edit-a-comment-legacy",
            method: "PATCH",
            params: {
                body: { required: true, type: "string" },
                comment_number: { required: true, type: "integer" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id/discussions/:discussion_number/comments/:comment_number"
        },
        updateDiscussionInOrg: {
            method: "PATCH",
            params: {
                body: { type: "string" },
                discussion_number: { required: true, type: "integer" },
                org: { required: true, type: "string" },
                team_slug: { required: true, type: "string" },
                title: { type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug/discussions/:discussion_number"
        },
        updateDiscussionLegacy: {
            deprecated: "octokit.teams.updateDiscussionLegacy() is deprecated, see https://developer.github.com/v3/teams/discussions/#edit-a-discussion-legacy",
            method: "PATCH",
            params: {
                body: { type: "string" },
                discussion_number: { required: true, type: "integer" },
                team_id: { required: true, type: "integer" },
                title: { type: "string" }
            },
            url: "/teams/:team_id/discussions/:discussion_number"
        },
        updateInOrg: {
            method: "PATCH",
            params: {
                description: { type: "string" },
                name: { required: true, type: "string" },
                org: { required: true, type: "string" },
                parent_team_id: { type: "integer" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                privacy: { enum: ["secret", "closed"], type: "string" },
                team_slug: { required: true, type: "string" }
            },
            url: "/orgs/:org/teams/:team_slug"
        },
        updateLegacy: {
            deprecated: "octokit.teams.updateLegacy() is deprecated, see https://developer.github.com/v3/teams/#edit-team-legacy",
            method: "PATCH",
            params: {
                description: { type: "string" },
                name: { required: true, type: "string" },
                parent_team_id: { type: "integer" },
                permission: { enum: ["pull", "push", "admin"], type: "string" },
                privacy: { enum: ["secret", "closed"], type: "string" },
                team_id: { required: true, type: "integer" }
            },
            url: "/teams/:team_id"
        }
    },
    users: {
        addEmails: {
            method: "POST",
            params: { emails: { required: true, type: "string[]" } },
            url: "/user/emails"
        },
        block: {
            method: "PUT",
            params: { username: { required: true, type: "string" } },
            url: "/user/blocks/:username"
        },
        checkBlocked: {
            method: "GET",
            params: { username: { required: true, type: "string" } },
            url: "/user/blocks/:username"
        },
        checkFollowing: {
            method: "GET",
            params: { username: { required: true, type: "string" } },
            url: "/user/following/:username"
        },
        checkFollowingForUser: {
            method: "GET",
            params: {
                target_user: { required: true, type: "string" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/following/:target_user"
        },
        createGpgKey: {
            method: "POST",
            params: { armored_public_key: { type: "string" } },
            url: "/user/gpg_keys"
        },
        createPublicKey: {
            method: "POST",
            params: { key: { type: "string" }, title: { type: "string" } },
            url: "/user/keys"
        },
        deleteEmails: {
            method: "DELETE",
            params: { emails: { required: true, type: "string[]" } },
            url: "/user/emails"
        },
        deleteGpgKey: {
            method: "DELETE",
            params: { gpg_key_id: { required: true, type: "integer" } },
            url: "/user/gpg_keys/:gpg_key_id"
        },
        deletePublicKey: {
            method: "DELETE",
            params: { key_id: { required: true, type: "integer" } },
            url: "/user/keys/:key_id"
        },
        follow: {
            method: "PUT",
            params: { username: { required: true, type: "string" } },
            url: "/user/following/:username"
        },
        getAuthenticated: { method: "GET", params: {}, url: "/user" },
        getByUsername: {
            method: "GET",
            params: { username: { required: true, type: "string" } },
            url: "/users/:username"
        },
        getContextForUser: {
            method: "GET",
            params: {
                subject_id: { type: "string" },
                subject_type: {
                    enum: ["organization", "repository", "issue", "pull_request"],
                    type: "string"
                },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/hovercard"
        },
        getGpgKey: {
            method: "GET",
            params: { gpg_key_id: { required: true, type: "integer" } },
            url: "/user/gpg_keys/:gpg_key_id"
        },
        getPublicKey: {
            method: "GET",
            params: { key_id: { required: true, type: "integer" } },
            url: "/user/keys/:key_id"
        },
        list: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                since: { type: "string" }
            },
            url: "/users"
        },
        listBlocked: { method: "GET", params: {}, url: "/user/blocks" },
        listEmails: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/emails"
        },
        listFollowersForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/followers"
        },
        listFollowersForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/followers"
        },
        listFollowingForAuthenticatedUser: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/following"
        },
        listFollowingForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/following"
        },
        listGpgKeys: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/gpg_keys"
        },
        listGpgKeysForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/gpg_keys"
        },
        listPublicEmails: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/public_emails"
        },
        listPublicKeys: {
            method: "GET",
            params: { page: { type: "integer" }, per_page: { type: "integer" } },
            url: "/user/keys"
        },
        listPublicKeysForUser: {
            method: "GET",
            params: {
                page: { type: "integer" },
                per_page: { type: "integer" },
                username: { required: true, type: "string" }
            },
            url: "/users/:username/keys"
        },
        togglePrimaryEmailVisibility: {
            method: "PATCH",
            params: {
                email: { required: true, type: "string" },
                visibility: { required: true, type: "string" }
            },
            url: "/user/email/visibility"
        },
        unblock: {
            method: "DELETE",
            params: { username: { required: true, type: "string" } },
            url: "/user/blocks/:username"
        },
        unfollow: {
            method: "DELETE",
            params: { username: { required: true, type: "string" } },
            url: "/user/following/:username"
        },
        updateAuthenticated: {
            method: "PATCH",
            params: {
                bio: { type: "string" },
                blog: { type: "string" },
                company: { type: "string" },
                email: { type: "string" },
                hireable: { type: "boolean" },
                location: { type: "string" },
                name: { type: "string" }
            },
            url: "/user"
        }
    }
};

const VERSION = "2.4.0";

function registerEndpoints(octokit, routes) {
    Object.keys(routes).forEach(namespaceName => {
        if (!octokit[namespaceName]) {
            octokit[namespaceName] = {};
        }
        Object.keys(routes[namespaceName]).forEach(apiName => {
            const apiOptions = routes[namespaceName][apiName];
            const endpointDefaults = ["method", "url", "headers"].reduce((map, key) => {
                if (typeof apiOptions[key] !== "undefined") {
                    map[key] = apiOptions[key];
                }
                return map;
            }, {});
            endpointDefaults.request = {
                validate: apiOptions.params
            };
            let request = octokit.request.defaults(endpointDefaults);
            // patch request & endpoint methods to support deprecated parameters.
            // Not the most elegant solution, but we don’t want to move deprecation
            // logic into octokit/endpoint.js as it’s out of scope
            const hasDeprecatedParam = Object.keys(apiOptions.params || {}).find(key => apiOptions.params[key].deprecated);
            if (hasDeprecatedParam) {
                const patch = patchForDeprecation.bind(null, octokit, apiOptions);
                request = patch(octokit.request.defaults(endpointDefaults), `.${namespaceName}.${apiName}()`);
                request.endpoint = patch(request.endpoint, `.${namespaceName}.${apiName}.endpoint()`);
                request.endpoint.merge = patch(request.endpoint.merge, `.${namespaceName}.${apiName}.endpoint.merge()`);
            }
            if (apiOptions.deprecated) {
                octokit[namespaceName][apiName] = Object.assign(function deprecatedEndpointMethod() {
                    octokit.log.warn(new Deprecation(`[@octokit/rest] ${apiOptions.deprecated}`));
                    octokit[namespaceName][apiName] = request;
                    return request.apply(null, arguments);
                }, request);
                return;
            }
            octokit[namespaceName][apiName] = request;
        });
    });
}
function patchForDeprecation(octokit, apiOptions, method, methodName) {
    const patchedMethod = (options) => {
        options = Object.assign({}, options);
        Object.keys(options).forEach(key => {
            if (apiOptions.params[key] && apiOptions.params[key].deprecated) {
                const aliasKey = apiOptions.params[key].alias;
                octokit.log.warn(new Deprecation(`[@octokit/rest] "${key}" parameter is deprecated for "${methodName}". Use "${aliasKey}" instead`));
                if (!(aliasKey in options)) {
                    options[aliasKey] = options[key];
                }
                delete options[key];
            }
        });
        return method(options);
    };
    Object.keys(method).forEach(key => {
        patchedMethod[key] = method[key];
    });
    return patchedMethod;
}

/**
 * This plugin is a 1:1 copy of internal @octokit/rest plugins. The primary
 * goal is to rebuild @octokit/rest on top of @octokit/core. Once that is
 * done, we will remove the registerEndpoints methods and return the methods
 * directly as with the other plugins. At that point we will also remove the
 * legacy workarounds and deprecations.
 *
 * See the plan at
 * https://github.com/octokit/plugin-rest-endpoint-methods.js/pull/1
 */
function restEndpointMethods(octokit) {
    // @ts-ignore
    octokit.registerEndpoints = registerEndpoints.bind(null, octokit);
    registerEndpoints(octokit, endpointsByScope);
    // Aliasing scopes for backward compatibility
    // See https://github.com/octokit/rest.js/pull/1134
    [
        ["gitdata", "git"],
        ["authorization", "oauthAuthorizations"],
        ["pullRequests", "pulls"]
    ].forEach(([deprecatedScope, scope]) => {
        Object.defineProperty(octokit, deprecatedScope, {
            get() {
                octokit.log.warn(
                // @ts-ignore
                new Deprecation(`[@octokit/plugin-rest-endpoint-methods] "octokit.${deprecatedScope}.*" methods are deprecated, use "octokit.${scope}.*" instead`));
                // @ts-ignore
                return octokit[scope];
            }
        });
    });
    return {};
}
restEndpointMethods.VERSION = VERSION;

export { restEndpointMethods };
//# sourceMappingURL=index.js.map
