export declare function registerEndpoints(octokit: any, routes: any): void;
