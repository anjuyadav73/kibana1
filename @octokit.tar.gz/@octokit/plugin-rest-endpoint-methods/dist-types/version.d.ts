export declare const VERSION = "2.4.0";
