/**
 * Abort signal
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal
 */
export declare type Signal = any;
