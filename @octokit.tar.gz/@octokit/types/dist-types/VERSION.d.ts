export declare const VERSION = "6.40.0";
