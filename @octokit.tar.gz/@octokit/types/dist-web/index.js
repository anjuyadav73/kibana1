const VERSION = "6.40.0";

export { VERSION };
//# sourceMappingURL=index.js.map
