const withDefaults = require('./with-defaults')
const DEFAULTS = require('./lib/defaults')

module.exports = withDefaults(null, DEFAULTS)
