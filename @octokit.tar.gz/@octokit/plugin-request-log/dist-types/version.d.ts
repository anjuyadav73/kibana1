export declare const VERSION = "1.0.4";
