export declare const VERSION = "5.0.0";
