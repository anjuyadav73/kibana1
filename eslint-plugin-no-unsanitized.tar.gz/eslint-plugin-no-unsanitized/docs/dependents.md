# Projects and Tool using eslint-plugin-no-unsanitized

* [Kibana](https://github.com/elastic/kibana/pull/16477)
