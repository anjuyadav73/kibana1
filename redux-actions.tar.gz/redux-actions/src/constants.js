export const DEFAULT_NAMESPACE = '/';
export const ACTION_TYPE_DELIMITER = '||';
