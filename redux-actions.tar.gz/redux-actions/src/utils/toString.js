export default value => value.toString();
