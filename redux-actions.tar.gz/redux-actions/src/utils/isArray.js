export default value => Array.isArray(value);
