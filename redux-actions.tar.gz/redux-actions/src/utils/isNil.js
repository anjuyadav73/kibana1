export default value => value === null || value === undefined;
