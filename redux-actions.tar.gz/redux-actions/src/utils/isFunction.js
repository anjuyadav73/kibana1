export default value => typeof value === 'function';
