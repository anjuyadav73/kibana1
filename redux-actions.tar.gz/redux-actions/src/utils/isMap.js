export default value => typeof Map !== 'undefined' && value instanceof Map;
