export default value => typeof value === 'string';
