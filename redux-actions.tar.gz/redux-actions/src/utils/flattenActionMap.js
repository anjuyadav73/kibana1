import isPlainObject from './isPlainObject';
import flattenWhenNode from './flattenWhenNode';

export default flattenWhenNode(isPlainObject);
