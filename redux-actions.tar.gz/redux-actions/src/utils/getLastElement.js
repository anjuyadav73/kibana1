export default array => array[array.length - 1];
