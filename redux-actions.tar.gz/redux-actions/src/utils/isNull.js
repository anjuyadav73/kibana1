export default value => value === null;
