export default value => value === undefined;
