export default value => value.length === 0;
