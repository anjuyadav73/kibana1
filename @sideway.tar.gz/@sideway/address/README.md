# @sideway/address

#### Validate email address and domain.

**address** is part of the **joi** ecosystem.

### Visit the [joi.dev](https://joi.dev) Developer Portal for tutorials, documentation, and support

## Useful resources

- [Documentation and API](https://joi.dev/module/address/)
- [Versions status](https://joi.dev/resources/status/#address)
- [Changelog](https://joi.dev/module/address/changelog/)
- [Project policies](https://joi.dev/policies/)
