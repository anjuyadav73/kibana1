// TypeScript Version: 3.4

import {Plugin} from 'unified'

declare const remarkBreaks: Plugin<[]>

export = remarkBreaks
