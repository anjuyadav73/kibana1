# text-hex

Transforms a given piece of text to a hex color.

## Install

```
npm install text-hex
```

## Usage

```js
var hex = require('text-hex');
console.log(hex('foo'));
```

## License

MIT
