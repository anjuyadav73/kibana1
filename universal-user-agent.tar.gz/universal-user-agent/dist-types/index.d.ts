export declare function getUserAgent(): string;
