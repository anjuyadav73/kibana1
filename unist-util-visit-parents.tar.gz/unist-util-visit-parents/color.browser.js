module.exports = identity
function identity(d) {
  return d
}
