module.exports = color
function color(d) {
  return '\u001B[33m' + d + '\u001B[39m'
}
