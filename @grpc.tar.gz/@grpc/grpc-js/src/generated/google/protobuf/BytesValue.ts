// Original file: null


export interface BytesValue {
  'value'?: (Buffer | Uint8Array | string);
}

export interface BytesValue__Output {
  'value': (Buffer);
}
