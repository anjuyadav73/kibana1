// Original file: null


export interface DoubleValue {
  'value'?: (number | string);
}

export interface DoubleValue__Output {
  'value': (number);
}
