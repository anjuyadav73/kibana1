
1.0.1 / 2021-04-01
==================

  * chore: update repository URL in package.json


1.0.0 / 2020-11-12
==================

  * chore: add license to package.json

0.0.3 / 2020-11-04
==================

  * fix: bump component.json

0.0.2 / 2020-11-04
==================

  * Fix possible regex dos vulnerability (Patrick Way)

0.0.1 / 2010-01-03
==================

  * Initial release
