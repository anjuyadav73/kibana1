browserify-des
===

DES for browserify
