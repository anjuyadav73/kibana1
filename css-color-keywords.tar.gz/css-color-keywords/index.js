'use strict'

module.exports = require('./colors.json')
