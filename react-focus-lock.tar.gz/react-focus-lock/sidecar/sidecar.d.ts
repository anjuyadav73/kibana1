import * as React from 'react';

declare var sidecar: React.FC;

export default sidecar;
