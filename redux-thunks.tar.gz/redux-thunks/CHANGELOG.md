# v0.3.0

- Pass the action `type` to handler via context

# v0.2.0

- Publish compiled cjs version, with original es6 module

# v0.1.0

- Initial version of module, with tests
