module.exports = require('./dec/decode').BrotliDecompressBuffer;
