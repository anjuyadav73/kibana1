
# Release History

## 1.1.1

- Add dependency on `debug` to log results of the file system checks
- Add `jest` tests

# 1.0.0

- First public release, a simple typescript library for checking whether a path exists
  on the file system and optionally whether it points to a file or folder. 
