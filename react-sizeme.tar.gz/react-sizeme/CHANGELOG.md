We follow semantic versioning.

See the [releases](https://github.com/ctrlplusb/react-sizeme/releases) page on
GitHub for information regarding each release.
