module.exports = require('../dist/esm/frameworks/angular/index');
