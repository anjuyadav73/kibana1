export * from '../dist/ts3.9/frameworks/angular/index.d';
