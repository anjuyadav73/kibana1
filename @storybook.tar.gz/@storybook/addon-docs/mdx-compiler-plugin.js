module.exports = require('@storybook/csf-tools/mdx').createCompiler;
