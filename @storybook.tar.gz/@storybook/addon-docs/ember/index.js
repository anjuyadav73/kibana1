module.exports = require('../dist/esm/frameworks/ember');
