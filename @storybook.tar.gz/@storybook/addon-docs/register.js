require('./dist/esm/register.js');
