// storyshots is not a typical addon because it's just a command-line tool
// nevertheless if you add it to .storybook/main.js it shouldn't complain
// https://github.com/storybookjs/storybook/issues/7959
module.exports = {};
