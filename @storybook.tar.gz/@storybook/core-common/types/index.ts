export type { StorybookConfig } from '../dist/ts3.9/types';
