module.exports = require('./dist/cjs/utils/prebuilt-manager');
