export * from './dist/ts3.9/utils/prebuilt-manager.d';
