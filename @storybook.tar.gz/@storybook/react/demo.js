/* eslint-disable global-require */
module.exports = {
  Welcome: require('./dist/esm/demo/Welcome').default,
  Button: require('./dist/esm/demo/Button').default,
};
