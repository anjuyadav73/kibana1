# Storybook Theming

Storybook Theming is a wrapper library for emotion.
It ensures a single version of emotion is used everywhere.

It also includes some ready to use themes: light (normal) and dark.
