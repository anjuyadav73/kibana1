export * from './dist/ts3.9/mdx/index.d';
