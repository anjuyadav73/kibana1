# Storybook Components

Storybook Components is a React UI components collection used by the UI of Storybook and Addons.

All components use [`emotion`](https://emotion.sh) for styling.
