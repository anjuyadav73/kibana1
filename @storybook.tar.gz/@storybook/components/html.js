module.exports = require('./dist/cjs/html');
