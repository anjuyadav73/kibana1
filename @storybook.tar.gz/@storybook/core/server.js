module.exports = require('./dist/cjs/server');
