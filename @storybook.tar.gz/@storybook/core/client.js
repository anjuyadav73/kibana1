// @storybook/core was split into core-client and core-server.  This file is for backwards-compat.
// TODO: remove in 7.0
module.exports = require('./dist/esm/index');
