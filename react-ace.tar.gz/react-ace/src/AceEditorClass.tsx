export class AceEditorClass {
  [index: string]: any;
}
