export declare class AceEditorClass {
    [index: string]: any;
}
