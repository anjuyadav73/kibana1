/**
 * @since 2.0.0
 */
import { IO } from './IO'
/**
 * @since 2.0.0
 */
export declare function log(s: unknown): IO<void>
/**
 * @since 2.0.0
 */
export declare function warn(s: unknown): IO<void>
/**
 * @since 2.0.0
 */
export declare function error(s: unknown): IO<void>
/**
 * @since 2.0.0
 */
export declare function info(s: unknown): IO<void>
