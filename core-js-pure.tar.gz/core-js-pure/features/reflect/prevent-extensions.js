var parent = require('../../stable/reflect/prevent-extensions');

module.exports = parent;
