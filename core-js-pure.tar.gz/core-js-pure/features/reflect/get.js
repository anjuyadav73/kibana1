var parent = require('../../stable/reflect/get');

module.exports = parent;
