require('../../modules/esnext.reflect.has-own-metadata');
var path = require('../../internals/path');

module.exports = path.Reflect.hasOwnMetadata;
