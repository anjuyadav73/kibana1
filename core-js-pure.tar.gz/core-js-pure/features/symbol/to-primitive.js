var parent = require('../../stable/symbol/to-primitive');

module.exports = parent;
