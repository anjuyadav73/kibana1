var parent = require('../../stable/array-buffer/constructor');

module.exports = parent;
