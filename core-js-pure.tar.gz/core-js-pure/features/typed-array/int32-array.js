var parent = require('../../stable/typed-array/int32-array');
require('../../features/typed-array/methods');

module.exports = parent;
