var parent = require('../../stable/typed-array/uint32-array');
require('../../features/typed-array/methods');

module.exports = parent;
