var parent = require('../../stable/typed-array/uint8-clamped-array');
require('../../features/typed-array/methods');

module.exports = parent;
