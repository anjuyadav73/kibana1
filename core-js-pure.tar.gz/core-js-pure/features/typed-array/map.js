var parent = require('../../stable/typed-array/map');

module.exports = parent;
