var parent = require('../../stable/typed-array/every');

// TODO: Remove from `core-js@4`
require('../../modules/esnext.typed-array.at');

module.exports = parent;
