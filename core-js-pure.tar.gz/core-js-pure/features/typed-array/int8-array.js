var parent = require('../../stable/typed-array/int8-array');
require('../../features/typed-array/methods');

module.exports = parent;
