var parent = require('../../stable/typed-array/int16-array');
require('../../features/typed-array/methods');

module.exports = parent;
