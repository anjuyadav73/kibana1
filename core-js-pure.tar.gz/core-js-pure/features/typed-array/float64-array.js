var parent = require('../../stable/typed-array/float64-array');
require('../../features/typed-array/methods');

module.exports = parent;
