var parent = require('../../stable/typed-array/reverse');

module.exports = parent;
