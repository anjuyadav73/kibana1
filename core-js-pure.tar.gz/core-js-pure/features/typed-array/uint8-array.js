var parent = require('../../stable/typed-array/uint8-array');
require('../../features/typed-array/methods');

module.exports = parent;
