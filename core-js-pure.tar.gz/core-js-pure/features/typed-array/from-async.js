require('../../modules/esnext.typed-array.from-async');
