var parent = require('../../stable/typed-array/keys');

module.exports = parent;
