var parent = require('../../stable/typed-array/of');

module.exports = parent;
