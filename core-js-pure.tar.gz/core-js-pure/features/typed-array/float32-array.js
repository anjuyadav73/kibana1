var parent = require('../../stable/typed-array/float32-array');
require('../../features/typed-array/methods');

module.exports = parent;
