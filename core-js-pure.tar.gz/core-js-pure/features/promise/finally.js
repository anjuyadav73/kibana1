var parent = require('../../stable/promise/finally');

module.exports = parent;
