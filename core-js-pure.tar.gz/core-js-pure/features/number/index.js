var parent = require('../../stable/number');

module.exports = parent;

require('../../modules/es.object.to-string');
require('../../modules/esnext.number.from-string');
require('../../modules/esnext.number.range');
