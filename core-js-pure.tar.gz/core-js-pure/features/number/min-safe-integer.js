var parent = require('../../stable/number/min-safe-integer');

module.exports = parent;
