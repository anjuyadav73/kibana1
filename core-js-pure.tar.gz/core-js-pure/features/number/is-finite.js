var parent = require('../../stable/number/is-finite');

module.exports = parent;
