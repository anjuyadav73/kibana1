var parent = require('../../stable/object/seal');

module.exports = parent;
