var parent = require('../../stable/object/from-entries');

module.exports = parent;
