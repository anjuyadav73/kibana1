var parent = require('../../stable/object/is-frozen');

module.exports = parent;
