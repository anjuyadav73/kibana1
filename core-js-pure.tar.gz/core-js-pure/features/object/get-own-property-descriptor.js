var parent = require('../../stable/object/get-own-property-descriptor');

module.exports = parent;
