var parent = require('../../stable/object/has-own');

// TODO: Remove from `core-js@4`
require('../../modules/esnext.object.has-own');

module.exports = parent;
