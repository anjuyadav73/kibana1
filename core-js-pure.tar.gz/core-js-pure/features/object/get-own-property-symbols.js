var parent = require('../../stable/object/get-own-property-symbols');

module.exports = parent;
