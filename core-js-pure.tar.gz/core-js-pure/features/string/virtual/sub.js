var parent = require('../../../stable/string/virtual/sub');

module.exports = parent;
