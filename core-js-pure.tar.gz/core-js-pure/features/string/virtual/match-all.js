// TODO: remove from `core-js@4`
require('../../../modules/esnext.string.match-all');

var parent = require('../../../stable/string/virtual/match-all');

module.exports = parent;
