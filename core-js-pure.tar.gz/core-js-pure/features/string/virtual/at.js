require('../../../stable/string/virtual/at');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.string.at');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').at;
