var parent = require('../../../stable/string/virtual/substr');

module.exports = parent;
