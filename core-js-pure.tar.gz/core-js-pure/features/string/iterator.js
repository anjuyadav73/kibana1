var parent = require('../../stable/string/iterator');

module.exports = parent;
