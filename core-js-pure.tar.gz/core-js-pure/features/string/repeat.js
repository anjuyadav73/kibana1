var parent = require('../../stable/string/repeat');

module.exports = parent;
