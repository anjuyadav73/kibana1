var parent = require('../../stable/string/fixed');

module.exports = parent;
