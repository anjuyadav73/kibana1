var parent = require('../../stable/string/ends-with');

module.exports = parent;
