// TODO: remove from `core-js@4`
require('../../modules/esnext.string.replace-all');

var parent = require('../../stable/string/replace-all');

module.exports = parent;
