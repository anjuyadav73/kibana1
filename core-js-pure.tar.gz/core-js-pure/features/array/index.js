var parent = require('../../stable/array');
require('../../modules/es.map');
require('../../modules/es.promise');
require('../../modules/esnext.array.from-async');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.at');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.filter-out');
require('../../modules/esnext.array.filter-reject');
require('../../modules/esnext.array.find-last');
require('../../modules/esnext.array.find-last-index');
require('../../modules/esnext.array.group-by');
require('../../modules/esnext.array.is-template-object');
require('../../modules/esnext.array.last-item');
require('../../modules/esnext.array.last-index');
require('../../modules/esnext.array.unique-by');

module.exports = parent;
