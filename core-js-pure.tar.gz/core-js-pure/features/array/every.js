var parent = require('../../stable/array/every');

module.exports = parent;
