var parent = require('../../../stable/array/virtual/flat-map');

module.exports = parent;
