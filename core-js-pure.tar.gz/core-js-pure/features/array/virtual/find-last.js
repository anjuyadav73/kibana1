require('../../../modules/esnext.array.find-last');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').findLast;
