var parent = require('../../../stable/array/virtual/every');

module.exports = parent;
