var parent = require('../../../stable/array/virtual/iterator');

module.exports = parent;
