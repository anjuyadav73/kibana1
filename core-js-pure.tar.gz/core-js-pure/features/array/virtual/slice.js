var parent = require('../../../stable/array/virtual/slice');

module.exports = parent;
