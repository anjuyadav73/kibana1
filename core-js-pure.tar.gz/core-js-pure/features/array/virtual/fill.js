var parent = require('../../../stable/array/virtual/fill');

module.exports = parent;
