var parent = require('../../../stable/array/virtual/last-index-of');

module.exports = parent;
