require('../../../modules/esnext.array.filter-reject');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').filterReject;
