var parent = require('../../stable/array/index-of');

module.exports = parent;
