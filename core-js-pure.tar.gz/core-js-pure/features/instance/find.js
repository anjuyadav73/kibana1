var parent = require('../../stable/instance/find');

module.exports = parent;
