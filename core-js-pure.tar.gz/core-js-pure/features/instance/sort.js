var parent = require('../../stable/instance/sort');

module.exports = parent;
