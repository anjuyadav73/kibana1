var parent = require('../../stable/instance/reverse');

module.exports = parent;
