var parent = require('../../stable/instance/repeat');

module.exports = parent;
