require('../../modules/es.set');
require('../../modules/esnext.set.join');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Set', 'join');
