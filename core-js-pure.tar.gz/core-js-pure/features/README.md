This folder contains entry points for all `core-js` features with dependencies. It's the recommended way for usage only required features.
