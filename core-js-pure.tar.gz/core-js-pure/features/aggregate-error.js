// TODO: remove from `core-js@4`
require('../modules/esnext.aggregate-error');

var parent = require('../stable/aggregate-error');

module.exports = parent;
