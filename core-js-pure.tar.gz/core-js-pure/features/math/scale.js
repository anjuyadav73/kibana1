require('../../modules/esnext.math.scale');
var path = require('../../internals/path');

module.exports = path.Math.scale;
