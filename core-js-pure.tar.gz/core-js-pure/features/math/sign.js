var parent = require('../../stable/math/sign');

module.exports = parent;
