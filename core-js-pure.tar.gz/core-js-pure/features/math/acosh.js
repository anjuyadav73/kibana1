var parent = require('../../stable/math/acosh');

module.exports = parent;
