require('../../modules/esnext.math.umulh');
var path = require('../../internals/path');

module.exports = path.Math.umulh;
