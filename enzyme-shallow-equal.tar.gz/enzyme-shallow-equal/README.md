# enzyme-shallow-equal

This is the implementation of shallowEqual that enzyme uses.

It's adapted from https://github.com/facebook/react/blob/144328fe81719e916b946e22660479e31561bb0b/packages/shared/shallowEqual.js#L36-L68
