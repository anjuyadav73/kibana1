declare const useInterval: (callback: Function, delay?: number | null | undefined) => void;
export default useInterval;
