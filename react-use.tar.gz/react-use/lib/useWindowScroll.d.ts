export interface State {
    x: number;
    y: number;
}
declare const useWindowScroll: () => State;
export default useWindowScroll;
