declare const useError: () => (err: Error) => void;
export default useError;
