declare const useMount: (fn: () => void) => void;
export default useMount;
