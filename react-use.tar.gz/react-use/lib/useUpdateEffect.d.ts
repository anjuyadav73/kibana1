import { useEffect } from 'react';
declare const useUpdateEffect: typeof useEffect;
export default useUpdateEffect;
