declare const useThrottle: <T>(value: T, ms?: number) => T;
export default useThrottle;
