import { EffectCallback } from 'react';
declare const useEffectOnce: (effect: EffectCallback) => void;
export default useEffectOnce;
