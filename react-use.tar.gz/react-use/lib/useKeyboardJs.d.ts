declare const useKeyboardJs: (combination: string | string[]) => [boolean, KeyboardEvent | null];
export default useKeyboardJs;
