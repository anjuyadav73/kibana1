declare const useBeforeUnload: (enabled?: boolean | (() => boolean), message?: string | undefined) => void;
export default useBeforeUnload;
