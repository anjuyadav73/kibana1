export declare type UseQueryParam = (param: string) => string | null;
declare const _default: UseQueryParam;
export default _default;
