declare const useLogger: (componentName: string, ...rest: any[]) => void;
export default useLogger;
