export default function usePrevious<T>(state: T): T | undefined;
