declare const UseKey: (props: any) => any;
export default UseKey;
