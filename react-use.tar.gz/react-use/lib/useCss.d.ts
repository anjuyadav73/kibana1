declare const useCss: (css: object) => string;
export default useCss;
