export declare type Easing = (t: number) => number;
declare const useTween: (easingName?: string, ms?: number, delay?: number) => number;
export default useTween;
