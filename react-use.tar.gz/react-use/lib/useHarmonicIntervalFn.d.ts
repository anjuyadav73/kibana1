declare const useHarmonicIntervalFn: (fn: Function, delay?: number | null) => void;
export default useHarmonicIntervalFn;
