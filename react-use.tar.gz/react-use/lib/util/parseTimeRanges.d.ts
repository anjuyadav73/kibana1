declare const parseTimeRanges: (ranges: any) => {
    start: number;
    end: number;
}[];
export default parseTimeRanges;
