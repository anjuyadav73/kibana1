declare const createRenderProp: (hook: any, mapPropsToArgs?: (props: any) => any[]) => (props: any) => any;
export default createRenderProp;
