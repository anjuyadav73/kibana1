declare const useStartTyping: (onStartTyping: (event: KeyboardEvent) => void) => void;
export default useStartTyping;
