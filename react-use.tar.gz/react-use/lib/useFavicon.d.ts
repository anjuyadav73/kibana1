declare const useFavicon: (href: string) => void;
export default useFavicon;
