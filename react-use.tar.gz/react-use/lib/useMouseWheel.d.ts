declare const _default: () => number;
export default _default;
