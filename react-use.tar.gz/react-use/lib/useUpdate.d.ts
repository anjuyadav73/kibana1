declare const useUpdate: () => () => void;
export default useUpdate;
