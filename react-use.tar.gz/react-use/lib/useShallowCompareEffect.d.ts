import { DependencyList, EffectCallback } from 'react';
declare const useShallowCompareEffect: (effect: EffectCallback, deps: DependencyList) => void;
export default useShallowCompareEffect;
