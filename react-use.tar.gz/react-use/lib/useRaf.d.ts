declare const useRaf: (ms?: number, delay?: number) => number;
export default useRaf;
