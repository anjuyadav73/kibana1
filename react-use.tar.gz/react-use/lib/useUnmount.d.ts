declare const useUnmount: (fn: () => any) => void;
export default useUnmount;
