export declare function useFirstMountState(): boolean;
