export declare function useRendersCount(): number;
