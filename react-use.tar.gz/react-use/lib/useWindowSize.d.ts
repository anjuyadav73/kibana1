declare const useWindowSize: (initialWidth?: number, initialHeight?: number) => {
    width: number;
    height: number;
};
export default useWindowSize;
