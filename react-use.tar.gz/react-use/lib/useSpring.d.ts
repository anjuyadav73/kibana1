declare const useSpring: (targetValue?: number, tension?: number, friction?: number) => number;
export default useSpring;
