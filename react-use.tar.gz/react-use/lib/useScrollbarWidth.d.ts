export declare function useScrollbarWidth(): number | undefined;
