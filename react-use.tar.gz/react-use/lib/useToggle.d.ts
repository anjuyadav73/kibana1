declare const useToggle: (initialValue: boolean) => [boolean, (nextValue?: any) => void];
export default useToggle;
