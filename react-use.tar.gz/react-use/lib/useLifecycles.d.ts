declare const useLifecycles: (mount: any, unmount?: any) => void;
export default useLifecycles;
