export default function useMountedState(): () => boolean;
