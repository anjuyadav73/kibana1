declare const usePageLeave: (onPageLeave: any, args?: never[]) => void;
export default usePageLeave;
