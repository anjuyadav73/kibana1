import useNumber from './useCounter';
export default useNumber;
