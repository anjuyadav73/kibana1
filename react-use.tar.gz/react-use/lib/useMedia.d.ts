declare const useMedia: (query: string, defaultState?: boolean) => boolean;
export default useMedia;
