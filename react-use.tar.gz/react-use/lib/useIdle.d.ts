declare const useIdle: (ms?: number, initialState?: boolean, events?: string[]) => boolean;
export default useIdle;
