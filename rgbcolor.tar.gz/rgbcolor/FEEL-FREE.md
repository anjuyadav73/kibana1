http://www.phpied.com/rgb-color-parser-in-javascript/

Feel free to use the code for your own color picker tool or whatever you feel
like. If you let me know how you use it, that would be even greater. Meanwhile
any other comments are highly appreciated. 
