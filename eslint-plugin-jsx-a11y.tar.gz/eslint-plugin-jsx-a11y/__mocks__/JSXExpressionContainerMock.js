export default function JSXExpressionContainerMock(exp) {
  return {
    type: 'JSXExpressionContainer',
    expression: exp,
  };
}
