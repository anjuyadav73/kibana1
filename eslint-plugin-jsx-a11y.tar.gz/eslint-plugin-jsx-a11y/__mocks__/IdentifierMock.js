export default function IdentifierMock(ident) {
  return {
    type: 'Identifier',
    name: ident,
  };
}
