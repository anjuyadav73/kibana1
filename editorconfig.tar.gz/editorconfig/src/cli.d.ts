export default function cli(args: string[]): void;
