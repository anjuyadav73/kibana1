# vega-voronoi

Voronoi diagram transform for Vega dataflows.

This package provides the following Vega data transform:

- [**Voronoi**](https://vega.github.io/vega/docs/transforms/voronoi/) [&lt;&gt;](https://github.com/vega/vega/blob/master/packages/vega-voronoi/src/Voronoi.js "Source")
