export {default as voronoi} from './src/Voronoi';
