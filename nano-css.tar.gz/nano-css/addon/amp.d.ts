import {NanoRenderer} from '../types/nano';

export interface AmpAddon {}

export function addon(nano: NanoRenderer);
