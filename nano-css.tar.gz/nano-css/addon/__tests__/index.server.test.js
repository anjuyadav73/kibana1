/** @jest-environment node */
'use strict';

require('./index.test');
