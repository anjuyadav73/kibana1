/** @jest-environment node */

/* eslint-disable */
'use strict';

require('./atoms.test');
