/** @jest-environment node */
'use strict';

process.env.NODE_ENV = 'development';

require('./jsx.test');
