'use strict';

process.env.NODE_ENV = 'development';

require('./put.test');
