/** @jest-environment node */

/* eslint-disable */
'use strict';

process.env.NODE_ENV = 'development';

require('./atoms.test');
