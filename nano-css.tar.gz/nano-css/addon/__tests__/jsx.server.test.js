/** @jest-environment node */
'use strict';

require('./jsx.test');
