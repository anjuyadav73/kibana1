/** @jest-environment node */

/* eslint-disable */
'use strict';

require('./emmet.test');
