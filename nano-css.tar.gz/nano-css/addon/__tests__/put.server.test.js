/** @jest-environment node */
'use strict';

require('./put.test');
