/** @jest-environment node */
'use strict';

require('./keyframes.test');
