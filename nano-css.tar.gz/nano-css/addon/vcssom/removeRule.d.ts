import {CSSOMRule} from '../cssom';

export function removeRule(sh: CSSStyleSheet, rule: CSSOMRule);
