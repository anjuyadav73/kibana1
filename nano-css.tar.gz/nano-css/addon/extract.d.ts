import {NanoRenderer} from '../types/nano';

export interface ExtractAddon {}

export function addon(nano: NanoRenderer);
