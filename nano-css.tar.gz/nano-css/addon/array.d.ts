import {NanoRenderer} from '../types/nano';

export interface ArrayAddon {}

export function addon(nano: NanoRenderer);
