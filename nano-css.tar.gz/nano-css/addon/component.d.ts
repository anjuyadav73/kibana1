import {NanoRenderer} from '../types/nano';

export interface ComponentAddon {
    Component;
}

export function addon(nano: NanoRenderer);
