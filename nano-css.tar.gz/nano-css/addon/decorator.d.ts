import {NanoRenderer} from '../types/nano';

export interface DecoratorAddon {
    css;
}

export function addon(nano: NanoRenderer);
