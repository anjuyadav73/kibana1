import {create} from '..';

const nano = create();

nano.rule({
    cursor: 'pointer',
});
