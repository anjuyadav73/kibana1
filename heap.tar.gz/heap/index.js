module.exports = require('./lib/heap');
