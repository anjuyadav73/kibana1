export declare function processSize(size: number | string): string | number;
export declare function noop(): void;
