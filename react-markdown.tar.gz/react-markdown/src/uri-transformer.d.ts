export = uriTransformer
/**
 * @param {string} uri
 * @returns {string}
 */
declare function uriTransformer(uri: string): string
