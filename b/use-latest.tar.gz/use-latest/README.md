# use-latest

A React helper hook for storing latest value in ref object (updated in useEffect's callback).
