export declare const getBrowserData: (edgeBinaryPath?: string | undefined) => Promise<{
    path: string;
    version: string;
} | undefined>;
