
1.0.0 - January 21, 2016
------------------------
* fix to remove leading spaces
* drop component support
* cleanup readme
* add travis ci
* update coding style

0.1.3 - October 24, 2013
------------------------
* update `to-no-case`

0.1.2 - October 1, 2013
-----------------------
* update `to-no-case`

0.1.1 - September 18, 2013
--------------------------
* update `to-no-case`

0.1.0 - September 18, 2013
--------------------------
* overhaul to use `to-no-case`

0.0.3 - September 18, 2013
--------------------------
* update `from-camel-case`

0.0.2 - September 18, 2013
--------------------------
* handle multiple spaces
* lowercase result

0.0.1 - September 18, 2013
--------------------------
:sparkles:
