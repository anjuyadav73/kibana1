var stdout = require('../../');

stdout.write('hello\n');
stdout.write('world\n');