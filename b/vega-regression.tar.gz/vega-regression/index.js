export {default as loess} from './src/Loess';
export {default as regression} from './src/Regression';
