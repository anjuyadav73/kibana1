import {BinaryFeaturesData} from '../types';

export function geojsonToBinary(features: object[], options?: object): BinaryFeaturesData;
export const TEST_EXPORTS: object;
