# @loaders.gl/gis

This module contains helper classes for the GIS category of loaders.

[loaders.gl](https://loaders.gl/docs) is a collection of framework-independent visualization-focused loaders (parsers).
