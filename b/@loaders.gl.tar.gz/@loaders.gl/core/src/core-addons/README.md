These experimental classes should be moved to another module.
