export function writeFile(filePath, arrayBufferOrString, options?);
export function writeFileSync(filePath, arrayBufferOrString, options?);