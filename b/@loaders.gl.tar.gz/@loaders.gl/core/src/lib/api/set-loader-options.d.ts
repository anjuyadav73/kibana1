/**
 * Set global loader options
 * @param options 
 */
export function setLoaderOptions(options: object): void;
