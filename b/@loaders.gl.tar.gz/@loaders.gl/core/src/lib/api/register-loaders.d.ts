export function registerLoaders(loaders);
export function getRegisteredLoaders();
export function _unregisterLoaders();
