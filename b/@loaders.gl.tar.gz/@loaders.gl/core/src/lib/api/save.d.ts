export function save(data, url, writer, options?): any;
export function saveSync(data, url, writer, options?): any;
