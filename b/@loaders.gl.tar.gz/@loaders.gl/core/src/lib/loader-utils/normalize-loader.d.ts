import {LoaderObject} from '@loaders.gl/loader-utils';

export function isLoaderObject(loader: LoaderObject): boolean;
export function normalizeLoader(loader: LoaderObject): LoaderObject;
