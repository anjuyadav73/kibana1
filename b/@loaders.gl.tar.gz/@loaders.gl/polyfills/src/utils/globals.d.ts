export const isBrowser: boolean;
export const global: object;
