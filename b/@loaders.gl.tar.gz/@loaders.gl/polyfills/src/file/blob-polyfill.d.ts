export const BlobPolyfill: typeof Blob;
