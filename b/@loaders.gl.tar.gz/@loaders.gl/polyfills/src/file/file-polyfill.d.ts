export const FilePolyfill: typeof File;

export const FileReaderPolyfill: typeof FileReader;