export const ReadableStreamPolyfill: typeof ReadableStream;
