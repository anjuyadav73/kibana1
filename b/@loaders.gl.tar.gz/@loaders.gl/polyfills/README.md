# @loaders.gl/polyfills

[loaders.gl](https://loaders.gl/docs) is a collection of framework-independent 3D and geospatial parsers and encoders.

This module contains polyfills for running on older browsers (mainly Edge and IE11) as well as Node.

For documentation please visit the [website](https://loaders.gl).
