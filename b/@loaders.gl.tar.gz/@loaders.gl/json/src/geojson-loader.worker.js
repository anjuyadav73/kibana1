import {GeoJSONLoader} from './geojson-loader';
import {createWorker} from '@loaders.gl/loader-utils';

createWorker(GeoJSONLoader);
