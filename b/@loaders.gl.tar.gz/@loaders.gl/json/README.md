# @loaders.gl/json

This module contains a table loader for the JSON and line delimited JSON formats.

[loaders.gl](https://loaders.gl/docs) is a collection of framework-independent visualization-focused loaders (parsers).
