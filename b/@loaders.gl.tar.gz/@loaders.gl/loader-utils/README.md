# @loaders.gl/core

This module contains shared utilities for loaders.gl, a collection of framework-independent 3D and geospatial loaders (parsers).

For documentation please visit the [website](https://loaders.gl).
