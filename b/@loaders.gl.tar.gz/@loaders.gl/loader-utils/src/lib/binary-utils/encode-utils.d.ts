// Note: These were broken out from gltf loader...
export function padStringToByteAlignment(string, byteAlignment);
export function copyStringToDataView(dataView, byteOffset, string, byteLength);
export function copyBinaryToDataView(dataView, byteOffset, binary, byteLength);
