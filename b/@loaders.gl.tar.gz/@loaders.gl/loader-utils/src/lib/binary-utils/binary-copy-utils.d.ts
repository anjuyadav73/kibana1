export function copyPaddedArrayBufferToDataView(dataView, byteOffset, sourceBuffer);
export function copyPaddedStringToDataView(dataView, byteOffset, string);
