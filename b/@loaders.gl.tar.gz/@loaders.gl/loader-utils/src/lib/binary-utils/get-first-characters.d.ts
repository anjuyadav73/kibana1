export function getFirstCharacters(data, length?: number);
export function getMagicString(arrayBuffer, byteOffset: number, length: number);
