export const self: object;
export const window: object;
export const global: object;
export const document: object;

export const isBrowser: boolean;
export const isWorker: boolean;
export const nodeVersion: number;
