
/**
 * Set up a WebWorkerGlobalScope to talk with the main thread
 * @param loader
 */
export default function createWorker(loader: any);
