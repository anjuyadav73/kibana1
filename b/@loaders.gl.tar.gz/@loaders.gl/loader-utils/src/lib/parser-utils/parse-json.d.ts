/**
 * Minimal JSON parser that throws more meaningful error messages
 */
export function parseJSON(string: string): any;
