import {BinaryGeometryData} from '@loaders.gl/gis';

export function parseRecord(view: DataView, options: object): BinaryGeometryData | null;
