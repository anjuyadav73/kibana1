import {DBFLoader} from '../dbf-loader';
import {createWorker} from '@loaders.gl/loader-utils';

createWorker(DBFLoader);
