import {SHPLoader} from '../shp-loader';
import {createWorker} from '@loaders.gl/loader-utils';

createWorker(SHPLoader);
