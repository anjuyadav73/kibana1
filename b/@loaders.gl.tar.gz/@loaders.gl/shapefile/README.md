# @loaders.gl/shapefile

This module contains a geometry loader for the ESRI Shapefile format.

[loaders.gl](https://loaders.gl/docs) is a collection of framework-independent visualization-focused loaders (parsers).
