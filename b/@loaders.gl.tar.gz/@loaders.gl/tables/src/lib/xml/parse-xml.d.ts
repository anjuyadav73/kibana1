export default function parseXML(xml: string): any;
export function parseXMLSupported(): boolean;
