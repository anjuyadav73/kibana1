import Schema from './schema';

export function deduceTableSchema(table, schema?: Schema);
