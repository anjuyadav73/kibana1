export default function assert(condition: boolean, message?: string);
