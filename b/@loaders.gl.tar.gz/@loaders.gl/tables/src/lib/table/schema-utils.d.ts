import {Schema} from './table-types';

export function deduceTableSchema(table, schema?: Schema);
