# @loaders.gl/tables

This module contains:

- Classes and APIs for manipulating tabular data output from loaders.gl table category loaders (CSV, JSON, ...).

[loaders.gl](https://loaders.gl/docs) is a collection of framework-independent 3D and geospatial parsers and encoders.

Please visit the [website](https://loaders.gl).
