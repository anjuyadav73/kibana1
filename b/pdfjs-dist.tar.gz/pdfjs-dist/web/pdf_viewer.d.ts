export * from "../types/web/pdf_viewer.component";
