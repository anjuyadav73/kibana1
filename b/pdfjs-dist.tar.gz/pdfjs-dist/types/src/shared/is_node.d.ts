export const isNodeJS: boolean;
