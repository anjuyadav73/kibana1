export let NodeCanvasFactory: {
    new (): {};
};
export let NodeCMapReaderFactory: {
    new (): {};
};
export let NodeStandardFontDataFactory: {
    new (): {};
};
