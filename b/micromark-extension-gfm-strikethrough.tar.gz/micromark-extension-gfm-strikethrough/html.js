exports.enter = {strikethrough: onenterstrikethrough}
exports.exit = {strikethrough: onexitstrikethrough}

function onenterstrikethrough() {
  this.tag('<del>')
}

function onexitstrikethrough() {
  this.tag('</del>')
}
