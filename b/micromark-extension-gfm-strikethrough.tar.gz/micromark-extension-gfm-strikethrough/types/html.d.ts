import {HtmlExtension} from 'micromark/dist/shared-types'

/**
 * The export of `html` is an extension for the default HTML compiler (to
 * compile as `<del>` elements; can be passed in `htmlExtensions`).
 */
declare const html: HtmlExtension
export = html
