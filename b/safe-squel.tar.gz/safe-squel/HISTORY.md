
5.12.5 / 2019-11-04
==================

  * fix: fix empty string bug
  * chore: bump to 5.12.5
  * fix: fix mysql empty string

5.12.4 / 2018-09-20
==================

  * chore: bump to 5.12.4
  * fix: add full SQL escape support

5.12.3 / 2018-09-20
==================

  * chore: new verison for squel
  * feat: add MySQL INSERT IGNORE support
  * chore: Update README.md ([#293](http://github.com/yibn2008/safe-squel/issues/293))
  * Makefile: should work with travis now.
