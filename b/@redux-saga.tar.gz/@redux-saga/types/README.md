# @redux-saga/types

Repository for shared types used by `redux-saga` packages. Shouldn't be used directly - it's purpose is to avoid cyclic dependencies between `redux-saga` packages.
