declare function _exports(values: import('postcss-value-parser').Node[][]): string;
export = _exports;
