declare function _exports(grid: string[]): string;
export = _exports;
