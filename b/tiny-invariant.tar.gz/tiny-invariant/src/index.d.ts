export default function invariant(condition: any, message?: string): void
