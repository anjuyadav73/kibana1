'use strict';

const path = require('path');

module.exports = function(dir, filename) {
    return /^\.\./.test(path.relative(dir, filename));
};
