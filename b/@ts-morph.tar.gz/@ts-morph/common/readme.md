# @ts-morph/common

Common functionality for [ts-morph](../ts-morph) and [@ts-morph/bootstrap](../bootstrap).

Please do not depend on this library!
