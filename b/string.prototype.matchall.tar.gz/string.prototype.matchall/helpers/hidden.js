'use strict';

// TODO, semver-major: delete this file

module.exports = require('side-channel');
