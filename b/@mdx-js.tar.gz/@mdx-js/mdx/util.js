// For backwards compatibility with downstream users
// of MDX utilities
module.exports = require('@mdx-js/util')
