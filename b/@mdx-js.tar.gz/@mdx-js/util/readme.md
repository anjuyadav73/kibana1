# [@mdx-js/util][mdx]

Utility functions used in [MDX][] libraries.

## Installation

```sh
yarn add @mdx-js/util
```

## License

[MIT][] © [John Otander][author]

<!-- Definitions -->

[mit]: license
[mdx]: https://github.com/mdx-js/mdx
[author]: https://johno.com
