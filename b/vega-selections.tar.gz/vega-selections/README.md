# vega-selections

[Vega expression language](https://vega.github.io/vega/docs/expressions/) functions for implementing Vega-Lite selections.
