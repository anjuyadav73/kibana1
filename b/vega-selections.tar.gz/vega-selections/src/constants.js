export const Intersect = 'intersect';
export const Union = 'union';
export const VlMulti = 'vlMulti';
export const VlPoint = 'vlPoint';
export const Or = 'or';
export const And = 'and';
