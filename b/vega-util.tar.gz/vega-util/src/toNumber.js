export default function(_) {
  return _ == null || _ === '' ? null : +_;
}
