export default function(message) {
  throw Error(message);
}
