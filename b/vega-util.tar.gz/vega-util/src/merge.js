export default function(compare, array0, array1, output) {
  const n0 = array0.length,
        n1 = array1.length;

  if (!n1) return array0;
  if (!n0) return array1;

  const merged = output || new array0.constructor(n0 + n1);
  let i0 = 0, i1 = 0, i = 0;

  for (; i0<n0 && i1<n1; ++i) {
    merged[i] = compare(array0[i0], array1[i1]) > 0
       ? array1[i1++]
       : array0[i0++];
  }

  for (; i0<n0; ++i0, ++i) {
    merged[i] = array0[i0];
  }

  for (; i1<n1; ++i1, ++i) {
    merged[i] = array1[i1];
  }

  return merged;
}
