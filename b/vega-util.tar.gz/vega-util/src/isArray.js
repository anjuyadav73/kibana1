export default Array.isArray;
