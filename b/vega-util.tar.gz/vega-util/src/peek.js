export default function(array) {
  return array[array.length - 1];
}
