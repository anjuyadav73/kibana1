export default function(_) {
  return Object.prototype.toString.call(_) === '[object Date]';
}
