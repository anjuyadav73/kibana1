export default function(_) {
  return _ === Object(_);
}
