export default function(_) {
  return typeof _ === 'string';
}
