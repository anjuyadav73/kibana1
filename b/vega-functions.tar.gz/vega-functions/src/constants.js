export const DataPrefix   = ':';
export const IndexPrefix  = '@';
export const ScalePrefix  = '%';
export const SignalPrefix = '$';
