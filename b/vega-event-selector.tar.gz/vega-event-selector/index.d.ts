export function parseSelector(selectorName: string, source: string): any[];
