// light library entry point.

"use strict";
module.exports = require("./src/index-light");