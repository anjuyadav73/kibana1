# @babel/plugin-proposal-nullish-coalescing-operator

> Remove nullish coalescing operator

See our website [@babel/plugin-proposal-nullish-coalescing-operator](https://babeljs.io/docs/en/babel-plugin-proposal-nullish-coalescing-operator) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-nullish-coalescing-operator
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-nullish-coalescing-operator --dev
```
