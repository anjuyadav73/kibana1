throw new Error("Use the `@babel/core` package instead of `@babel/cli`.");
