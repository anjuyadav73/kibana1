export {default as wordcloud} from './src/Wordcloud';
