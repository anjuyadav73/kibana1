# vega-wordcloud

Wordcloud layout algorithm for Vega dataflows.

This package provides the following Vega data transform:

- [**Wordcloud**](https://vega.github.io/vega/docs/transforms/wordcloud/) [&lt;&gt;](https://github.com/vega/vega/blob/master/packages/vega-wordcloud/src/Wordcloud.js "Source")
