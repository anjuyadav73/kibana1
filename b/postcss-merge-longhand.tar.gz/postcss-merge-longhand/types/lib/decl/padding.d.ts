declare const _exports: {
    explode: (rule: import("postcss").Rule) => void;
    merge: (rule: import("postcss").Rule) => void;
};
export = _exports;
