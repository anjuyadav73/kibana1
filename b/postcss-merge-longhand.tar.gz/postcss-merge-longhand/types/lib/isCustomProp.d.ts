declare const _exports: (node: import('postcss').Declaration) => boolean;
export = _exports;
