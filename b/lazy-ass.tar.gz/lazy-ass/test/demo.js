var lazyAss = require('..');
function bad(foo, bar) {
  lazyAss(false, 'this fails on purpose, foo =', foo, 'bar =', bar);
}
bad('foo', 'bar');
