declare function lazyAss(predicate: any, ...args:any[]): void;
export = lazyAss;
