## [Unreleased]

<details>
  <summary>
    Changes that have landed in master but are not yet released.
    Click to see more.
  </summary>
</details>

## 0.4.1 (January 9, 2019)

- Fixed LLtoUTMUPSObject northing values in southern hemisphere. ([@BernardIgiri](https://github.com/BernardIgiri) in [#14429](https://github.com/codice/usng.js/pull/26))
