# vega-runtime

Runtime support for Vega dataflows. Parses a runtime dataflow description produced by [vega-parser](https://github.com/vega/vega/tree/master/packages/vega-parser) to instantiate a live [vega-dataflow](https://github.com/vega/vega/tree/master/packages/vega-dataflow) instance.
