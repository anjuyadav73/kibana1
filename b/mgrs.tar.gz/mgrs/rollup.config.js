
export default {
	entry: 'mgrs.js',
  dest: 'dist/mgrs.js',
  format: 'umd',
  moduleName: 'mgrs',
  exports: 'named'
};
