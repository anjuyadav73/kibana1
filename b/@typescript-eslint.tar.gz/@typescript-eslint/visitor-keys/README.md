<h1 align="center">TypeScript-ESTree Visitor Keys</h1>

<p align="center">Visitor keys used to help traverse the TypeScript-ESTree AST</p>

<p align="center">
    <img src="https://github.com/typescript-eslint/typescript-eslint/workflows/CI/badge.svg" alt="CI" />
    <a href="https://www.npmjs.com/package/@typescript-eslint/visitor-keys"><img src="https://img.shields.io/npm/v/@typescript-eslint/visitor-keys.svg?style=flat-square" alt="NPM Version" /></a>
    <a href="https://www.npmjs.com/package/@typescript-eslint/visitor-keys"><img src="https://img.shields.io/npm/dm/@typescript-eslint/visitor-keys.svg?style=flat-square" alt="NPM Downloads" /></a>
</p>

## Contributing

[See the contributing guide here](../../CONTRIBUTING.md)
