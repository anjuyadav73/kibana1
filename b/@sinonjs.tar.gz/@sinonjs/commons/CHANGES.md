# Changes

## 1.7.2

- [`76ad9c1`](https://github.com/sinonjs/commons/commit/76ad9c16bad29f72420ed55bdf45b65d076108c8)
  Fix generators causing exceptions in function-name (Sebastian Mayr)

_Released on 2020-04-08._

## 1.7.1

- [`0486d25`](https://github.com/sinonjs/commons/commit/0486d250ecec9b5f9aa2210357767e413f4162d3)
  Upgrade eslint-config-sinon, add eslint-plugin-jsdoc (Morgan Roderick)
    >
    > This adds linting of jsdoc
    >

_Released on 2020-02-19._
