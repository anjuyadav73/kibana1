export declare function dedent(templ: TemplateStringsArray | string, ...values: unknown[]): string;
export default dedent;
