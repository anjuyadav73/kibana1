require('../').register({
  typeCheck: true,
});
