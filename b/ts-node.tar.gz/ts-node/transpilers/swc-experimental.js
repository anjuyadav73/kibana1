module.exports = require('../dist/transpilers/swc')
