# Changelog

## 0.1.0

- Initial extraction from [stylelint](https://github.com/stylelint/stylelint), API refactoring, and release.
