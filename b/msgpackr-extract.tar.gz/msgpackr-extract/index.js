module.exports = require('node-gyp-build')(__dirname)
