HTMLCanvasElement.prototype.getContext = function() {};
