# vega-schema-url-parser

Install with

```bash
npm install vega-schema-url-parser
```
