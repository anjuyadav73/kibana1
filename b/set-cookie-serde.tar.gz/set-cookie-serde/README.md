# set-cookie-serde

Serialize and deserialize `set-cookie` headers.
