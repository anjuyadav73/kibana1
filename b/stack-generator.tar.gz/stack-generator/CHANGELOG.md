## v2.0.0
* Upgrade `stackframe` dependency to 1.x. Stackframes are constructed and accessed differently. See the [stackframe CHANGELOG](https://github.com/stacktracejs/stackframe/blob/master/CHANGELOG.md#v10x) for details.

## v1.0.3
* Fix edge case when parsing arguments with Firefox

## v1.0.2
* Name functions such that they can can be filtered out by stacktrace.js

## v1.0.1
* Provide standard distribution (minified and unminified). 

## v1.0.0
* Add `getArgs()` and `setArgs(args)` methods

## v0.1.0
* Initial port from stacktrace.js

