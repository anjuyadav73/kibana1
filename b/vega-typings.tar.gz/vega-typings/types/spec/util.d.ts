export type Vector2<T> = [T, T];
export type Vector3<T> = [T, T, T];
export type Vector4<T> = [T, T, T, T];
export type Vector5<T> = [T, T, T, T, T];
export type Vector6<T> = [T, T, T, T, T, T];
export type Vector7<T> = [T, T, T, T, T, T, T];
export type Vector10<T> = [T, T, T, T, T, T, T, T, T, T];
export type Vector12<T> = [T, T, T, T, T, T, T, T, T, T, T, T];
