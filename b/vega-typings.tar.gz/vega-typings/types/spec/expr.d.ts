export type Expr = string;
export interface ExprRef {
  expr: Expr;
}
