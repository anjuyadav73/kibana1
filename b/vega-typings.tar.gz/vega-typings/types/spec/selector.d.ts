export type EventSelector = string;
