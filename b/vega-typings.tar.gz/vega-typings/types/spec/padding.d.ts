export type Padding =
  | number
  | {
      top?: number;
      bottom?: number;
      left?: number;
      right?: number;
    };
