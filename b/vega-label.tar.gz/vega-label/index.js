export { default as label } from './src/Label';
