# vega-label

Label layout algorithm for Vega dataflows.

This package provides the following Vega data transform:

- [**Label**](https://vega.github.io/vega/docs/transforms/label/) [&lt;&gt;](https://github.com/vega/vega/blob/master/packages/vega-label/src/Label.js "Source")
