import r from '@foliojs-fork/restructure';

// only used for encoding
export default new r.Array(new r.Buffer);
