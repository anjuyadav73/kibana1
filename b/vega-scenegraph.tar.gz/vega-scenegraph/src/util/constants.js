export const DegToRad = Math.PI / 180;
export const Epsilon = 1e-14;
export const HalfPi = Math.PI / 2;
export const Tau = Math.PI * 2;
export const HalfSqrt3 = Math.sqrt(3) / 2;
