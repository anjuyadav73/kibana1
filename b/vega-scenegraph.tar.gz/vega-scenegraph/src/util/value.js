export default function(value, dflt) {
  return value == null ? dflt : value;
}
