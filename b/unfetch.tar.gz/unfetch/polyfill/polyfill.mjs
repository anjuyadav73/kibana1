import unfetch from '..';
if (!self.fetch) self.fetch = unfetch;
