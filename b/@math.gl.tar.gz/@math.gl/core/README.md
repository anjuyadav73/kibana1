# @math.gl/core

[math.gl](https://math.gl/docs) is a suite of math modules for 3D applications.

This module contains classes for vectors and matrices etc.

For documentation please visit the [website](https://math.gl).
