# `@nicolo-ribaudo/chokidar-2`

A wrapper around `chokidar@2.1.8` that doesn't depend on `fsevents@1`.
