
1.0.0 - January 21, 2016
------------------------
* drop component support
* cleanup readme
* add travis ci
* update coding style

0.2.1 - October 3, 2013
-----------------------
* published to npm, thanks [@Nami-Doc](https://github.com/Nami-Doc)!

0.1.2 - October 1, 2013
-----------------------
* updated `to-space-case`

0.1.1 - September 18, 2013
--------------------------
* updated `to-space-case`

0.1.0 - September 18, 2013
--------------------------
* updated `to-space-case`

0.0.1 - September 18, 2013
--------------------------
:sparkles:
