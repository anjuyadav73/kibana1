<a name="0.2.2"></a>
## [0.2.2](https://github.com/mapbox/geojson-area/compare/v0.2.1...v0.2.2) (2016-12-19)


### Bug Fixes

* **algorithm:** Avoid accidental global i, fixes use strict ([1646944](https://github.com/mapbox/geojson-area/commit/1646944))



