[![Build Status](https://travis-ci.org/mapbox/geojson-normalize.svg)](https://travis-ci.org/mapbox/geojson-normalize)

# geojson-normalize

Normalize any GeoJSON object into a GeoJSON FeatureCollection.

## install

    npm install --save geojson-normalize

## api

    normalize(object) -> featurecollection object
