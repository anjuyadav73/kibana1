## 0.4.0

* Added shortcut initializer with `[w, s, e, n]` coords.
* Added `.intersect()` method

## 0.3.0

* Added `.center()` method

## 0.2.0

* Added `.contains()` method

## 0.1.0

* Added `.polygon()` method
