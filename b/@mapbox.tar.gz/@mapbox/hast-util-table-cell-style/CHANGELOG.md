# Changelog

## 0.1.3

- Use ES5 for browser compatibility.

## 0.1.2

- We're ok with end users on Node v4.

## 0.1.1

- Add missing unist-util-visit dependency.

## 0.1.0

- Initial release.