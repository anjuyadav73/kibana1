var b = require('beep');
console.log(b.x.y.z * 3);
console.log(b.quote.read(__dirname + '/xyz.txt'));
console.log(b.f.g.h(5));
