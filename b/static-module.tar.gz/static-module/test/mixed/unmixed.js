var b = require('beep');
console.log(b.x * 3);
console.log(b.quote(__dirname + '/xyz.txt'));
console.log(b.f(5));
