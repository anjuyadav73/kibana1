var beep = require('beep')
console.log(!beep)
