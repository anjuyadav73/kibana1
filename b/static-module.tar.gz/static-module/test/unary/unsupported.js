var beep = require('beep')
console.log(typeof beep)
