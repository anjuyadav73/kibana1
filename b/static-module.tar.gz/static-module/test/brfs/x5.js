var a = 1, b = 2, fs = require('fs'),
  c = 3, d = 4, src = fs.readFileSync(__dirname + '/x.txt', 'utf8'),
  e = 5
;
console.log(src);
