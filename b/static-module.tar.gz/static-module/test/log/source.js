console.log(require('beep')());
