var x = require('beep').f(5);
console.log(x);
