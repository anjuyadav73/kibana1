console.log(require('beep').f(5) * 2);
