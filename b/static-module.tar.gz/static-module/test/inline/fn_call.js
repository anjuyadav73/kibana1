console.log(require('beep')(5));
