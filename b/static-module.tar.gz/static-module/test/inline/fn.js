var x = require('beep')(5);
console.log(x);
