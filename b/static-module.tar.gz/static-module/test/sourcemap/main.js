var css = require('sheetify');

function doSomeStuff () {
    // doing some stuff before inlining a static module call
    return yadda(yadda)
}

css('filename.css');

exports.blah = whatever.xyz
