var f = require('fff');
var toString = Object.prototype.toString;
console.log(toString.call(f(5)));
