var b = require('beep');
console.log(b(5));
