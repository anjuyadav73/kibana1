#!/usr/bin/env node
var b = require('beep');
console.log(b.x * 3);
console.log(b.f(5));
