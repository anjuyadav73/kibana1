var fs = require('fs');
var a = fs.readFileSync(__dirname + '/robot.html', 'utf8');
var b = fs.readFileSync(__dirname + '/x.txt', 'utf8');
var c = fs.readFileSync(__dirname + '/robot.html', 'utf8');
var d = fs.readFileSync(__dirname + '/x.txt', 'utf8');
console.log(a);
console.log(b);
console.log(c);
console.log(d);
