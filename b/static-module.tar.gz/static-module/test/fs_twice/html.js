var a = require('fs').readFileSync(__dirname + '/robot.html', 'utf8');
var b = require('fs').readFileSync(__dirname + '/x.txt', 'utf8');
console.log(a);
console.log(b);
