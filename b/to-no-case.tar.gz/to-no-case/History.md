
1.0.2 - October 25, 2016
------------------------
* fix separator logic to avoid false positives

1.0.1 - March 31, 2016
----------------------
* fix broken uppercase handling

1.0.0 - January 21, 2016
------------------------
* drop component support
* cleanup readme
* add travis ci
* update coding style

0.1.3 - September 29, 2014
--------------------------
* fix non-latin characters

0.1.2 - October 24, 2013
------------------------
* fix camel/pascal case detection

0.1.1 - October 1, 2013
-----------------------
* typo :blush:

0.1.0 - September 18, 2013
--------------------------
* fix camel case bug

0.0.3 - September 18, 2013
--------------------------
* handle unknown cases

0.0.2 - September 18, 2013
--------------------------
* support acronyms at the end of a string

0.0.1 - September 18, 2013
--------------------------
:sparkles:
