module.exports = require('./syntax')
