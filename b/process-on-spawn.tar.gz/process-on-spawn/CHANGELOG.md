# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 1.0.0 (2019-12-16)


### Features

* Initial implementation ([39123b4](https://github.com/cfware/process-on-spawn/commit/39123b4ec06d8f9a22a0b19bbf955ab9e80fa376))
