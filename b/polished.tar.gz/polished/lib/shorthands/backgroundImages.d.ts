import { Styles } from '../types/style';

declare function backgroundImages(...properties: Array<string>): Styles;

export default backgroundImages;
