import { InteractionState } from '../types/interactionState';

declare function buttons(...states: Array<InteractionState>): string;

export default buttons;
