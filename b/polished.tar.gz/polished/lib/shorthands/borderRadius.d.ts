import { Styles } from '../types/style';

declare function borderRadius(side: string, radius: string | number): Styles;

export default borderRadius;
