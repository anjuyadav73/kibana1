import { Styles } from '../types/style';

declare function borderStyle(...values: Array<null | void | string>): Styles;

export default borderStyle;
