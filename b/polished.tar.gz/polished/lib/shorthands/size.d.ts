import { Styles } from '../types/style';

declare function size(height: string | number, width?: string | number): Styles;

export default size;
