import { Styles } from '../types/style';

declare function backgrounds(...properties: Array<string>): Styles;

export default backgrounds;
