import { Styles } from '../types/style';

declare function transitions(
  ...properties: Array<string | Array<string>>
): Styles;

export default transitions;
