import { Styles } from '../types/style';

declare function borderColor(...values: Array<null | void | string>): Styles;

export default borderColor;
