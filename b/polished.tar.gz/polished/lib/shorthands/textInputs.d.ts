import { InteractionState } from '../types/interactionState';

declare function textInputs(...states: Array<InteractionState>): string;

export default textInputs;
