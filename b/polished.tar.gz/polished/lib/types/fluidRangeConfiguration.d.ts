declare interface FluidRangeConfiguration {
  prop: string;
  fromSize: string | number;
  toSize: string | number;
}

export { FluidRangeConfiguration };
