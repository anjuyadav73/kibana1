type InteractionState = void | null | 'active' | 'focus' | 'hover';

export { InteractionState };
