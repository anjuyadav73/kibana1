declare interface Styles {
  [ruleOrSelector: string]: string | number | Styles;
}

export { Styles };
