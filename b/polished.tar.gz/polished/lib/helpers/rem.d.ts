declare const rem: (value: string | number, base?: string | number) => string;

export default rem;
