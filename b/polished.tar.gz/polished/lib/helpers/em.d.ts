declare const em: (value: string | number, base?: string | number) => string;

export default em;
