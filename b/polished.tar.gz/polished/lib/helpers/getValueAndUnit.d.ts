declare function getValueAndUnit(value: string | number): any;

export default getValueAndUnit;
