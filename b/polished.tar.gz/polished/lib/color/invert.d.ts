declare function invert(color: string): string;

export default invert;
