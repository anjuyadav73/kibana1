declare function complement(color: string): string;

export default complement;
