declare function curriedSetHueWith1(color: string): string;
declare function curriedSetHue(hue: number | string): typeof curriedSetHueWith1;
declare function curriedSetHue(hue: number | string, color: string): string;

export default curriedSetHue;
