declare function getContrast(color1: string, color2: string): number;

export default getContrast;
