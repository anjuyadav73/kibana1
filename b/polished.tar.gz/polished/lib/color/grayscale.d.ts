declare function grayscale(color: string): string;

export default grayscale;
