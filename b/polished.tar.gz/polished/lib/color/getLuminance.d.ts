declare function getLuminance(color: string): number;

export default getLuminance;
