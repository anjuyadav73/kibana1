declare function toColorString(color: Object): string;

export default toColorString;
