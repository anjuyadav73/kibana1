declare function readableColor(
  color: string,
  returnIfLightColor?: string,
  returnIfDarkColor?: string,
  strict?: boolean,
): string;

export default readableColor;
