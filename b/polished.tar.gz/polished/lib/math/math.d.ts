declare function math(formula: string, additionalSymbols?: Object): string;

export default math;
