import { Styles } from '../types/style';

declare function wordWrap(wrap?: string): Styles;

export default wordWrap;
