import { TimingFunction } from '../types/timingFunction';

declare function timingFunctions(timingFunction: TimingFunction): string;

export default timingFunctions;
