import { Styles } from '../types/style';

declare function hideVisually(): Styles;

export default hideVisually;
