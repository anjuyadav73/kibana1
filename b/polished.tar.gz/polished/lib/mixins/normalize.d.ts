import { Styles } from '../types/style';

declare function normalize(): Array<Styles>;

export default normalize;
