declare function between(
  fromSize: string | number,
  toSize: string | number,
  minScreen?: string,
  maxScreen?: string,
): string;

export default between;
