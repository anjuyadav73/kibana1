import { Styles } from '../types/style';

declare function cover(offset?: number | string): Styles;

export default cover;
