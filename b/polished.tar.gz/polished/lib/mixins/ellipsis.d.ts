import { Styles } from '../types/style';

declare function ellipsis(width?: string | number): Styles;

export default ellipsis;
