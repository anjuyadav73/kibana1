import { Styles } from '../types/style';

declare function clearFix(parent?: string): Styles;

export default clearFix;
