import { Styles } from '../types/style';

declare function hideText(): Styles;

export default hideText;
