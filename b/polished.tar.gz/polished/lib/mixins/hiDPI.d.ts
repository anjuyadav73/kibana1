declare function hiDPI(ratio?: number): string;

export default hiDPI;
