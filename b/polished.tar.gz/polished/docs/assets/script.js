Object.assign(window, polished)
console.log('> console.log(polished)')
console.log(polished)
