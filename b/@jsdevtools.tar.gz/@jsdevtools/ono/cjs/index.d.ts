import { ono } from "./singleton";
export { Ono } from "./constructor";
export * from "./types";
export { ono };
export default ono;
