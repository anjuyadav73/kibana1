export { default } from './forEachRight.js'
