'use strict';

require('/Users/jordan_harband/Dropbox/git/promise.prototype.finally.git/shim')();
