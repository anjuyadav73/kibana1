'use strict';

require('es6-shim');

require('./');

require('./shimmed');
