# use-composed-ref

React hook which creates a ref function from given refs. Useful when using forwardRef.
