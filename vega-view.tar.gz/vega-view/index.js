export {default as View} from './src/View';
