export * from "./lib/SVGPathData";
export as namespace svgpathdata;
