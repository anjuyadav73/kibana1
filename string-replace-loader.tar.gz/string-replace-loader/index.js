const processChuck = require('./lib/processChunk')

module.exports = processChuck
