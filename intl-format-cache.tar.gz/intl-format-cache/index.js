'use strict';

exports = module.exports = require('./lib/memoizer')['default'];
exports['default'] = exports;
