export function toUpper(str){
  return str.toUpperCase()
}
