export function toLower(str){
  return str.toLowerCase()
}
