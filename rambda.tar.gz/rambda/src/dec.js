export const dec = x => x - 1
