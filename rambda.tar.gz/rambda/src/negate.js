export function negate(x){
  return -x
}
