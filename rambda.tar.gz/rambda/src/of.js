export function of(value){
  return [ value ]
}
