export function not(input){
  return !input
}
