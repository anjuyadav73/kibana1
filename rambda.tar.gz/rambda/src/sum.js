export function sum(list){
  return list.reduce((prev, current) => prev + current, 0)
}
