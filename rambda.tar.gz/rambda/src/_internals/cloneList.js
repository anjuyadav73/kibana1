export const cloneList = list => Array.prototype.slice.call(list)
