export const _isArray = Array.isArray
