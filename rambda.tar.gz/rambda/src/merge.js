export {mergeRight as merge} from './mergeRight.js'
