export function identity(x){
  return x
}
