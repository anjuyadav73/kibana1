export function toPairs(obj){
  return Object.entries(obj)
}
