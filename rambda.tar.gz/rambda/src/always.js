export function always(x){
  return _ => x
}
