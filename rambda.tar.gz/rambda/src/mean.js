import { sum } from './sum.js'

export function mean(list){
  return sum(list) / list.length
}
