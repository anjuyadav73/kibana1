export const Feature = 'Feature';
export const FeatureCollection = 'FeatureCollection';
export const MultiPoint = 'MultiPoint';
