## [1.0.1](https://github.com/streamich/set-harmonic-interval/compare/v1.0.0...v1.0.1) (2019-10-23)


### Bug Fixes

* husky hooks now should be defined in separate package.json field; ([6a444f7](https://github.com/streamich/set-harmonic-interval/commit/6a444f7))
* prettier expects doubleqotes on file template ([d449a86](https://github.com/streamich/set-harmonic-interval/commit/d449a86))

# 1.0.0 (2019-08-25)


### Features

* 🎸 implement setHarmonicInterval and clearHarmonicInterval ([2cb24b4](https://github.com/streamich/set-harmonic-interval/commit/2cb24b4))
