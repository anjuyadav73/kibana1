declare function _exports(value: string): string;
export = _exports;
