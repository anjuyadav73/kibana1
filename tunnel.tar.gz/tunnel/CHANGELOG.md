# Changelog

 - 0.0.6 (2018/09/11)
   - Fix `localAddress` not working (#25)
   - Fix `Host:` header for CONNECT method by @tmurakam (#29, #30)
   - Fix default port for https (#32)
   - Fix error handling when the proxy send illegal response body (#33)

 - 0.0.5 (2017/06/12)
   - Fix socket leak.
 
 - 0.0.4 (2016/01/23)
   - supported Node v0.12 or later.

 - 0.0.3 (2014/01/20)
   - fixed package.json

 - 0.0.1 (2012/02/18)
   - supported Node v0.6.x (0.6.11 or later).

 - 0.0.0 (2012/02/11)
   - first release.
