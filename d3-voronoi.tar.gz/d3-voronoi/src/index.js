export {default as voronoi} from "./voronoi";
