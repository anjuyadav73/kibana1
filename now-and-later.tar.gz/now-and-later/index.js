'use strict';

module.exports = {
  map: require('./lib/map'),
  mapSeries: require('./lib/mapSeries'),
};
