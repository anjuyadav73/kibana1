"use strict";
require("./warnAboutDeprecatedCJSRequire.js")("renderRoutes");
module.exports = require("./index.js").renderRoutes;
