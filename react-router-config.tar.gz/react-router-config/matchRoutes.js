"use strict";
require("./warnAboutDeprecatedCJSRequire.js")("matchRoutes");
module.exports = require("./index.js").matchRoutes;
