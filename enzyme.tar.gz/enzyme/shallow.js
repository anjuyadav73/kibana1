module.exports = require('./build/shallow').default;
