module.exports = require('./build/ReactWrapper').default;
