module.exports = require('./build/render').default;
