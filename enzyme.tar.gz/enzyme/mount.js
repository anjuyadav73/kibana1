module.exports = require('./build/mount').default;
