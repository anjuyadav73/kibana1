import Span from './span';
import SpanContext from './span_context';
import Tracer from './tracer';
export declare let tracer: Tracer | null;
export declare let spanContext: SpanContext | null;
export declare let span: Span | null;
export declare function initialize(): void;
//# sourceMappingURL=noop.d.ts.map