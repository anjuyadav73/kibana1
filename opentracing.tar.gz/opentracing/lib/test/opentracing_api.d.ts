export declare function opentracingAPITests(): void;
export default opentracingAPITests;
//# sourceMappingURL=opentracing_api.d.ts.map