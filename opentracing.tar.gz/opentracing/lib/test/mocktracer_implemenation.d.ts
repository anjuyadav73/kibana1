declare function mockTracerimplementationTests(): void;
export default mockTracerimplementationTests;
//# sourceMappingURL=mocktracer_implemenation.d.ts.map