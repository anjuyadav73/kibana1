import { Tracer } from '../index';
export declare function noopImplementationTests(createTracer?: () => Tracer): void;
export default noopImplementationTests;
//# sourceMappingURL=noop_implementation.d.ts.map