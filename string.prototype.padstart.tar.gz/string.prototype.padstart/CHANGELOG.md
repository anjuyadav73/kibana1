3.0.0 / 2015-11-17
=================
  * Renamed to `padStart`/`padEnd` per November 2015 TC39 meeting.

2.0.0 / 2015-09-25
=================
  * [Breaking] Take the *first* part of the `fillStr` when truncating (#1)
  * Implement the [es-shim API](es-shims/api)
  * [Tests] up to `io.js` `v3.3`, `node` `v4.1`
  * [Deps] update `es-abstract`
  * [Dev Deps] Update `tape`, `jscs`, `eslint`, `@ljharb/eslint-config`, `nsp`
  * [Refactor] Remove redundant `max` operation, per https://github.com/ljharb/proposal-string-pad-left-right/pull/2

1.0.0 / 2015-07-30
=================
  * v1.0.0
