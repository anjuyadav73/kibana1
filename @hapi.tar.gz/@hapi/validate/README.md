<a href="https://hapi.dev"><img src="https://raw.githubusercontent.com/hapijs/assets/master/images/family.png" width="180px" align="right" /></a>

# @hapi/validate

A fork of the [**joi**](https://github.com/sideway/joi) validation library for internal hapi core needs only. This fork is maintained to keep the hapi framework 100% free of external dependencies. It is not meant to be used outside of hapi core modules. Please use the official [**joi**](https://github.com/sideway/joi) library.
