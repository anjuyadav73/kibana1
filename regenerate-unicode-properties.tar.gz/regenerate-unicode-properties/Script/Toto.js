const set = require('regenerate')();
set.addRange(0x1E290, 0x1E2AE);
exports.characters = set;
