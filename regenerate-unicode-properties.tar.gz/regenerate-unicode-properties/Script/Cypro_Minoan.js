const set = require('regenerate')();
set.addRange(0x12F90, 0x12FF2);
exports.characters = set;
