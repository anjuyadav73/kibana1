const set = require('regenerate')(0x171F);
set.addRange(0x1700, 0x1715).addRange(0x1735, 0x1736);
exports.characters = set;
