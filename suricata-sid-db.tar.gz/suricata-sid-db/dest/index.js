"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var db = require("./suricata-rules-ref.json");
exports.db = db;
