import db from './suricata-rules-ref.json';
export { db };
