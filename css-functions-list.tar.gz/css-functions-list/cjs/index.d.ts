export default location;
/**
 * Path to CSS functions list JSON file.
 */
declare const location: string;
//# sourceMappingURL=index.d.ts.map