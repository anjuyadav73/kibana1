const toHaveStyleRule = require('../src/native/toHaveStyleRule')

expect.extend({ toHaveStyleRule })
