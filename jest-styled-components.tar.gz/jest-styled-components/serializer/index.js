const styleSheetSerializer = require('../src/styleSheetSerializer')

module.exports.styleSheetSerializer = styleSheetSerializer
