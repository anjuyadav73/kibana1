# Security Policy

## Reporting a Vulnerability

To report a vulnerability please send an email with the details to info@apidocjs.com but ONLY in case it is a real problem. apiDoc generates static files, which should be used and hosted on a separate webspace, so it could not harm anything else.

For normal issues or problems with dependent libraries use the [Issue tracker](https://github.com/apidoc/apidoc/issues).
