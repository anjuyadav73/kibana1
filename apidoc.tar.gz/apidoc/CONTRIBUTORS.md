# apiDoc Contributors

Thanks to all people that helped to make apiDoc better!

You can find a list of contributors to the code here:
https://github.com/apidoc/apidoc/graphs/contributors

Note that opening issues and discussing about features is also a meaningful contribution!
