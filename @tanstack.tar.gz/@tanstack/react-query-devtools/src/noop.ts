export function ReactQueryDevtools() {
  return null
}

export function ReactQueryDevtoolsPanel() {
  return null
}
