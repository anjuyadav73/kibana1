// @ts-ignore
// eslint-disable-next-line import/no-unresolved
import { unstable_batchedUpdates } from 'react-native'
export { unstable_batchedUpdates }
