export class Deprecation extends Error {
  name: "Deprecation";
}
