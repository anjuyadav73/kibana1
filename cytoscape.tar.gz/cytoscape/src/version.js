export default process.env.VERSION;
