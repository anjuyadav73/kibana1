export default ( typeof window === 'undefined' ? null : window ); // eslint-disable-line no-undef
