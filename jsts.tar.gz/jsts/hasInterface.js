export default function (o, i) {
  return o.interfaces_ && o.interfaces_().indexOf(i) > -1
}
