export default function DecimalFormat () {}
