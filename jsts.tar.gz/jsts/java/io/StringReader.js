export default function StringReader () {}
