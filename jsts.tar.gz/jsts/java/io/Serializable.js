export default function Serializable () {}
