export default function Writer () {}
