export default function Comparable () {}
