export default function Clonable () {}
