import extend from '../../../../extend';
export default function SegmentSetMutualIntersector() {}
extend(SegmentSetMutualIntersector.prototype, {
	process: function (segStrings, segInt) {},
	interfaces_: function () {
		return [];
	},
	getClass: function () {
		return SegmentSetMutualIntersector;
	}
});
