import LineDissolver from './dissolve/LineDissolver'

export {
  LineDissolver
}
