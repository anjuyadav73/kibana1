import STRtree from './strtree/STRtree'

export {
  STRtree
}
