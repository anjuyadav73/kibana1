import extend from '../../../../../extend';
export default function SweepLineOverlapAction() {}
extend(SweepLineOverlapAction.prototype, {
	overlap: function (s0, s1) {},
	interfaces_: function () {
		return [];
	},
	getClass: function () {
		return SweepLineOverlapAction;
	}
});
