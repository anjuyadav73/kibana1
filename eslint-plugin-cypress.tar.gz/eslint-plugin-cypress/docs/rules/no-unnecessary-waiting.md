## No Assigning Return Values

See [the Cypress Best Practices guide](https://on.cypress.io/best-practices#Unnecessary-Waiting).
