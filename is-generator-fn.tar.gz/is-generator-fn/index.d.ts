/**
 * Check if something is a generator function.
 */
export default function isGeneratorFn(value: unknown): value is GeneratorFunction;
