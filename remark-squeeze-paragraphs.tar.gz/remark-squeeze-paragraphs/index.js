'use strict'

var squeezeParagraphs = require('mdast-squeeze-paragraphs')

module.exports = function () {
  return squeezeParagraphs
}
