module.exports = function(file, prev, done) {
  done({
    contents: 'div {color: yellow;}'
  });
};
