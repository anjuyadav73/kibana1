'use strict';

module.exports = require('./cjs/react-shallow-renderer.js');
