export { EmotionJSX as JSX } from './jsx-namespace'
