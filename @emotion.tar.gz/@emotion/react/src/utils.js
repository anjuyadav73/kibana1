// @flow
export let isBrowser = typeof document !== 'undefined'

export const hasOwnProperty = {}.hasOwnProperty
