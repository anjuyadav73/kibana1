export default function prettify(styles: string, indentation?: string): string
