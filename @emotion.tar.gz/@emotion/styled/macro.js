module.exports = require('babel-plugin-emotion').macros.createStyledMacro({
  importPath: '@emotion/styled-base',
  originalImportPath: '@emotion/styled',
  isWeb: true
})
