// @flow
import { createSerializer } from './create-serializer'
export const { test, serialize } = createSerializer()
