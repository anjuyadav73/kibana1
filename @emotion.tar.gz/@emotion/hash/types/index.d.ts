export default function murmurhash2_32_gc(str: string): string
