# @emotion/hash

## 0.8.0

### Minor Changes

- [`446e756`](https://github.com/emotion-js/emotion/commit/446e75661c4aa01e51d1466472a212940c19cd82) [#1775](https://github.com/emotion-js/emotion/pull/1775) Thanks [@kripod](https://github.com/kripod)! - Optimized hashing for performance while also reducing the size of the function.

## 0.7.4

### Patch Changes

- [`4c62ae9`](https://github.com/emotion-js/emotion/commit/4c62ae9447959d438928e1a26f76f1487983c968) [#1698](https://github.com/emotion-js/emotion/pull/1698) Thanks [@Andarist](https://github.com/Andarist)! - Add LICENSE file

## 0.7.3

### Patch Changes

- [c81c0033](https://github.com/emotion-js/emotion/commit/c81c0033c490210077da0e9c3f9fa1a22fcd9c96) [#1503](https://github.com/emotion-js/emotion/pull/1503) Thanks [@Andarist](https://github.com/Andarist)! - Add TS types to util packages - hash, memoize & weak-memoize

## 0.7.2

### Patch Changes

- [c0eb604d](https://github.com/emotion-js/emotion/commit/c0eb604d) [#1419](https://github.com/emotion-js/emotion/pull/1419) Thanks [@mitchellhamilton](https://github.com/mitchellhamilton)! - Update build tool
