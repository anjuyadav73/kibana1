module.exports = require('./lib/puid');
