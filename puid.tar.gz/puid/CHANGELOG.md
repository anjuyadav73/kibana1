Changelog
=========

-	v1.0.7 v1.0.6 npm release failed, yeahhh :-(
-	v1.0.6 update dev dependencies
-	v1.0.5 update dev dependencies
-	v1.0.4 add unnecessary files/dirs to .npmignore
-	v1.0.x update dev dependencies
-	v1.0.0 Release Version 1.0 with stable API
-	v0.5.6 update dev dependencies
-	v0.5.5 update dev dependencies
-	v0.5.4 update dev dependencies
-	v0.5.2 last version compatible with node v0.8.x
-	v0.5.0 changed datetime for default epoch value from "1999-07-02 03:00:00 pm" to "1999-06-07 03:00:00 pm GMT"; further infos see #7 (https://github.com/pid/puid/issues/7\)
-	v0.4.0 added short-puid, long-puid behavior is unchanged
