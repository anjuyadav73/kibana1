import wrcModule from './index.js'
export const WeakLRUCache = wrcModule.WeakLRUCache
export const LRFUExpirer = wrcModule.LRFUExpirer