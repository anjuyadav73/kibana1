export const GroupMark = 'group';
export const RectMark = 'rect';
export const RuleMark = 'rule';
export const SymbolMark = 'symbol';
export const TextMark = 'text';
