
export default {
  entry: 'index.js',
  dest: 'wkt.build.js',
  format: 'cjs'
};
