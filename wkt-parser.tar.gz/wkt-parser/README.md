wkt-parser
===

The wkt parser pulled out of proj4 so it can be hacked on.
