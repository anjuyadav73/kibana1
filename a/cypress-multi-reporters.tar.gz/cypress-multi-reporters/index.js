'use strict';

const MultiReporters = require('./lib/MultiReporters');

module.exports = MultiReporters;
