module.exports = function () {
  var element = document.createElement('div')
  document.body.appendChild(element)
  return element
}
