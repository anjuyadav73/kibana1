var hat = require('hat');
var rack = hat.rack();

console.log(rack());
console.log(rack());
