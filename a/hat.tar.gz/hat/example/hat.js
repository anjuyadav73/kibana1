var hat = require('hat');

var id = hat();
console.log(id);
