
// Exported default stateless component used in variable declaration
export default function _uid({ value }) {
  return React.createElement(
    "div",
    null,
    value
  );
}
_uid.displayName = "input";
