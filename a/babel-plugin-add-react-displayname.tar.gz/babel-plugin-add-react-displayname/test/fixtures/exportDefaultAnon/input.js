// Exported default stateless component used in variable declaration
export default function ({value}) {
  return <div>{value}</div>
}
