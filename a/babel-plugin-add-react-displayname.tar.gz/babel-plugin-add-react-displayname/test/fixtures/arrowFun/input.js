// Stateless component with an arrow function
var Component2 = ({value}) => {
  return (
    <div>{value}</div>
  )
}