import React from 'react';
import { Component } from 'react';

// Babel already sets displayName for this one
export var Component0 = React.createClass({
  displayName: 'Component0',

  render: function () {
    React.createElement('div', null);
  }
});