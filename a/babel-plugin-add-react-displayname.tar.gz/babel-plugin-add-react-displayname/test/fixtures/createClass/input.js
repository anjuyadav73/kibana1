import React from 'react';
import { Component } from 'react';

// Babel already sets displayName for this one
export var Component0 = React.createClass({
  render: function() {
    <div></div>
  }
})
