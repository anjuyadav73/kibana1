// Arrow function with empty return
var emptyReturnFunction = () => {
  return
}