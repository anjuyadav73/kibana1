export default function hyphenate(string: string): string;
