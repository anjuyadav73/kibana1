export default function toggleClass(element: Element | SVGElement, className: string): void;
