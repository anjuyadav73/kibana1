export default function scrollTo(selected: HTMLElement, scrollParent?: HTMLElement): (() => void) | undefined;
