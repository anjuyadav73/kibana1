export default function getWidth(node: HTMLElement, client?: boolean): number;
