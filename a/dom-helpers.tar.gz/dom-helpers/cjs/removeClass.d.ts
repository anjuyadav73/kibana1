export default function removeClass(element: Element | SVGElement, className: string): void;
