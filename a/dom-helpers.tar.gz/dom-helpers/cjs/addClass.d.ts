export default function addClass(element: Element | SVGElement, className: string): void;
