/**
 * Return the actively focused element safely.
 *
 * @param doc the document to checl
 */
export default function activeElement(doc?: Document): Element | null;
