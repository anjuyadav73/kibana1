export default function hasClass(element: Element | SVGElement, className: string): boolean;
