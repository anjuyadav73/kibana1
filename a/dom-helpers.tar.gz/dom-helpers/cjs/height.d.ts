export default function height(node: HTMLElement, client?: boolean): number;
