export function linear(t) {
  return +t;
}
