import { keyBy } from "../fp";
export = keyBy;
