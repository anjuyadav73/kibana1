import { dissocPath } from "../fp";
export = dissocPath;
