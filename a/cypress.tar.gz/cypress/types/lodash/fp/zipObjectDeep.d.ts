import { zipObjectDeep } from "../fp";
export = zipObjectDeep;
