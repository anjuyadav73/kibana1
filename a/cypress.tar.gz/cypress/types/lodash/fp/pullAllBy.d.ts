import { pullAllBy } from "../fp";
export = pullAllBy;
