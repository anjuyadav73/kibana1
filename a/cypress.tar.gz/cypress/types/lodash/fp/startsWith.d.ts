import { startsWith } from "../fp";
export = startsWith;
