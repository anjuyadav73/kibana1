import { unary } from "../fp";
export = unary;
