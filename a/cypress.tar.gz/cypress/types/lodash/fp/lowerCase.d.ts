import { lowerCase } from "../fp";
export = lowerCase;
