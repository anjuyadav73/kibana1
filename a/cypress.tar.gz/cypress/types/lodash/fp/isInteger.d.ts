import { isInteger } from "../fp";
export = isInteger;
