import { reduceRight } from "../fp";
export = reduceRight;
