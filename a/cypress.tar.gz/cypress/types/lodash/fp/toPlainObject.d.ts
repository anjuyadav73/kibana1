import { toPlainObject } from "../fp";
export = toPlainObject;
