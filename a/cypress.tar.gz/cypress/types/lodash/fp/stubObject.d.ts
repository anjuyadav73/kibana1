import { stubObject } from "../fp";
export = stubObject;
