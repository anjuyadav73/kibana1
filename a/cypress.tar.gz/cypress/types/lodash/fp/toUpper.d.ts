import { toUpper } from "../fp";
export = toUpper;
