import { gte } from "../fp";
export = gte;
