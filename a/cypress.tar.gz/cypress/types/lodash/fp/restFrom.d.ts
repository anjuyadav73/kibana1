import { restFrom } from "../fp";
export = restFrom;
