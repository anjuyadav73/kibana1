import { toString } from "../fp";
export = toString;
