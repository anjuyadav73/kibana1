import { isMatchWith } from "../fp";
export = isMatchWith;
