import { propEq } from "../fp";
export = propEq;
