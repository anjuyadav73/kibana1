import { includesFrom } from "../fp";
export = includesFrom;
