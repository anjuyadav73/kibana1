import { mapKeys } from "../fp";
export = mapKeys;
