import { defaultTo } from "../fp";
export = defaultTo;
