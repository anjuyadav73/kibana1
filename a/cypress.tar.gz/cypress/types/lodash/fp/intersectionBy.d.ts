import { intersectionBy } from "../fp";
export = intersectionBy;
