import { invertBy } from "../fp";
export = invertBy;
