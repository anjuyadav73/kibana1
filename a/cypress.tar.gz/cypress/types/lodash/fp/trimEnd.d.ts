import { trimEnd } from "../fp";
export = trimEnd;
