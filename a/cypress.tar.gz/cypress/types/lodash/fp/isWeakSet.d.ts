import { isWeakSet } from "../fp";
export = isWeakSet;
