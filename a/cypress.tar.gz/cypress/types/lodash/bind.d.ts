import { bind } from "./index";
export = bind;
