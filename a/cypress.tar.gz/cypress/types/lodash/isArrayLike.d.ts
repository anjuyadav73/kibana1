import { isArrayLike } from "./index";
export = isArrayLike;
