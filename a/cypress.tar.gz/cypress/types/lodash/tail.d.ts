import { tail } from "./index";
export = tail;
