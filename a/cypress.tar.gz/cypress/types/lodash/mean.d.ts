import { mean } from "./index";
export = mean;
