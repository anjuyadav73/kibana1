import { lt } from "./index";
export = lt;
