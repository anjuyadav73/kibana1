import { conformsTo } from "./index";
export = conformsTo;
