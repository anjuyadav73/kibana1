import { spread } from "./index";
export = spread;
