import { kebabCase } from "./index";
export = kebabCase;
