# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.9.x   | :white_check_mark: |

## Reporting a Vulnerability

Please report security vulnerabilities to kriszyp@gmail.com.
