/** DON'T EDIT THIS FILE WHICH WAS CREATED BY 'scripts/generate-index.js'. */
"use strict"

module.exports = {
    configs: require("./lib/configs"),
    rules: require("./lib/rules"),
    utils: require("./lib/utils"),
}
