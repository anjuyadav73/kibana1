export declare function invariant(
  condition: unknown,
  message?: string,
): asserts condition;
