/**
 * Build a string describing the path.
 */
export declare function printPathArray(
  path: ReadonlyArray<string | number>,
): string;
