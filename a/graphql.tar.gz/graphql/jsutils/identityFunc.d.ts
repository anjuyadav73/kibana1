/**
 * Returns the first argument it receives.
 */
export declare function identityFunc<T>(x: T): T;
