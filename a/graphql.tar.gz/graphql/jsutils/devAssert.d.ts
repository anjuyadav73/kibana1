export declare function devAssert(condition: unknown, message: string): void;
