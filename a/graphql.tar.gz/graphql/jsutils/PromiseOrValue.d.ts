export declare type PromiseOrValue<T> = Promise<T> | T;
