/**
 * Returns the first argument it receives.
 */
export function identityFunc(x) {
  return x;
}
