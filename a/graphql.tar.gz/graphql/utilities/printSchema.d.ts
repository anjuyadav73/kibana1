import type { GraphQLNamedType } from '../type/definition';
import type { GraphQLSchema } from '../type/schema';
export declare function printSchema(schema: GraphQLSchema): string;
export declare function printIntrospectionSchema(schema: GraphQLSchema): string;
export declare function printType(type: GraphQLNamedType): string;
