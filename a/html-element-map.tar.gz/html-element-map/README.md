# html-element-map
Look up HTML tag names via HTML Element constructors, and vice versa.
