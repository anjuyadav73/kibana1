import mod from './index.js'

export default mod
export const HttpProxyAgent = mod.HttpProxyAgent
export const HttpsProxyAgent = mod.HttpsProxyAgent
