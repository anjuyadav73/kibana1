
1.0.0 / 2014-10-10
==================

 * fix travis test fail on 0.8.x
 * Moved to readable-stream. Adds support for node@0.8 (@twolfson)

0.0.1 / 2014-04-14
==================

 * first version
 * first commit
