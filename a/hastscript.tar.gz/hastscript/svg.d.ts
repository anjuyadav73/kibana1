// TypeScript Version: 3.5

import hastscript = require('hastscript')

export = hastscript
