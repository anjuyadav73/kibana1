## globjoin changelog

### 2016/02/16 - 0.1.4

* NPM: Remove accidental dependency.

### 2016/02/15 - 0.1.3

* Bug Fix: Should use Array.prototype.slice().
* Misc: Remove unused test fixtures.

### 2015/12/24 - 0.1.2

First Release