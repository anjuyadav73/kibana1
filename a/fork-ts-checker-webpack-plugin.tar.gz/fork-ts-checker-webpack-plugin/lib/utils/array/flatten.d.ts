declare function flatten<T>(matrix: T[][]): T[];
export default flatten;
