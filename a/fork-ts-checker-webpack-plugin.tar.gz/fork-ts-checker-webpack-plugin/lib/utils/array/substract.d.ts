declare function subtract<T>(arrayA?: T[], arrayB?: T[]): T[];
export default subtract;
