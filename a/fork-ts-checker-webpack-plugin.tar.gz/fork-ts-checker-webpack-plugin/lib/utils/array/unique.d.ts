declare function unique<T>(array: T[]): T[];
export default unique;
