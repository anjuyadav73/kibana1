declare function isPending(promise: Promise<unknown>, timeout?: number): Promise<unknown>;
export default isPending;
