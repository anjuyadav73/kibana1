declare class RpcMessagePortClosedError extends Error {
}
export { RpcMessagePortClosedError };
