import { RpcMessageChannel } from '../index';
declare function createRpcIpcMessageChannel(servicePath: string, memoryLimit?: number): RpcMessageChannel;
export { createRpcIpcMessageChannel };
