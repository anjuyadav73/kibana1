import webpack from 'webpack';
import { ForkTsCheckerWebpackPluginConfiguration } from '../ForkTsCheckerWebpackPluginConfiguration';
declare function tapErrorToLogMessage(compiler: webpack.Compiler, configuration: ForkTsCheckerWebpackPluginConfiguration): void;
export { tapErrorToLogMessage };
