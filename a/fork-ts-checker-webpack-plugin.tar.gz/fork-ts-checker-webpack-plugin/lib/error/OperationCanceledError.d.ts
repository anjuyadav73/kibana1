declare class OperationCanceledError extends Error {
    readonly canceled = true;
}
export { OperationCanceledError };
