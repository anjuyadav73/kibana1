import { Issue } from '../../issue';
import { LintResult } from '../types/eslint';
declare function createIssuesFromEsLintResults(results: LintResult[]): Issue[];
export { createIssuesFromEsLintResults };
