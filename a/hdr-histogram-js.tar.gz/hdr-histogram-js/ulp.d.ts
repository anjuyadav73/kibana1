declare const ulp: (x: number) => number;
export default ulp;
