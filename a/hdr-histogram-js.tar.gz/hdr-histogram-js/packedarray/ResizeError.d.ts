export declare class ResizeError {
    newSize: number;
    constructor(newSize: number);
}
