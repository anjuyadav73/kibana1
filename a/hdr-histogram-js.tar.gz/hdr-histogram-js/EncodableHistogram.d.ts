export declare abstract class EncodableHistogram {
}
