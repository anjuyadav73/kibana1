# Changes to Array Flat Polyfill

### 1.0.1 (April 12, 2019)

- Fixed an issue with the depth parameter
- Performance is improved by ~200%

### 1.0.0 (November 28, 2018)

- Initial version
