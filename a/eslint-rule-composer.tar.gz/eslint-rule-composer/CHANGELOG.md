# Changelog

## v0.3.0 (2018-04-16)

* Update: Add filename property to metadata ([#3](https://github.com/not-an-aardvark/eslint-rule-composer/issues/3)) ([c6982df](https://github.com/not-an-aardvark/eslint-rule-composer/commit/c6982df862ffd9f2f7595d05d407eb7b5f9e83f9))

## v0.2.0 (2018-04-14)

* Update: Add a reference to context settings and options ([#1](https://github.com/not-an-aardvark/eslint-rule-composer/issues/1)) ([e7312ba](https://github.com/not-an-aardvark/eslint-rule-composer/commit/e7312bae50399f7576220649a52b8bbb4d4083c2))
* Build: set up Travis CI ([7e43e8c](https://github.com/not-an-aardvark/eslint-rule-composer/commit/7e43e8c05f667b0335f8ca7505acf831e1616070))

## v0.1.1 (2018-03-14)

* Chore: set up release script ([2ce3403](https://github.com/not-an-aardvark/eslint-rule-composer/commit/2ce3403d9cade255f904a3f8b9135076fa0937f1))
* Update: support rules that use messageIds ([861137c](https://github.com/not-an-aardvark/eslint-rule-composer/commit/861137cd9080c6a9f9e1dfe5a5e0fa03f81bf5ec))
* Docs: fix formatting in readme ([bad652b](https://github.com/not-an-aardvark/eslint-rule-composer/commit/bad652b05f6470e2155df02746acfa85a45fb4ab))

