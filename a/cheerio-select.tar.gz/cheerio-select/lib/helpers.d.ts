import type { Node } from "domhandler";
import type { Selector } from "css-what";
export declare function getDocumentRoot(node: Node): Node;
export declare function groupSelectors(selectors: Selector[][]): [plain: Selector[][], filtered: Selector[][]];
//# sourceMappingURL=helpers.d.ts.map