var array = Array.prototype;

export var slice = array.slice;
