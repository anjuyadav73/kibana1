// This file allows dist/cronstrue-i18n.js to be required from Node as:
// var cronstrue = require('cronstrue/i18n');

var cronstrueWithLocales = require("./dist/cronstrue-i18n.js");
module.exports = cronstrueWithLocales;
