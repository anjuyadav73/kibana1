/*!
 * Copyright 2019 acrazing <joking.young@gmail.com>. All rights reserved.
 * @since 2019-07-17 18:45:32
 */
import G from 'glob';
import { DependencyTree, ParseOptions } from './types';
export declare const glob: typeof G.__promisify__;
export declare const defaultOptions: ParseOptions;
export declare function normalizeOptions(options: Partial<ParseOptions>): ParseOptions;
export declare function appendSuffix(request: string, extensions: string[]): Promise<string | null>;
export declare type Resolver = (context: string, request: string, extensions: string[]) => Promise<string | null>;
export declare const simpleResolver: Resolver;
export declare function shortenTree(context: string, tree: DependencyTree): DependencyTree;
export declare function parseCircular(tree: DependencyTree): string[][];
export declare function parseDependents(tree: DependencyTree): Record<string, string[]>;
export declare function parseWarnings(tree: DependencyTree, dependents?: Record<string, string[]>): string[];
export declare function prettyTree(tree: DependencyTree, entries: string[], prefix?: string): string;
export declare function prettyCircular(circulars: string[][], prefix?: string): string;
export declare function prettyWarning(warnings: string[], prefix?: string): string;
