/*!
 * Copyright 2019 acrazing <joking.young@gmail.com>. All rights reserved.
 * @since 2019-07-17 18:45:32
 */
import { DependencyTree, ParseOptions } from './types';
/**
 * @param entries - the entry glob list
 * @param options
 */
export declare function parseDependencyTree(entries: string[] | string, options: Partial<ParseOptions>): Promise<DependencyTree>;
