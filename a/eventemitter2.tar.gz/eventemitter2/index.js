module.exports = require('./lib/eventemitter2');
