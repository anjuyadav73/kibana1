'use strict';

require('es5-shim');
require('es6-shim');

require('./');
