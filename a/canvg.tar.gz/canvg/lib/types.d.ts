export declare type RenderingContext2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;
//# sourceMappingURL=types.d.ts.map