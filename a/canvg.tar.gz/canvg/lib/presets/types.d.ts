/**
 * XML/HTML parser from string into DOM Document.
 */
export interface DOMParser {
    prototype: any;
    new (): any;
}
//# sourceMappingURL=types.d.ts.map