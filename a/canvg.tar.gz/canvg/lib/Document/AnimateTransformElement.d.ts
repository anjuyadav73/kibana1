import AnimateElement from './AnimateElement';
export default class AnimateTransformElement extends AnimateElement {
    type: string;
    calcValue(): string;
}
//# sourceMappingURL=AnimateTransformElement.d.ts.map