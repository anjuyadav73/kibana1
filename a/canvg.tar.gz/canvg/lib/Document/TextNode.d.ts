import TSpanElement from './TSpanElement';
export default class TextNode extends TSpanElement {
    type: string;
}
//# sourceMappingURL=TextNode.d.ts.map