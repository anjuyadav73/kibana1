import Element from './Element';
export default class TitleElement extends Element {
    type: string;
}
//# sourceMappingURL=TitleElement.d.ts.map