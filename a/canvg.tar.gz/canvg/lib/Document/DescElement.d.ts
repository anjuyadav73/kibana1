import Element from './Element';
export default class DescElement extends Element {
    type: string;
}
//# sourceMappingURL=DescElement.d.ts.map