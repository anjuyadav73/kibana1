import PathElement from './PathElement';
export default class MissingGlyphElement extends PathElement {
    type: string;
    readonly horizAdvX = 0;
}
//# sourceMappingURL=MissingGlyphElement.d.ts.map