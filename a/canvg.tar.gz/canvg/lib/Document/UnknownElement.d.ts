import Document from './Document';
import Element from './Element';
export default class UnknownElement extends Element {
    constructor(document: Document, node: HTMLElement, captureTextNodes?: boolean);
}
//# sourceMappingURL=UnknownElement.d.ts.map