export { default } from './Document';
export * from './Document';
export * from './elements';
//# sourceMappingURL=index.d.ts.map