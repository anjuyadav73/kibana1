# node-trace-event changelog

## 1.3.1 (not yet released)

(nothing yet)


## 1.3.0

- Add `.child(<fields>)` option to `trace_event.createBunyanTracer()` object.


## 1.2.0

- Add `trace_event.createBunyanLogger()` usage for some sugar. See the
  README.md for details.


## 1.1.0

- Rename to 'trace-event', which is a much more accurate name.


## 1.0.0

First release.
