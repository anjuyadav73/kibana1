## Collaborators

dependency-check is only possible due to the excellent work of the following collaborators:

| Nickname    | Profile                                              |
|-------------|------------------------------------------------------|
| blakeembrey | [GitHub/blakeembrey](https://github.com/blakeembrey) |
| voxpelli    | [GitHub/voxpelli](https://github.com/voxpelli)       |
| maxogden    | [GitHub/maxogden](https://github.com/maxogden)       |
