/**
 * returns true if the current environment is NodeJS
 */
export declare const isNode: boolean;