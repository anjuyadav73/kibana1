"use strict";

var isImplemented = require("../../../string/from-code-point/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
