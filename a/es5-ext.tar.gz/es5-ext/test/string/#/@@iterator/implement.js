"use strict";

var isImplemented = require("../../../../string/#/@@iterator/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
