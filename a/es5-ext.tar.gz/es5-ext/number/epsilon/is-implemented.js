"use strict";

module.exports = function () {
	return typeof Number.EPSILON === "number";
};
