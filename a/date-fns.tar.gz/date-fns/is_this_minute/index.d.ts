declare module 'date-fns/is_this_minute' {
  import {isThisMinute} from 'date-fns'
  export = isThisMinute
}
