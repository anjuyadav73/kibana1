declare module 'date-fns/end_of_today' {
  import {endOfToday} from 'date-fns'
  export = endOfToday
}
