declare module 'date-fns/sub_days' {
  import {subDays} from 'date-fns'
  export = subDays
}
