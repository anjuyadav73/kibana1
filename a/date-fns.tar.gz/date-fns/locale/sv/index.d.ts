declare module 'date-fns/locale/sv' { }
