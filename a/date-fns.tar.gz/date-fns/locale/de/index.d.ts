declare module 'date-fns/locale/de' { }
