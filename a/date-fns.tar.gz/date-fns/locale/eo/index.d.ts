declare module 'date-fns/locale/eo' { }
