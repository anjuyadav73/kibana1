declare module 'date-fns/locale/sl' { }
