declare module 'date-fns/locale/hu' { }
