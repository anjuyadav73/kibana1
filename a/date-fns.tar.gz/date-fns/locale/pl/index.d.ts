declare module 'date-fns/locale/pl' { }
