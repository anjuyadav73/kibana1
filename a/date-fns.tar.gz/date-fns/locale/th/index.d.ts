declare module 'date-fns/locale/th' { }
