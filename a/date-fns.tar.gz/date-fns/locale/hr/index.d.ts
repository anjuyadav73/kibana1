declare module 'date-fns/locale/hr' { }
