declare module 'date-fns/locale/zh_cn' { }
