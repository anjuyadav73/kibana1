declare module 'date-fns/locale/be' { }
