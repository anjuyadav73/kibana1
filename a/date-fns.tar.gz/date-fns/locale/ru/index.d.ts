declare module 'date-fns/locale/ru' { }
