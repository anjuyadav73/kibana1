declare module 'date-fns/locale/mk' { }
