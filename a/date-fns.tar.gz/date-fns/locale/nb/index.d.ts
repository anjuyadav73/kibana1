declare module 'date-fns/locale/nb' { }
