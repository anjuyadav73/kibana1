declare module 'date-fns/locale/zh_tw' { }
