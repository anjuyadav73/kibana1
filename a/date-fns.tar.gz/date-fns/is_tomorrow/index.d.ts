declare module 'date-fns/is_tomorrow' {
  import {isTomorrow} from 'date-fns'
  export = isTomorrow
}
