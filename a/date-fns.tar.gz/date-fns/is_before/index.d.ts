declare module 'date-fns/is_before' {
  import {isBefore} from 'date-fns'
  export = isBefore
}
