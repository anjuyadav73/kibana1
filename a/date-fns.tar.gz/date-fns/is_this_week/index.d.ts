declare module 'date-fns/is_this_week' {
  import {isThisWeek} from 'date-fns'
  export = isThisWeek
}
