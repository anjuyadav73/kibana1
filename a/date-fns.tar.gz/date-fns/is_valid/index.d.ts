declare module 'date-fns/is_valid' {
  import {isValid} from 'date-fns'
  export = isValid
}
