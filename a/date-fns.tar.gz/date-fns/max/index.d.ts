declare module 'date-fns/max' {
  import {max} from 'date-fns'
  export = max
}
