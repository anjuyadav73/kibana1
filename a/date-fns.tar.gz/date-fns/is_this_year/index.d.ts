declare module 'date-fns/is_this_year' {
  import {isThisYear} from 'date-fns'
  export = isThisYear
}
