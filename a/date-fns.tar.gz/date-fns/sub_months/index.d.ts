declare module 'date-fns/sub_months' {
  import {subMonths} from 'date-fns'
  export = subMonths
}
