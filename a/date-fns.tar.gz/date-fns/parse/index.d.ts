declare module 'date-fns/parse' {
  import {parse} from 'date-fns'
  export = parse
}
