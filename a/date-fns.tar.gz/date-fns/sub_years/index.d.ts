declare module 'date-fns/sub_years' {
  import {subYears} from 'date-fns'
  export = subYears
}
