declare module 'date-fns/add_days' {
  import {addDays} from 'date-fns'
  export = addDays
}
