declare module 'date-fns/add_years' {
  import {addYears} from 'date-fns'
  export = addYears
}
