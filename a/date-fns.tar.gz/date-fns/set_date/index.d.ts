declare module 'date-fns/set_date' {
  import {setDate} from 'date-fns'
  export = setDate
}
