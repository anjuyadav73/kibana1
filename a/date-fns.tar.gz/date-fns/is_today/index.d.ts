declare module 'date-fns/is_today' {
  import {isToday} from 'date-fns'
  export = isToday
}
