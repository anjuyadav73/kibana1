declare module 'date-fns/start_of_tomorrow' {
  import {startOfTomorrow} from 'date-fns'
  export = startOfTomorrow
}
