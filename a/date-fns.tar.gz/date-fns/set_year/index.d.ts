declare module 'date-fns/set_year' {
  import {setYear} from 'date-fns'
  export = setYear
}
