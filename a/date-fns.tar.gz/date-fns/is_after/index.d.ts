declare module 'date-fns/is_after' {
  import {isAfter} from 'date-fns'
  export = isAfter
}
