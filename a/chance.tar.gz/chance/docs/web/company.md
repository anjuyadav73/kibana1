# company

```js
// usage
chance.company()
```

Return a random company name.

```js
chance.company()
=> 'Caremark Rx Inc'
```
