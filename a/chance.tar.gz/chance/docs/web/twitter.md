# twitter

```js
// usage
chance.twitter()
```

Return a random twitter handle.

```js
chance.twitter()
=> "@guspejani"
```
