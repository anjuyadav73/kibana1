# klout

```js
// usage
chance.klout()
```

Return a random [Klout](http://klout.com) score. Range 1-99.

```js
chance.klout()
=> 21
```
