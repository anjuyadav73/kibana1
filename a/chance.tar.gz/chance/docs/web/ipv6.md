# ipv6

```js
// usage
chance.ipv6()
```

Return a random IPv6 Address.

```js
chance.ipv6()
=> 'db2f:6123:f99e:00f7:a76e:7f68:9f91:bb08'
```

