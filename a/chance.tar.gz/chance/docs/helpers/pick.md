# pick

```js
// usage
chance.pick(array)
chance.pick(array, count)
```

**`pick()` is now deprecated in favor of `pickone()` and `pickset()`**
