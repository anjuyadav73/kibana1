# pickone

```js
// usage
chance.pickone(array)
```

Given an array, pick a random element and return it

```js
chance.pickone(['alpha', 'bravo', 'charlie', 'delta', 'echo']);
=> 'delta'
```
