# cpf

```js
// usage
chance.cpf()
```

Generate a random Brazilian tax id.

```js
chance.cpf();
=> '607.116.899-62'
```
