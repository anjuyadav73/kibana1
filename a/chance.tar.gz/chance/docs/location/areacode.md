# areacode

```js
// usage
chance.areacode()
```

Generate a random area code

```js
chance.areacode()
=> '(526)'
```

*Note, this is a US area code, we have little support for internationalization
at this time. Hope to fix that in the future!*
