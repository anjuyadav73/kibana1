# millisecond

```js
// usage
chance.millisecond()
```

Generate a random millisecond

```js
chance.millisecond();
=> 729
```

By default, returns a millisecond from 0 to 999. Idea is for generating a clock time.
