# apple_token

```js
// usage
chance.apple_token()
```

Return a random Apple Push Token

```js
chance.apple_token()
=> 'b50edac575bfba07dd019b28b2af7189a3ddda17c806ef14a9abbfd00533f67e'
```
