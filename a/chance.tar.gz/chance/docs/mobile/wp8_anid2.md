# wp8_anid2

```js
// usage
chance.wp8_anid2()
```

Return a random Windows Phone 8 ANID2

```js
chance.wp8_anid2()
=> 'OGI5ODk0MmNkZGI2OGE3YzAwODE1Y2NiYTc4MzEzZjM='
```
