// For backwards compatibility, make sure require("graphql-tag") returns
// the gql function, rather than an exports object.
module.exports = require('./lib/graphql-tag.umd.js').gql;
