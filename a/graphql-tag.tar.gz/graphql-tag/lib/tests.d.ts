import 'source-map-support/register';
//# sourceMappingURL=tests.d.ts.map