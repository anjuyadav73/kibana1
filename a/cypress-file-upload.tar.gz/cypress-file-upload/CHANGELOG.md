# CHANGELOG

You can see the changelog on the [releases page](../../releases).
