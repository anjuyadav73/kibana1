module.exports = require('../full/get-iterator-method');
