module.exports = require('../../full/data-view');
