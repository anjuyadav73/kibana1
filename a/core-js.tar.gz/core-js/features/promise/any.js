module.exports = require('../../full/promise/any');
