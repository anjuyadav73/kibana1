module.exports = require('../../full/promise');
