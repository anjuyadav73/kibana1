module.exports = require('../../full/reflect/get-prototype-of');
