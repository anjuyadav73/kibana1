module.exports = require('../../full/reflect/get-own-metadata-keys');
