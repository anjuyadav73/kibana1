module.exports = require('../../full/reflect/to-string-tag');
