module.exports = require('../../full/reflect/construct');
