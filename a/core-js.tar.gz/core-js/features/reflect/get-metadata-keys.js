module.exports = require('../../full/reflect/get-metadata-keys');
