module.exports = require('../../full/reflect/prevent-extensions');
