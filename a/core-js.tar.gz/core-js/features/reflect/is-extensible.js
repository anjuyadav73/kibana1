module.exports = require('../../full/reflect/is-extensible');
