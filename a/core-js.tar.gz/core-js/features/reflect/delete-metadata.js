module.exports = require('../../full/reflect/delete-metadata');
