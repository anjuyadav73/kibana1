module.exports = require('../../full/reflect/has-own-metadata');
