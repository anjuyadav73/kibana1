module.exports = require('../../full/reflect/set-prototype-of');
