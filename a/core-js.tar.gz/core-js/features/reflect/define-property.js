module.exports = require('../../full/reflect/define-property');
