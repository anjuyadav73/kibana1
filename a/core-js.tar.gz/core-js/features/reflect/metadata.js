module.exports = require('../../full/reflect/metadata');
