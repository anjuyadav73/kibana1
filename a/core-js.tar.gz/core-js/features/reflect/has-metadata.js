module.exports = require('../../full/reflect/has-metadata');
