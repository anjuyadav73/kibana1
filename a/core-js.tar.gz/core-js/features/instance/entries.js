module.exports = require('../../full/instance/entries');
