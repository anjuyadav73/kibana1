module.exports = require('../../full/instance/ends-with');
