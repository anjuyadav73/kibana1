module.exports = require('../../full/instance/code-points');
