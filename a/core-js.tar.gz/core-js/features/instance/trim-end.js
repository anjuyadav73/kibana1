module.exports = require('../../full/instance/trim-end');
