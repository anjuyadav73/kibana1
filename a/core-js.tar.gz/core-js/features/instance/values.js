module.exports = require('../../full/instance/values');
