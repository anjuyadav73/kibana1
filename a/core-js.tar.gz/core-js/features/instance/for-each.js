module.exports = require('../../full/instance/for-each');
