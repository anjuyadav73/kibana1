module.exports = require('../../full/instance/find');
