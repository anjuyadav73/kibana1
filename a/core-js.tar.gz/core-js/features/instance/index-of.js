module.exports = require('../../full/instance/index-of');
