module.exports = require('../../full/instance/starts-with');
