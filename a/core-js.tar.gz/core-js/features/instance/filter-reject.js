module.exports = require('../../full/instance/filter-reject');
