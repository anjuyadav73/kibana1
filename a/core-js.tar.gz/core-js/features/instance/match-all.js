module.exports = require('../../full/instance/match-all');
