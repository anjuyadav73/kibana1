module.exports = require('../../full/instance/to-spliced');
