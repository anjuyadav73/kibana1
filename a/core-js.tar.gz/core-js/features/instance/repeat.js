module.exports = require('../../full/instance/repeat');
