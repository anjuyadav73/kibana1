module.exports = require('../../full/instance/copy-within');
