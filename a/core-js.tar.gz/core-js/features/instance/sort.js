module.exports = require('../../full/instance/sort');
