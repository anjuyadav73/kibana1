module.exports = require('../../full/instance/group-by-to-map');
