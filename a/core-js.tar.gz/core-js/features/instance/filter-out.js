module.exports = require('../../full/instance/filter-out');
