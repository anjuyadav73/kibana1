module.exports = require('../../full/instance/push');
