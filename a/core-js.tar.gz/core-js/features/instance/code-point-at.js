module.exports = require('../../full/instance/code-point-at');
