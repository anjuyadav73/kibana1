module.exports = require('../../full/instance/flat-map');
