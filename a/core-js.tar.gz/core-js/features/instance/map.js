module.exports = require('../../full/instance/map');
