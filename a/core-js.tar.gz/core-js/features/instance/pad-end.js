module.exports = require('../../full/instance/pad-end');
