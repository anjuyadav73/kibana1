module.exports = require('../../full/instance/splice');
