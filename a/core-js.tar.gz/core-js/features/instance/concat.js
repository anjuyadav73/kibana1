module.exports = require('../../full/instance/concat');
