module.exports = require('../../full/instance/slice');
