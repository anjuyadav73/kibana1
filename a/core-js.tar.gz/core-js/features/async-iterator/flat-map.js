module.exports = require('../../full/async-iterator/flat-map');
