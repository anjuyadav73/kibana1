module.exports = require('../../full/async-iterator');
