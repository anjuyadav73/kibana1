module.exports = require('../../full/async-iterator/every');
