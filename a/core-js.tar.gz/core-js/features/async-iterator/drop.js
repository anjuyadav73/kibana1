module.exports = require('../../full/async-iterator/drop');
