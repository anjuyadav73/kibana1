module.exports = require('../../full/set/delete-all');
