module.exports = require('../../full/set/reduce');
