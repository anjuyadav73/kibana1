module.exports = require('../../full/set/intersection');
