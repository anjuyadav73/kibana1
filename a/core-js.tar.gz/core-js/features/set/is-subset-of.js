module.exports = require('../../full/set/is-subset-of');
