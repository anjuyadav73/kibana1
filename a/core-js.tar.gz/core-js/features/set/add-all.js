module.exports = require('../../full/set/add-all');
