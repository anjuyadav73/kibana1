module.exports = require('../../full/set/every');
