module.exports = require('../../full/set/union');
