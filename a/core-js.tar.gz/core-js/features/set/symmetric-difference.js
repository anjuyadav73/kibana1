module.exports = require('../../full/set/symmetric-difference');
