module.exports = require('../../full/set/join');
