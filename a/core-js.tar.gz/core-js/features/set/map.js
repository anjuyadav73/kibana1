module.exports = require('../../full/set/map');
