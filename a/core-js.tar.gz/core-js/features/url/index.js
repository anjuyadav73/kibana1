module.exports = require('../../full/url');
