module.exports = require('../../full/weak-set/add-all');
