module.exports = require('../../full/weak-set');
