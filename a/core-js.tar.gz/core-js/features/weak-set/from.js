module.exports = require('../../full/weak-set/from');
