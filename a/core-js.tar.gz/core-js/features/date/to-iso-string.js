module.exports = require('../../full/date/to-iso-string');
