module.exports = require('../../full/date/to-gmt-string');
