module.exports = require('../../full/date/set-year');
