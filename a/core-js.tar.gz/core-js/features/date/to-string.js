module.exports = require('../../full/date/to-string');
