module.exports = require('../../full/date/now');
