module.exports = require('../../full/date/to-primitive');
