module.exports = require('../../full/weak-map/emplace');
