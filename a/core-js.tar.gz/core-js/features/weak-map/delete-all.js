module.exports = require('../../full/weak-map/delete-all');
