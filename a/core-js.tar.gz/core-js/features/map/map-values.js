module.exports = require('../../full/map/map-values');
