module.exports = require('../../full/map/update');
