module.exports = require('../../full/map/of');
