module.exports = require('../../full/map/merge');
