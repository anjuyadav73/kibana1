module.exports = require('../../full/map/emplace');
