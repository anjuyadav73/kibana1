module.exports = require('../../full/map/filter');
