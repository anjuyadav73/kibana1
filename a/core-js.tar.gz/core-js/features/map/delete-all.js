module.exports = require('../../full/map/delete-all');
