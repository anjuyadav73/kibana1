module.exports = require('../../full/map/reduce');
