module.exports = require('../../full/map/upsert');
