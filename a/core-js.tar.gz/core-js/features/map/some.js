module.exports = require('../../full/map/some');
