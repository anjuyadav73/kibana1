module.exports = require('../../full/map/every');
