module.exports = require('../full/composite-symbol');
