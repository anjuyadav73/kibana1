module.exports = require('../../full/array-buffer/slice');
