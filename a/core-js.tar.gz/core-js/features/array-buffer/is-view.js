module.exports = require('../../full/array-buffer/is-view');
