module.exports = require('../../full/dom-collections/for-each');
