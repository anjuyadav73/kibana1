module.exports = require('../../full/typed-array/set');
