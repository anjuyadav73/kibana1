module.exports = require('../../full/typed-array/values');
