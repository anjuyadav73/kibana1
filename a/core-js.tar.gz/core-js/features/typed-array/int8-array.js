module.exports = require('../../full/typed-array/int8-array');
