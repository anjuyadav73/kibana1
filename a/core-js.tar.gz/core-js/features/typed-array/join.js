module.exports = require('../../full/typed-array/join');
