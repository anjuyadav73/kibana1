module.exports = require('../../full/typed-array/to-locale-string');
