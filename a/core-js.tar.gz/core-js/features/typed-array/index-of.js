module.exports = require('../../full/typed-array/index-of');
