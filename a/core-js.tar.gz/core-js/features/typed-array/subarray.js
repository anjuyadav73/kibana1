module.exports = require('../../full/typed-array/subarray');
