module.exports = require('../../full/typed-array/iterator');
