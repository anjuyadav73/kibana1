module.exports = require('../../full/typed-array/from');
