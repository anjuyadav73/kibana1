module.exports = require('../../full/typed-array/entries');
