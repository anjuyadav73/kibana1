module.exports = require('../../full/typed-array/at');
