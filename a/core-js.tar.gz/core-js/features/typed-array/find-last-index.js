module.exports = require('../../full/typed-array/find-last-index');
