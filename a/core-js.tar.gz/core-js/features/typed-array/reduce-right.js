module.exports = require('../../full/typed-array/reduce-right');
