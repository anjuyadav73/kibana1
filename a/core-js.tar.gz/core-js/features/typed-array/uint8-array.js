module.exports = require('../../full/typed-array/uint8-array');
