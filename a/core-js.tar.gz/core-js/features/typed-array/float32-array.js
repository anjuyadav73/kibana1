module.exports = require('../../full/typed-array/float32-array');
