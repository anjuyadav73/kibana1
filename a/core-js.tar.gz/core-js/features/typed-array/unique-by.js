module.exports = require('../../full/typed-array/unique-by');
