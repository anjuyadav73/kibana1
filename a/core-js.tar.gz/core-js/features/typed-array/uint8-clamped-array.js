module.exports = require('../../full/typed-array/uint8-clamped-array');
