module.exports = require('../../full/observable');
