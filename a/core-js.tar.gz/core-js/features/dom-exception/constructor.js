module.exports = require('../../full/dom-exception/constructor');
