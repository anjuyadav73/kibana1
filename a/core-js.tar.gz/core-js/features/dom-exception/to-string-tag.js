module.exports = require('../../full/dom-exception/to-string-tag');
