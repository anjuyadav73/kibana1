module.exports = require('../full/set-immediate');
