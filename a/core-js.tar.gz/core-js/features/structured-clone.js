module.exports = require('../full/structured-clone');
