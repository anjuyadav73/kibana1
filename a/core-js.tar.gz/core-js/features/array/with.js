module.exports = require('../../full/array/with');
