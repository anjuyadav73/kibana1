module.exports = require('../../full/array/splice');
