module.exports = require('../../../full/array/virtual/last-index-of');
