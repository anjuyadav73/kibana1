module.exports = require('../../../full/array/virtual/at');
