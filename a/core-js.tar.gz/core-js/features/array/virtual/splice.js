module.exports = require('../../../full/array/virtual/splice');
