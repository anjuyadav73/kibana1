module.exports = require('../../../full/array/virtual/index-of');
