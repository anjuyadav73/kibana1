module.exports = require('../../../full/array/virtual/group');
