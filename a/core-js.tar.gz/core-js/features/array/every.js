module.exports = require('../../full/array/every');
