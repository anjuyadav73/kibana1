module.exports = require('../../full/array/values');
