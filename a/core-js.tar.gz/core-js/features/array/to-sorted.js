module.exports = require('../../full/array/to-sorted');
