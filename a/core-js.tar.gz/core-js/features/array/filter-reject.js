module.exports = require('../../full/array/filter-reject');
