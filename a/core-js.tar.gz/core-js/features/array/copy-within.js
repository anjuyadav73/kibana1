module.exports = require('../../full/array/copy-within');
