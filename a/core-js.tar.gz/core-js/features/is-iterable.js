module.exports = require('../full/is-iterable');
