module.exports = require('../../full/string/trim-start');
