module.exports = require('../../full/string/blink');
