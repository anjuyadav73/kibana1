module.exports = require('../../full/string/link');
