module.exports = require('../../full/string/raw');
