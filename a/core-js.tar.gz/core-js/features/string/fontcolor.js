module.exports = require('../../full/string/fontcolor');
