module.exports = require('../../../full/string/virtual');
