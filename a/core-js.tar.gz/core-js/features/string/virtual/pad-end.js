module.exports = require('../../../full/string/virtual/pad-end');
