module.exports = require('../../../full/string/virtual/ends-with');
