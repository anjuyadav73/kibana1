module.exports = require('../../../full/string/virtual/trim-start');
