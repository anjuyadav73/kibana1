module.exports = require('../../../full/string/virtual/replace-all');
