module.exports = require('../../full/string/anchor');
