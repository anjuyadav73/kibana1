module.exports = require('../../full/string/sup');
