module.exports = require('../../full/string/replace-all');
