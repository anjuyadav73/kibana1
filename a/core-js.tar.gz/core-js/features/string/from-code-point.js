module.exports = require('../../full/string/from-code-point');
