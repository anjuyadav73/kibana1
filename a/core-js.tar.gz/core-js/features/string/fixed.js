module.exports = require('../../full/string/fixed');
