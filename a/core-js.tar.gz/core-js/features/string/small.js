module.exports = require('../../full/string/small');
