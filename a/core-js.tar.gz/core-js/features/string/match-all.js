module.exports = require('../../full/string/match-all');
