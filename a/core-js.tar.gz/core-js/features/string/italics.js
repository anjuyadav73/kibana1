module.exports = require('../../full/string/italics');
