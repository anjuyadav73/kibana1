module.exports = require('../../full/string/strike');
