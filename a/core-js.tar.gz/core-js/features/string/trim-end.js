module.exports = require('../../full/string/trim-end');
