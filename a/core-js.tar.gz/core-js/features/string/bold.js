module.exports = require('../../full/string/bold');
