module.exports = require('../../full/string/pad-start');
