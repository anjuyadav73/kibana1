module.exports = require('../../full/string/search');
