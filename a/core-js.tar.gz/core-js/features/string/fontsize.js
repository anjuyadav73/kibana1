module.exports = require('../../full/string/fontsize');
