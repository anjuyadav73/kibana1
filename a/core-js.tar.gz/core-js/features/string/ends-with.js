module.exports = require('../../full/string/ends-with');
