module.exports = require('../../full/string/code-points');
