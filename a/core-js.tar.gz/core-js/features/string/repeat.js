module.exports = require('../../full/string/repeat');
