module.exports = require('../../full/string/pad-end');
