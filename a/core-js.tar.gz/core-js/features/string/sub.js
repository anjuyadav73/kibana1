module.exports = require('../../full/string/sub');
