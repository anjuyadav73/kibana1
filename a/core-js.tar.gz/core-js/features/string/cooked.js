module.exports = require('../../full/string/cooked');
