module.exports = require('../../full/string/includes');
