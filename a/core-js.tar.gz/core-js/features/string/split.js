module.exports = require('../../full/string/split');
