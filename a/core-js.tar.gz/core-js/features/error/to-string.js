module.exports = require('../../full/error/to-string');
