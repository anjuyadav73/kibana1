module.exports = require('../../full/error/constructor');
