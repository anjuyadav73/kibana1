module.exports = require('../../../full/number/virtual/to-precision');
