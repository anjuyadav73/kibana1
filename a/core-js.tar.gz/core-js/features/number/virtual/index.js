module.exports = require('../../../full/number/virtual');
