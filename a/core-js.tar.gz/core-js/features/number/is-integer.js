module.exports = require('../../full/number/is-integer');
