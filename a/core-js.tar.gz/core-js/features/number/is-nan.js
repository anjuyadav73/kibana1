module.exports = require('../../full/number/is-nan');
