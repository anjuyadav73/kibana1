module.exports = require('../../full/number/min-safe-integer');
