module.exports = require('../../full/number/to-exponential');
