module.exports = require('../../full/number/parse-float');
