module.exports = require('../../full/number/is-safe-integer');
