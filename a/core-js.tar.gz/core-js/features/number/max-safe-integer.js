module.exports = require('../../full/number/max-safe-integer');
