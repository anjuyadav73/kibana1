module.exports = require('../../full/number/constructor');
