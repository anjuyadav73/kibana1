module.exports = require('../../full/number');
