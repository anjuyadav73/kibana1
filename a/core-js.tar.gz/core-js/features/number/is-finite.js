module.exports = require('../../full/number/is-finite');
