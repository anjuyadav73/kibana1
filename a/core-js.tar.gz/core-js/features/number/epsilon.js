module.exports = require('../../full/number/epsilon');
