module.exports = require('../../full/number/parse-int');
