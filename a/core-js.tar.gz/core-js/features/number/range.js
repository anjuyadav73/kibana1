module.exports = require('../../full/number/range');
