module.exports = require('../../full/number/from-string');
