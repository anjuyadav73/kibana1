module.exports = require('../../full/object/define-properties');
