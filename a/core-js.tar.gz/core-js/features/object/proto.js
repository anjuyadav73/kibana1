module.exports = require('../../full/object/proto');
