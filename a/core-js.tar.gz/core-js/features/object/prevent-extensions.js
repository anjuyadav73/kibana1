module.exports = require('../../full/object/prevent-extensions');
