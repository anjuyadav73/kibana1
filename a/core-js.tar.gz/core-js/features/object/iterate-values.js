module.exports = require('../../full/object/iterate-values');
