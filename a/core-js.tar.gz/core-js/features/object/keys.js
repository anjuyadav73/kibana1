module.exports = require('../../full/object/keys');
