module.exports = require('../../full/object/assign');
