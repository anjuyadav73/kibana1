module.exports = require('../../full/object/from-entries');
