module.exports = require('../../full/json/to-string-tag');
