module.exports = require('../../full/json/stringify');
