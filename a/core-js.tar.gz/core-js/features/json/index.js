module.exports = require('../../full/json');
