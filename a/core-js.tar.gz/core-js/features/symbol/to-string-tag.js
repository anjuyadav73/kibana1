module.exports = require('../../full/symbol/to-string-tag');
