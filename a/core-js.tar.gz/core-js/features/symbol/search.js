module.exports = require('../../full/symbol/search');
