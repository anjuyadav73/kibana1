module.exports = require('../../full/symbol/matcher');
