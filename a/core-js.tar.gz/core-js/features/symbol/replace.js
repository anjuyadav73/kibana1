module.exports = require('../../full/symbol/replace');
