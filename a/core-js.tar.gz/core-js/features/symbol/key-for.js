module.exports = require('../../full/symbol/key-for');
