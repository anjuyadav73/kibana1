module.exports = require('../../full/symbol/split');
