module.exports = require('../../full/symbol/species');
