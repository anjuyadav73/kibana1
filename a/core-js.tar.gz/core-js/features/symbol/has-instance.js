module.exports = require('../../full/symbol/has-instance');
