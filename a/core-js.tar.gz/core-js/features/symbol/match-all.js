module.exports = require('../../full/symbol/match-all');
