module.exports = require('../../full/symbol/metadata-key');
