module.exports = require('../../full/symbol/pattern-match');
