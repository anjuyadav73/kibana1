module.exports = require('../../full/symbol/iterator');
