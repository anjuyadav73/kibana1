module.exports = require('../../full/symbol/for');
