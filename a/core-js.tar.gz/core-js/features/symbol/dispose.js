module.exports = require('../../full/symbol/dispose');
