module.exports = require('../../full/symbol/observable');
