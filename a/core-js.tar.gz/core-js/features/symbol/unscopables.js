module.exports = require('../../full/symbol/unscopables');
