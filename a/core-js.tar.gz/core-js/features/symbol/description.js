module.exports = require('../../full/symbol/description');
