module.exports = require('../full/global-this');
