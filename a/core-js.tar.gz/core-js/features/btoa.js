module.exports = require('../full/btoa');
