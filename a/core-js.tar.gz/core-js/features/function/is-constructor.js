module.exports = require('../../full/function/is-constructor');
