module.exports = require('../../full/function/name');
