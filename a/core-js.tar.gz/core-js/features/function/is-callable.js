module.exports = require('../../full/function/is-callable');
