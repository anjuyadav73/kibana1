module.exports = require('../../full/function/bind');
