module.exports = require('../../../full/function/virtual/un-this');
