module.exports = require('../../../full/function/virtual');
