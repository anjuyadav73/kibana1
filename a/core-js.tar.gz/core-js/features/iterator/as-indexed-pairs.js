module.exports = require('../../full/iterator/as-indexed-pairs');
