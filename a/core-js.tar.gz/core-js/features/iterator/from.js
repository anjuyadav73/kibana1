module.exports = require('../../full/iterator/from');
