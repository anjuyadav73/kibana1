module.exports = require('../../full/iterator/for-each');
