module.exports = require('../../full/iterator/filter');
