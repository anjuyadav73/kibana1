module.exports = require('../../full/iterator/find');
