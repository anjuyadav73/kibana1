module.exports = require('../../full/iterator/take');
