module.exports = require('../../full/iterator/map');
