module.exports = require('../../full/iterator/drop');
