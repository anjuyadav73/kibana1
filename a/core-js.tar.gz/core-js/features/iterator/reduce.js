module.exports = require('../../full/iterator/reduce');
