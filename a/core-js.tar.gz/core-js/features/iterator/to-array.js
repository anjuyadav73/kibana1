module.exports = require('../../full/iterator/to-array');
