module.exports = require('../full/set-interval');
