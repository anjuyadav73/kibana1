# @wojtekmaj/enzyme-adapter-utils

Unofficial fork of [enzyme-adapter-utils](https://enzymejs.github.io/enzyme/) with added support for React 17.
