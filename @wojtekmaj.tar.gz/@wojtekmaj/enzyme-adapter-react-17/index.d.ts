import { EnzymeAdapter } from 'enzyme';

declare class ReactSeventeenAdapter extends EnzymeAdapter {}

declare namespace ReactSeventeenAdapter {}

export = ReactSeventeenAdapter;
