module.exports = require('./ReactSeventeenAdapter');
