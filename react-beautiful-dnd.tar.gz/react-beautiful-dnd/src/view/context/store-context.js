// @flow
import React from 'react';
import type { Store } from '../../state/store-types';

export default React.createContext<?Store>(null);
