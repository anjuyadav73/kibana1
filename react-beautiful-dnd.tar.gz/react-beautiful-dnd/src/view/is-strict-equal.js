// @flow
export default (a: mixed, b: mixed): boolean => a === b;
