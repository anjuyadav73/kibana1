// @flow
export { default } from './connected-droppable';
