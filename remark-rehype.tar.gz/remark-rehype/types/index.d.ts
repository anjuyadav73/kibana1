// Minimum TypeScript Version: 3.2
import {Plugin, Processor} from 'unified'
import {Options} from 'mdast-util-to-hast'

declare const remark2rehype: Plugin<[Options?] | [Processor?, Options?]>

export = remark2rehype
