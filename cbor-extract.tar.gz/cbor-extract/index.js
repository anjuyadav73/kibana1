module.exports = require('node-gyp-build-optional-packages')(__dirname)
