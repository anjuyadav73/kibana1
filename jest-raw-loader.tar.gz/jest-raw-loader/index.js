module.exports = {
  process: content => "module.exports = " + JSON.stringify(content)
};
