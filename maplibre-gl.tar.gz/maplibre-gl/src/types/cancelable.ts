export type Cancelable = {
    cancel: () => void;
};
