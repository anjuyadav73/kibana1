import {createLayout} from '../util/struct_array';

export default createLayout([
    {name: 'a_pos', type: 'Int16', components: 2}
]);
