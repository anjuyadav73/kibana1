// This file is generated. Edit build/generate-shaders.ts, then run `npm run codegen`.
export default 'void main() {gl_FragColor=vec4(1.0);}';
