declare function nice(inc : number) : number;
export = nice;

