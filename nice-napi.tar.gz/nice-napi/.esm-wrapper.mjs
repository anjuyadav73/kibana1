import mod from "./index.js";

export default mod;
export const nice = mod.nice;
