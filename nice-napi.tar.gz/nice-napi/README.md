# nice-napi – nice(2) bindings for Node.js

https://linux.die.net/man/2/nice as a JS function. That’s it, that’s the module.

```js
const nice = require('nice-napi');
nice(5);  // Increase niceness by 5.
```
