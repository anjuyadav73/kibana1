const SilentReporter = require('./SilentReporter');

module.exports = SilentReporter;
