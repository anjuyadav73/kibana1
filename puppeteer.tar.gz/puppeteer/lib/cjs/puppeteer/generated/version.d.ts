/**
 * @internal
 */
export declare const packageVersion = "18.1.0";
//# sourceMappingURL=version.d.ts.map