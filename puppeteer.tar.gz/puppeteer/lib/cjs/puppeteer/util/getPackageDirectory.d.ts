/**
 * @internal
 */
export declare const getPackageDirectory: (from: string) => string;
//# sourceMappingURL=getPackageDirectory.d.ts.map