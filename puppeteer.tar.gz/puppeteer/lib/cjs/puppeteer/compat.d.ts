/**
 * @internal
 */
declare let puppeteerDirname: string;
export { puppeteerDirname };
//# sourceMappingURL=compat.d.ts.map