// this is the actual main file 'index.js', not 'wrong.js' like the package.json would indicate
module.exports = 1;
