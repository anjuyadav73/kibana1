export const SymbolLegend  = 'symbol';
export const DiscreteLegend = 'discrete';
export const GradientLegend = 'gradient';
