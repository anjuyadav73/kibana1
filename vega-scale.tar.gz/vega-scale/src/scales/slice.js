export const slice = Array.prototype.slice;
