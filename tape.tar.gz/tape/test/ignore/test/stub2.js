'use strict';

var tape = require('../../../');

tape.test(function (t) {
    t.pass('test/stub2');
    t.end();
});
