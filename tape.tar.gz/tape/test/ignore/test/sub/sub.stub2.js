'use strict';

var tape = require('../../../../');

tape.test(function (t) {
    t.pass('test/sub/stub2');
    t.end();
});
