'use strict';

var tape = require('../../');

tape.test(function (t) {
    t.plan(1);
    t.ok('Okay');
});
