'use strict';

var tape = require('../../');

tape.test(function (t) {
    t.pass('Should print');
    t.end();
});
