'use strict';

var test = require('../');

test('No cb test');
