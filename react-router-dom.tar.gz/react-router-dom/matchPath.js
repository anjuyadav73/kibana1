"use strict";
require("./warnAboutDeprecatedCJSRequire")("matchPath");
module.exports = require("./index.js").matchPath;
