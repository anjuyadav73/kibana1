'use strict';

require('./hook-spawn.js');

module.exports = require('./preload-list.js');
