import * as React from 'react';

declare let sidecar: React.FC;

export default sidecar;
