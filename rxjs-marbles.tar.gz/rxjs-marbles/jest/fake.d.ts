export declare function fakeSchedulers(fakeTest: (advance: (milliseconds: number) => void) => any): () => any;
