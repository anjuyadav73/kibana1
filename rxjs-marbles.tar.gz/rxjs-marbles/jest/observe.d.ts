import { Observable } from "rxjs";
export declare type DoneFunction = (error?: Error) => void;
export declare function observe<T>(observableTest: () => Observable<T>): (done: DoneFunction) => void;
