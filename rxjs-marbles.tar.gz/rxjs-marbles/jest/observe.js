"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.observe = void 0;
var done_subscriber_1 = require("../done-subscriber");
function observe(observableTest) {
    return function (done) {
        var subscriber = new done_subscriber_1.DoneSubscriber(done, done);
        observableTest().subscribe(subscriber);
    };
}
exports.observe = observe;
