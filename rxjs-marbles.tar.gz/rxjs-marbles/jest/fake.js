"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fakeSchedulers = void 0;
var fake_1 = require("../fake");
function fakeSchedulers(fakeTest) {
    var fakeTime = 0;
    return fake_1.fakeSchedulers(function () {
        return fakeTest(function (milliseconds) {
            fakeTime += milliseconds;
            jest.advanceTimersByTime(milliseconds);
        });
    }, function () { return fakeTime; });
}
exports.fakeSchedulers = fakeSchedulers;
