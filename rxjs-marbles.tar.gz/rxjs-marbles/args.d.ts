export declare const argsSymbol: unique symbol;
