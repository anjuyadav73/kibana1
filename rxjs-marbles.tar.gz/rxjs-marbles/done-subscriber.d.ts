import { Subscriber } from "rxjs";
export declare class DoneSubscriber<T> extends Subscriber<T> {
    private onError;
    constructor(onError: (error: any) => void, onComplete: () => void);
    unsubscribe(): void;
}
