import { Observable } from "rxjs";
import { ExpectHelpers, TestObservableLike } from "./types";
export declare class Expect<T> {
    private actual;
    private helpers;
    private subscription?;
    constructor(actual: Observable<T>, helpers: ExpectHelpers, subscription?: string | undefined);
    toBeObservable(expected: TestObservableLike<T>): void;
    toBeObservable(expected: string, values?: {
        [key: string]: T;
    }, error?: any): void;
    toHaveSubscriptions(expected: string | string[]): void;
}
