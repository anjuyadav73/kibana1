import { NamedCase, UnnamedCase } from "../cases";
import { Configuration } from "../configuration";
import { Context } from "../context";
import { MarblesFunction } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export { MarblesFunction } from "../marbles";
export * from "./observe";
export interface CasesFunction {
    <T extends UnnamedCase>(name: string, func: (context: Context, _case: T) => void, cases: {
        [key: string]: T;
    }): void;
    <T extends NamedCase>(name: string, func: (context: Context, _case: T) => void, cases: T[]): void;
}
export declare function configure(configuration: Configuration): {
    cases: CasesFunction;
    marbles: MarblesFunction;
};
declare const cases: CasesFunction, marbles: MarblesFunction;
export { cases, marbles };
export declare function fakeSchedulers(fakeTest: () => any): () => any;
