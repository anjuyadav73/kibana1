import { Observable } from "rxjs";
export interface DoneFunction {
    (): void;
    fail: (error: any) => void;
}
export declare function observe<T>(observableTest: () => Observable<T>): (done: DoneFunction) => void;
