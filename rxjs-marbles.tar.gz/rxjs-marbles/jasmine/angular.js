"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fakeSchedulers = void 0;
var testing_1 = require("@angular/core/testing");
var fake_1 = require("../fake");
function fakeSchedulers(fakeTest) {
    return testing_1.fakeAsync(fake_1.fakeSchedulers(function () {
        return fakeTest(function (milliseconds) {
            console.log("The tick parameter passed to the fakeSchedulers test is deprecated; call the @angular/core/testing tick function instead. See the examples for the intended usage.");
            testing_1.tick(milliseconds);
        });
    }));
}
exports.fakeSchedulers = fakeSchedulers;
