export declare function fakeSchedulers(fakeTest: (tick: (milliseconds: number) => void) => any): () => any;
