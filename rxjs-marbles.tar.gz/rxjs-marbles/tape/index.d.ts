import * as tape from "tape";
import { NamedCase, UnnamedCase } from "../cases";
import { Configuration } from "../configuration";
import { Context } from "../context";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export interface CasesFunction {
    <T extends UnnamedCase>(name: string, func: (context: Context, _case: T, t: tape.Test) => void, cases: {
        [key: string]: T;
    }): void;
    <T extends NamedCase>(name: string, func: (context: Context, _case: T, t: tape.Test) => void, cases: T[]): void;
}
export declare type MarblesFunction = (func: (m: Context, t: tape.Test) => any) => any;
export declare function configure(configuration: Configuration): {
    cases: CasesFunction;
    marbles: MarblesFunction;
};
declare const cases: CasesFunction, marbles: MarblesFunction;
export { cases, marbles };
export declare function fakeSchedulers(fakeTest: (t: tape.Test) => any): (t: tape.Test) => any;
