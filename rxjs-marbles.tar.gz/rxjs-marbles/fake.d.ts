export declare function fakeSchedulers(fakeTest: () => any, now?: () => number): () => any;
export declare function fakeSchedulers<T>(fakeTest: (t: T) => any, now?: () => number): (t: T) => any;
