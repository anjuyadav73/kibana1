import { Configuration } from "./configuration";
import { Context } from "./context";
export interface MarblesFunction {
    (func: (context: Context) => any): () => any;
    <T>(func: (context: Context, t: T) => any): (t: T) => any;
    (func: (context: Context, ...rest: any[]) => any): (...rest: any[]) => any;
}
export declare function configure(configuration: Configuration): {
    marbles: MarblesFunction;
};
export declare function configure<T>(factory: (t: T) => Configuration): {
    marbles: MarblesFunction;
};
export declare const marbles: MarblesFunction;
