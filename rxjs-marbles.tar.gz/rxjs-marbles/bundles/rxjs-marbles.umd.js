(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("rxjs"), require("rxjs/testing"));
	else if(typeof define === 'function' && define.amd)
		define(["rxjs", "rxjs/testing"], factory);
	else if(typeof exports === 'object')
		exports["rxjsMarbles"] = factory(require("rxjs"), require("rxjs/testing"));
	else
		root["rxjsMarbles"] = factory(root["rxjs"], root["rxjs"]["testing"]);
})(window, function(__WEBPACK_EXTERNAL_MODULE_rxjs__, __WEBPACK_EXTERNAL_MODULE_rxjs_testing__) {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./source/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/fast-equals/dist/fast-equals.js":
/*!******************************************************!*\
  !*** ./node_modules/fast-equals/dist/fast-equals.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("(function (global, factory) {\n   true ? factory(exports) :\n  undefined;\n}(this, (function (exports) { 'use strict';\n\n  var HAS_WEAKSET_SUPPORT = typeof WeakSet === 'function';\r\n  var keys = Object.keys;\r\n  /**\r\n   * are the values passed strictly equal or both NaN\r\n   *\r\n   * @param a the value to compare against\r\n   * @param b the value to test\r\n   * @returns are the values equal by the SameValueZero principle\r\n   */\r\n  function sameValueZeroEqual(a, b) {\r\n      return a === b || (a !== a && b !== b);\r\n  }\r\n  /**\r\n   * is the value a plain object\r\n   *\r\n   * @param value the value to test\r\n   * @returns is the value a plain object\r\n   */\r\n  function isPlainObject(value) {\r\n      return value.constructor === Object || value.constructor == null;\r\n  }\r\n  /**\r\n   * is the value promise-like (meaning it is thenable)\r\n   *\r\n   * @param value the value to test\r\n   * @returns is the value promise-like\r\n   */\r\n  function isPromiseLike(value) {\r\n      return !!value && typeof value.then === 'function';\r\n  }\r\n  /**\r\n   * is the value passed a react element\r\n   *\r\n   * @param value the value to test\r\n   * @returns is the value a react element\r\n   */\r\n  function isReactElement(value) {\r\n      return !!(value && value.$$typeof);\r\n  }\r\n  /**\r\n   * in cases where WeakSet is not supported, creates a new custom\r\n   * object that mimics the necessary API aspects for cache purposes\r\n   *\r\n   * @returns the new cache object\r\n   */\r\n  function getNewCacheFallback() {\r\n      var values = [];\r\n      return {\r\n          add: function (value) {\r\n              values.push(value);\r\n          },\r\n          has: function (value) {\r\n              return values.indexOf(value) !== -1;\r\n          },\r\n      };\r\n  }\r\n  /**\r\n   * get a new cache object to prevent circular references\r\n   *\r\n   * @returns the new cache object\r\n   */\r\n  var getNewCache = (function (canUseWeakMap) {\r\n      if (canUseWeakMap) {\r\n          return function _getNewCache() {\r\n              return new WeakSet();\r\n          };\r\n      }\r\n      return getNewCacheFallback;\r\n  })(HAS_WEAKSET_SUPPORT);\r\n  /**\r\n   * create a custom isEqual handler specific to circular objects\r\n   *\r\n   * @param [isEqual] the isEqual comparator to use instead of isDeepEqual\r\n   * @returns the method to create the `isEqual` function\r\n   */\r\n  function createCircularEqualCreator(isEqual) {\r\n      return function createCircularEqual(comparator) {\r\n          var _comparator = isEqual || comparator;\r\n          return function circularEqual(a, b, cache) {\r\n              if (cache === void 0) { cache = getNewCache(); }\r\n              var isCacheableA = !!a && typeof a === 'object';\r\n              var isCacheableB = !!b && typeof b === 'object';\r\n              if (isCacheableA || isCacheableB) {\r\n                  var hasA = isCacheableA && cache.has(a);\r\n                  var hasB = isCacheableB && cache.has(b);\r\n                  if (hasA || hasB) {\r\n                      return hasA && hasB;\r\n                  }\r\n                  if (isCacheableA) {\r\n                      cache.add(a);\r\n                  }\r\n                  if (isCacheableB) {\r\n                      cache.add(b);\r\n                  }\r\n              }\r\n              return _comparator(a, b, cache);\r\n          };\r\n      };\r\n  }\r\n  /**\r\n   * are the arrays equal in value\r\n   *\r\n   * @param a the array to test\r\n   * @param b the array to test against\r\n   * @param isEqual the comparator to determine equality\r\n   * @param meta the meta object to pass through\r\n   * @returns are the arrays equal\r\n   */\r\n  function areArraysEqual(a, b, isEqual, meta) {\r\n      var index = a.length;\r\n      if (b.length !== index) {\r\n          return false;\r\n      }\r\n      while (index-- > 0) {\r\n          if (!isEqual(a[index], b[index], meta)) {\r\n              return false;\r\n          }\r\n      }\r\n      return true;\r\n  }\r\n  /**\r\n   * are the maps equal in value\r\n   *\r\n   * @param a the map to test\r\n   * @param b the map to test against\r\n   * @param isEqual the comparator to determine equality\r\n   * @param meta the meta map to pass through\r\n   * @returns are the maps equal\r\n   */\r\n  function areMapsEqual(a, b, isEqual, meta) {\r\n      var isValueEqual = a.size === b.size;\r\n      if (isValueEqual && a.size) {\r\n          a.forEach(function (aValue, aKey) {\r\n              if (isValueEqual) {\r\n                  isValueEqual = false;\r\n                  b.forEach(function (bValue, bKey) {\r\n                      if (!isValueEqual && isEqual(aKey, bKey, meta)) {\r\n                          isValueEqual = isEqual(aValue, bValue, meta);\r\n                      }\r\n                  });\r\n              }\r\n          });\r\n      }\r\n      return isValueEqual;\r\n  }\r\n  var OWNER = '_owner';\r\n  var hasOwnProperty = Function.prototype.bind.call(Function.prototype.call, Object.prototype.hasOwnProperty);\r\n  /**\r\n   * are the objects equal in value\r\n   *\r\n   * @param a the object to test\r\n   * @param b the object to test against\r\n   * @param isEqual the comparator to determine equality\r\n   * @param meta the meta object to pass through\r\n   * @returns are the objects equal\r\n   */\r\n  function areObjectsEqual(a, b, isEqual, meta) {\r\n      var keysA = keys(a);\r\n      var index = keysA.length;\r\n      if (keys(b).length !== index) {\r\n          return false;\r\n      }\r\n      if (index) {\r\n          var key = void 0;\r\n          while (index-- > 0) {\r\n              key = keysA[index];\r\n              if (key === OWNER) {\r\n                  var reactElementA = isReactElement(a);\r\n                  var reactElementB = isReactElement(b);\r\n                  if ((reactElementA || reactElementB) &&\r\n                      reactElementA !== reactElementB) {\r\n                      return false;\r\n                  }\r\n              }\r\n              if (!hasOwnProperty(b, key) || !isEqual(a[key], b[key], meta)) {\r\n                  return false;\r\n              }\r\n          }\r\n      }\r\n      return true;\r\n  }\r\n  /**\r\n   * are the regExps equal in value\r\n   *\r\n   * @param a the regExp to test\r\n   * @param b the regExp to test agains\r\n   * @returns are the regExps equal\r\n   */\r\n  function areRegExpsEqual(a, b) {\r\n      return (a.source === b.source &&\r\n          a.global === b.global &&\r\n          a.ignoreCase === b.ignoreCase &&\r\n          a.multiline === b.multiline &&\r\n          a.unicode === b.unicode &&\r\n          a.sticky === b.sticky &&\r\n          a.lastIndex === b.lastIndex);\r\n  }\r\n  /**\r\n   * are the sets equal in value\r\n   *\r\n   * @param a the set to test\r\n   * @param b the set to test against\r\n   * @param isEqual the comparator to determine equality\r\n   * @param meta the meta set to pass through\r\n   * @returns are the sets equal\r\n   */\r\n  function areSetsEqual(a, b, isEqual, meta) {\r\n      var isValueEqual = a.size === b.size;\r\n      if (isValueEqual && a.size) {\r\n          a.forEach(function (aValue) {\r\n              if (isValueEqual) {\r\n                  isValueEqual = false;\r\n                  b.forEach(function (bValue) {\r\n                      if (!isValueEqual) {\r\n                          isValueEqual = isEqual(aValue, bValue, meta);\r\n                      }\r\n                  });\r\n              }\r\n          });\r\n      }\r\n      return isValueEqual;\r\n  }\n\n  var HAS_MAP_SUPPORT = typeof Map === 'function';\r\n  var HAS_SET_SUPPORT = typeof Set === 'function';\r\n  function createComparator(createIsEqual) {\r\n      var isEqual = \r\n      /* eslint-disable no-use-before-define */\r\n      typeof createIsEqual === 'function'\r\n          ? createIsEqual(comparator)\r\n          : comparator;\r\n      /* eslint-enable */\r\n      /**\r\n       * compare the value of the two objects and return true if they are equivalent in values\r\n       *\r\n       * @param a the value to test against\r\n       * @param b the value to test\r\n       * @param [meta] an optional meta object that is passed through to all equality test calls\r\n       * @returns are a and b equivalent in value\r\n       */\r\n      function comparator(a, b, meta) {\r\n          if (a === b) {\r\n              return true;\r\n          }\r\n          if (a && b && typeof a === 'object' && typeof b === 'object') {\r\n              if (isPlainObject(a) && isPlainObject(b)) {\r\n                  return areObjectsEqual(a, b, isEqual, meta);\r\n              }\r\n              var aShape = Array.isArray(a);\r\n              var bShape = Array.isArray(b);\r\n              if (aShape || bShape) {\r\n                  return aShape === bShape && areArraysEqual(a, b, isEqual, meta);\r\n              }\r\n              aShape = a instanceof Date;\r\n              bShape = b instanceof Date;\r\n              if (aShape || bShape) {\r\n                  return (aShape === bShape && sameValueZeroEqual(a.getTime(), b.getTime()));\r\n              }\r\n              aShape = a instanceof RegExp;\r\n              bShape = b instanceof RegExp;\r\n              if (aShape || bShape) {\r\n                  return aShape === bShape && areRegExpsEqual(a, b);\r\n              }\r\n              if (isPromiseLike(a) || isPromiseLike(b)) {\r\n                  return a === b;\r\n              }\r\n              if (HAS_MAP_SUPPORT) {\r\n                  aShape = a instanceof Map;\r\n                  bShape = b instanceof Map;\r\n                  if (aShape || bShape) {\r\n                      return aShape === bShape && areMapsEqual(a, b, isEqual, meta);\r\n                  }\r\n              }\r\n              if (HAS_SET_SUPPORT) {\r\n                  aShape = a instanceof Set;\r\n                  bShape = b instanceof Set;\r\n                  if (aShape || bShape) {\r\n                      return aShape === bShape && areSetsEqual(a, b, isEqual, meta);\r\n                  }\r\n              }\r\n              return areObjectsEqual(a, b, isEqual, meta);\r\n          }\r\n          return a !== a && b !== b;\r\n      }\r\n      return comparator;\r\n  }\n\n  var deepEqual = createComparator();\r\n  var shallowEqual = createComparator(function () { return sameValueZeroEqual; });\r\n  var circularDeepEqual = createComparator(createCircularEqualCreator());\r\n  var circularShallowEqual = createComparator(createCircularEqualCreator(sameValueZeroEqual));\n\n  exports.circularDeepEqual = circularDeepEqual;\n  exports.circularShallowEqual = circularShallowEqual;\n  exports.createCustomEqual = createComparator;\n  exports.deepEqual = deepEqual;\n  exports.sameValueZeroEqual = sameValueZeroEqual;\n  exports.shallowEqual = shallowEqual;\n\n  Object.defineProperty(exports, '__esModule', { value: true });\n\n})));\n//# sourceMappingURL=fast-equals.js.map\n\n\n//# sourceURL=webpack://rxjsMarbles/./node_modules/fast-equals/dist/fast-equals.js?");

/***/ }),

/***/ "./source/args.ts":
/*!************************!*\
  !*** ./source/args.ts ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.argsSymbol = void 0;\r\nexports.argsSymbol = Symbol(\"args\");\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/args.ts?");

/***/ }),

/***/ "./source/assert.ts":
/*!**************************!*\
  !*** ./source/assert.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.assertSubscriptions = exports.assertArgs = void 0;\r\nvar args_1 = __webpack_require__(/*! ./args */ \"./source/args.ts\");\r\nfunction assertArgs(observable) {\r\n    if (!observable[args_1.argsSymbol]) {\r\n        throw new Error(\"Expected a hot or cold test observable.\");\r\n    }\r\n}\r\nexports.assertArgs = assertArgs;\r\nfunction assertSubscriptions(observable) {\r\n    if (!observable[\"subscriptions\"]) {\r\n        throw new Error(\"Expected a hot or cold test observable with subscriptions.\");\r\n    }\r\n}\r\nexports.assertSubscriptions = assertSubscriptions;\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/assert.ts?");

/***/ }),

/***/ "./source/configuration.ts":
/*!*********************************!*\
  !*** ./source/configuration.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nvar __assign = (this && this.__assign) || function () {\r\n    __assign = Object.assign || function(t) {\r\n        for (var s, i = 1, n = arguments.length; i < n; i++) {\r\n            s = arguments[i];\r\n            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))\r\n                t[p] = s[p];\r\n        }\r\n        return t;\r\n    };\r\n    return __assign.apply(this, arguments);\r\n};\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.defaults = void 0;\r\nvar fast_equals_1 = __webpack_require__(/*! fast-equals */ \"./node_modules/fast-equals/dist/fast-equals.js\");\r\nvar defaultConfiguration = {\r\n    assert: defaultAssert,\r\n    assertDeepEqual: defaultAssertDeepEqual,\r\n    frameworkMatcher: false,\r\n    run: true,\r\n};\r\nfunction defaults() {\r\n    return __assign({}, defaultConfiguration);\r\n}\r\nexports.defaults = defaults;\r\nfunction defaultAssert(value, message) {\r\n    if (value) {\r\n        return;\r\n    }\r\n    throw new Error(message);\r\n}\r\nfunction defaultAssertDeepEqual(a, b) {\r\n    if (fast_equals_1.circularDeepEqual(a, b)) {\r\n        return;\r\n    }\r\n    throw new Error(\"Expected \" + toString(a) + \" to equal \" + toString(b) + \".\");\r\n}\r\nfunction toString(value) {\r\n    if (value === null) {\r\n        return \"null\";\r\n    }\r\n    else if (value === undefined) {\r\n        return \"undefined\";\r\n    }\r\n    return value.toString();\r\n}\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/configuration.ts?");

/***/ }),

/***/ "./source/context-deprecated.ts":
/*!**************************************!*\
  !*** ./source/context-deprecated.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nvar __assign = (this && this.__assign) || function () {\r\n    __assign = Object.assign || function(t) {\r\n        for (var s, i = 1, n = arguments.length; i < n; i++) {\r\n            s = arguments[i];\r\n            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))\r\n                t[p] = s[p];\r\n        }\r\n        return t;\r\n    };\r\n    return __assign.apply(this, arguments);\r\n};\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.DeprecatedContext = void 0;\r\nvar rxjs_1 = __webpack_require__(/*! rxjs */ \"rxjs\");\r\nvar testing_1 = __webpack_require__(/*! rxjs/testing */ \"rxjs/testing\");\r\nvar args_1 = __webpack_require__(/*! ./args */ \"./source/args.ts\");\r\nvar assert_1 = __webpack_require__(/*! ./assert */ \"./source/assert.ts\");\r\nvar expect_1 = __webpack_require__(/*! ./expect */ \"./source/expect.ts\");\r\nvar matcher_1 = __webpack_require__(/*! ./matcher */ \"./source/matcher.ts\");\r\nvar DeprecatedContext = (function () {\r\n    function DeprecatedContext(configuration_) {\r\n        this.configuration_ = configuration_;\r\n        this.autoFlush = true;\r\n        this.bindings_ = [];\r\n        this.frameTimeFactor_ = undefined;\r\n        this.reframable_ = true;\r\n    }\r\n    Object.defineProperty(DeprecatedContext.prototype, \"scheduler\", {\r\n        get: function () {\r\n            var _this = this;\r\n            if (!this.scheduler_) {\r\n                this.scheduler_ = new testing_1.TestScheduler(function (actual, expected) {\r\n                    return matcher_1.observableMatcher(actual, expected, _this.configuration_.assert, _this.configuration_.assertDeepEqual, _this.configuration_.frameworkMatcher);\r\n                });\r\n            }\r\n            return this.scheduler_;\r\n        },\r\n        enumerable: false,\r\n        configurable: true\r\n    });\r\n    DeprecatedContext.prototype.bind = function () {\r\n        var _this = this;\r\n        var schedulers = [];\r\n        for (var _i = 0; _i < arguments.length; _i++) {\r\n            schedulers[_i] = arguments[_i];\r\n        }\r\n        if (this.bindings_.length !== 0) {\r\n            throw new Error(\"Schedulers already bound.\");\r\n        }\r\n        if (schedulers.length === 0) {\r\n            schedulers = [\r\n                rxjs_1.animationFrameScheduler,\r\n                rxjs_1.asapScheduler,\r\n                rxjs_1.asyncScheduler,\r\n                rxjs_1.queueScheduler,\r\n            ];\r\n        }\r\n        this.bindings_ = schedulers.map(function (instance) {\r\n            var now = instance.hasOwnProperty(\"now\") ? instance.now : undefined;\r\n            instance.now = function () { return _this.scheduler.now(); };\r\n            var schedule = instance.hasOwnProperty(\"schedule\")\r\n                ? instance.schedule\r\n                : undefined;\r\n            instance.schedule = function (work, delay, state) {\r\n                return _this.scheduler.schedule(work, delay, state);\r\n            };\r\n            return { instance: instance, now: now, schedule: schedule };\r\n        });\r\n    };\r\n    DeprecatedContext.prototype.cold = function (marbles, values, error) {\r\n        var scheduler = this.scheduler;\r\n        this.reframable_ = false;\r\n        var observable = scheduler.createColdObservable(marbles, values, error);\r\n        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };\r\n        return observable;\r\n    };\r\n    DeprecatedContext.prototype.configure = function (configuration) {\r\n        if (this.scheduler_) {\r\n            throw new Error(\"Scheduler already created; call configure before using other context methods and properties.\");\r\n        }\r\n        this.configuration_ = __assign(__assign({}, this.configuration_), configuration);\r\n    };\r\n    DeprecatedContext.prototype.equal = function (actual) {\r\n        var args = [];\r\n        for (var _i = 1; _i < arguments.length; _i++) {\r\n            args[_i - 1] = arguments[_i];\r\n        }\r\n        var scheduler = this.scheduler;\r\n        var a0 = args[0], a1 = args[1], a2 = args[2], a3 = args[3];\r\n        if (a1 && typeof a1 === \"string\") {\r\n            scheduler.expectObservable(actual, a0).toBe(a1, a2, a3);\r\n        }\r\n        else if (a1 && a1[args_1.argsSymbol]) {\r\n            assert_1.assertArgs(a1);\r\n            var _a = a1[args_1.argsSymbol], error = _a.error, marbles = _a.marbles, values = _a.values;\r\n            scheduler.expectObservable(actual, a0).toBe(marbles, values, error);\r\n        }\r\n        else if (typeof a0 === \"string\") {\r\n            scheduler.expectObservable(actual).toBe(a0, a1, a2);\r\n        }\r\n        else {\r\n            assert_1.assertArgs(a0);\r\n            var _b = a0[args_1.argsSymbol], error = _b.error, marbles = _b.marbles, values = _b.values;\r\n            scheduler.expectObservable(actual).toBe(marbles, values, error);\r\n        }\r\n    };\r\n    DeprecatedContext.prototype.expect = function (actual, subscription) {\r\n        var scheduler = this.scheduler;\r\n        return new expect_1.Expect(actual, scheduler, subscription);\r\n    };\r\n    DeprecatedContext.prototype.flush = function () {\r\n        var scheduler = this.scheduler;\r\n        this.reframable_ = false;\r\n        scheduler.flush();\r\n    };\r\n    DeprecatedContext.prototype.has = function (actual, expected) {\r\n        assert_1.assertSubscriptions(actual);\r\n        var scheduler = this.scheduler;\r\n        scheduler.expectSubscriptions(actual.subscriptions).toBe(expected);\r\n    };\r\n    DeprecatedContext.prototype.hot = function (marbles, values, error) {\r\n        var scheduler = this.scheduler;\r\n        this.reframable_ = false;\r\n        var observable = scheduler.createHotObservable(marbles, values, error);\r\n        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };\r\n        return observable;\r\n    };\r\n    DeprecatedContext.prototype.reframe = function (timePerFrame, maxTime) {\r\n        if (!this.reframable_) {\r\n            throw new Error(\"Cannot reframe; scheduler already used.\");\r\n        }\r\n        if (maxTime === undefined) {\r\n            maxTime = timePerFrame * 75;\r\n        }\r\n        this.frameTimeFactor_ =\r\n            rxjs_1.VirtualTimeScheduler.frameTimeFactor ||\r\n                testing_1.TestScheduler.frameTimeFactor;\r\n        rxjs_1.VirtualTimeScheduler.frameTimeFactor = timePerFrame;\r\n        testing_1.TestScheduler.frameTimeFactor = timePerFrame;\r\n        var scheduler = this.scheduler;\r\n        scheduler.maxFrames = maxTime;\r\n    };\r\n    DeprecatedContext.prototype.teardown = function () {\r\n        try {\r\n            if (this.autoFlush) {\r\n                this.scheduler.flush();\r\n            }\r\n        }\r\n        finally {\r\n            this.bindings_.forEach(function (_a) {\r\n                var instance = _a.instance, now = _a.now, schedule = _a.schedule;\r\n                if (now) {\r\n                    instance.now = now;\r\n                }\r\n                else {\r\n                    delete instance.now;\r\n                }\r\n                if (schedule) {\r\n                    instance.schedule = schedule;\r\n                }\r\n                else {\r\n                    delete instance.schedule;\r\n                }\r\n            });\r\n            if (this.frameTimeFactor_) {\r\n                rxjs_1.VirtualTimeScheduler.frameTimeFactor = this.frameTimeFactor_;\r\n                testing_1.TestScheduler.frameTimeFactor = this.frameTimeFactor_;\r\n            }\r\n        }\r\n    };\r\n    DeprecatedContext.prototype.time = function (marbles) {\r\n        var scheduler = this.scheduler;\r\n        this.reframable_ = false;\r\n        return scheduler.createTime(marbles);\r\n    };\r\n    return DeprecatedContext;\r\n}());\r\nexports.DeprecatedContext = DeprecatedContext;\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/context-deprecated.ts?");

/***/ }),

/***/ "./source/context-run.ts":
/*!*******************************!*\
  !*** ./source/context-run.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.RunContext = void 0;\r\nvar testing_1 = __webpack_require__(/*! rxjs/testing */ \"rxjs/testing\");\r\nvar args_1 = __webpack_require__(/*! ./args */ \"./source/args.ts\");\r\nvar assert_1 = __webpack_require__(/*! ./assert */ \"./source/assert.ts\");\r\nvar expect_1 = __webpack_require__(/*! ./expect */ \"./source/expect.ts\");\r\nvar RunContext = (function () {\r\n    function RunContext(scheduler, helpers_) {\r\n        this.scheduler = scheduler;\r\n        this.helpers_ = helpers_;\r\n    }\r\n    Object.defineProperty(RunContext.prototype, \"autoFlush\", {\r\n        get: function () {\r\n            throw notSupported(\"autoFlush\");\r\n        },\r\n        set: function (value) {\r\n            throw notSupported(\"autoFlush\");\r\n        },\r\n        enumerable: false,\r\n        configurable: true\r\n    });\r\n    RunContext.prototype.bind = function () {\r\n        var schedulers = [];\r\n        for (var _i = 0; _i < arguments.length; _i++) {\r\n            schedulers[_i] = arguments[_i];\r\n        }\r\n        throw notSupported(\"bind\");\r\n    };\r\n    RunContext.prototype.cold = function (marbles, values, error) {\r\n        var helpers_ = this.helpers_;\r\n        var observable = helpers_.cold(marbles, values, error);\r\n        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };\r\n        return observable;\r\n    };\r\n    RunContext.prototype.configure = function (configuration) {\r\n        throw notSupported(\"configure\");\r\n    };\r\n    RunContext.prototype.equal = function (actual) {\r\n        var args = [];\r\n        for (var _i = 1; _i < arguments.length; _i++) {\r\n            args[_i - 1] = arguments[_i];\r\n        }\r\n        var helpers_ = this.helpers_;\r\n        var a0 = args[0], a1 = args[1], a2 = args[2], a3 = args[3];\r\n        if (a1 && typeof a1 === \"string\") {\r\n            helpers_.expectObservable(actual, a0).toBe(a1, a2, a3);\r\n        }\r\n        else if (a1 && a1[args_1.argsSymbol]) {\r\n            assert_1.assertArgs(a1);\r\n            var _a = a1[args_1.argsSymbol], error = _a.error, marbles = _a.marbles, values = _a.values;\r\n            helpers_.expectObservable(actual, a0).toBe(marbles, values, error);\r\n        }\r\n        else if (typeof a0 === \"string\") {\r\n            helpers_.expectObservable(actual).toBe(a0, a1, a2);\r\n        }\r\n        else {\r\n            assert_1.assertArgs(a0);\r\n            var _b = a0[args_1.argsSymbol], error = _b.error, marbles = _b.marbles, values = _b.values;\r\n            helpers_.expectObservable(actual).toBe(marbles, values, error);\r\n        }\r\n    };\r\n    RunContext.prototype.expect = function (actual, subscription) {\r\n        var helpers_ = this.helpers_;\r\n        return new expect_1.Expect(actual, helpers_, subscription);\r\n    };\r\n    RunContext.prototype.flush = function () {\r\n        this.helpers_.flush();\r\n    };\r\n    RunContext.prototype.has = function (actual, expected) {\r\n        assert_1.assertSubscriptions(actual);\r\n        var helpers_ = this.helpers_;\r\n        helpers_.expectSubscriptions(actual.subscriptions).toBe(expected);\r\n    };\r\n    RunContext.prototype.hot = function (marbles, values, error) {\r\n        var helpers_ = this.helpers_;\r\n        var observable = helpers_.hot(marbles, values, error);\r\n        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };\r\n        return observable;\r\n    };\r\n    RunContext.prototype.reframe = function (timePerFrame, maxTime) {\r\n        throw notSupported(\"reframe\");\r\n    };\r\n    RunContext.prototype.teardown = function () {\r\n        throw notSupported(\"teardown\");\r\n    };\r\n    RunContext.prototype.time = function (marbles) {\r\n        var messages = testing_1.TestScheduler.parseMarbles(marbles, undefined, undefined, undefined, true);\r\n        var complete = messages.find(function (_a) {\r\n            var notification = _a.notification;\r\n            return notification.kind === \"C\";\r\n        });\r\n        if (complete) {\r\n            return complete.frame;\r\n        }\r\n        return this.scheduler.createTime(marbles);\r\n    };\r\n    return RunContext;\r\n}());\r\nexports.RunContext = RunContext;\r\nfunction notSupported(name) {\r\n    return new Error(name + \" is not supported when using the latest TestScheduler. For the deprecated behaviour, use 'const { marbles } = configure({ run: false })'.\");\r\n}\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/context-run.ts?");

/***/ }),

/***/ "./source/context.ts":
/*!***************************!*\
  !*** ./source/context.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/context.ts?");

/***/ }),

/***/ "./source/expect.ts":
/*!**************************!*\
  !*** ./source/expect.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.Expect = void 0;\r\nvar args_1 = __webpack_require__(/*! ./args */ \"./source/args.ts\");\r\nvar assert_1 = __webpack_require__(/*! ./assert */ \"./source/assert.ts\");\r\nvar Expect = (function () {\r\n    function Expect(actual, helpers, subscription) {\r\n        this.actual = actual;\r\n        this.helpers = helpers;\r\n        this.subscription = subscription;\r\n    }\r\n    Expect.prototype.toBeObservable = function (expected, values, error) {\r\n        var _a = this, actual = _a.actual, helpers = _a.helpers, subscription = _a.subscription;\r\n        if (typeof expected === \"string\") {\r\n            helpers\r\n                .expectObservable(actual, subscription)\r\n                .toBe(expected, values, error);\r\n        }\r\n        else {\r\n            assert_1.assertArgs(expected);\r\n            var _b = expected[args_1.argsSymbol], error_1 = _b.error, marbles = _b.marbles, values_1 = _b.values;\r\n            helpers\r\n                .expectObservable(actual, subscription)\r\n                .toBe(marbles, values_1, error_1);\r\n        }\r\n    };\r\n    Expect.prototype.toHaveSubscriptions = function (expected) {\r\n        var _a = this, actual = _a.actual, helpers = _a.helpers;\r\n        assert_1.assertSubscriptions(actual);\r\n        var subscriptions = actual.subscriptions;\r\n        helpers.expectSubscriptions(subscriptions).toBe(expected);\r\n    };\r\n    return Expect;\r\n}());\r\nexports.Expect = Expect;\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/expect.ts?");

/***/ }),

/***/ "./source/index.ts":
/*!*************************!*\
  !*** ./source/index.ts ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nvar __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {\r\n    if (k2 === undefined) k2 = k;\r\n    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });\r\n}) : (function(o, m, k, k2) {\r\n    if (k2 === undefined) k2 = k;\r\n    o[k2] = m[k];\r\n}));\r\nvar __exportStar = (this && this.__exportStar) || function(m, exports) {\r\n    for (var p in m) if (p !== \"default\" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);\r\n};\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\n__exportStar(__webpack_require__(/*! ./configuration */ \"./source/configuration.ts\"), exports);\r\n__exportStar(__webpack_require__(/*! ./context */ \"./source/context.ts\"), exports);\r\n__exportStar(__webpack_require__(/*! ./expect */ \"./source/expect.ts\"), exports);\r\n__exportStar(__webpack_require__(/*! ./marbles */ \"./source/marbles.ts\"), exports);\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/index.ts?");

/***/ }),

/***/ "./source/marbles.ts":
/*!***************************!*\
  !*** ./source/marbles.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nvar __assign = (this && this.__assign) || function () {\r\n    __assign = Object.assign || function(t) {\r\n        for (var s, i = 1, n = arguments.length; i < n; i++) {\r\n            s = arguments[i];\r\n            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))\r\n                t[p] = s[p];\r\n        }\r\n        return t;\r\n    };\r\n    return __assign.apply(this, arguments);\r\n};\r\nvar __spreadArray = (this && this.__spreadArray) || function (to, from) {\r\n    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)\r\n        to[j] = from[i];\r\n    return to;\r\n};\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.marbles = exports.configure = void 0;\r\nvar testing_1 = __webpack_require__(/*! rxjs/testing */ \"rxjs/testing\");\r\nvar configuration_1 = __webpack_require__(/*! ./configuration */ \"./source/configuration.ts\");\r\nvar context_deprecated_1 = __webpack_require__(/*! ./context-deprecated */ \"./source/context-deprecated.ts\");\r\nvar context_run_1 = __webpack_require__(/*! ./context-run */ \"./source/context-run.ts\");\r\nvar matcher_1 = __webpack_require__(/*! ./matcher */ \"./source/matcher.ts\");\r\nfunction configure(configurationOrFactory) {\r\n    function deriveConfiguration() {\r\n        var args = [];\r\n        for (var _i = 0; _i < arguments.length; _i++) {\r\n            args[_i] = arguments[_i];\r\n        }\r\n        var explicit = typeof configurationOrFactory === \"function\"\r\n            ? configurationOrFactory.apply(void 0, args) : configurationOrFactory;\r\n        return __assign(__assign({}, configuration_1.defaults()), explicit);\r\n    }\r\n    function _marbles(func) {\r\n        var wrapper = function () {\r\n            var _this = this;\r\n            var rest = [];\r\n            for (var _i = 0; _i < arguments.length; _i++) {\r\n                rest[_i] = arguments[_i];\r\n            }\r\n            var configuration = deriveConfiguration.apply(void 0, rest);\r\n            if (configuration.run) {\r\n                var scheduler_1 = new testing_1.TestScheduler(function (actual, expected) {\r\n                    return matcher_1.observableMatcher(actual, expected, configuration.assert, configuration.assertDeepEqual, configuration.frameworkMatcher);\r\n                });\r\n                return scheduler_1.run(function (helpers) {\r\n                    return func.call.apply(func, __spreadArray([_this, new context_run_1.RunContext(scheduler_1, helpers)], rest));\r\n                });\r\n            }\r\n            var context = new context_deprecated_1.DeprecatedContext(configuration);\r\n            try {\r\n                return func.call.apply(func, __spreadArray([this, context], rest));\r\n            }\r\n            finally {\r\n                context.teardown();\r\n            }\r\n        };\r\n        if (func.length > 1) {\r\n            return function (first) {\r\n                var rest = [];\r\n                for (var _i = 1; _i < arguments.length; _i++) {\r\n                    rest[_i - 1] = arguments[_i];\r\n                }\r\n                return wrapper.apply(void 0, __spreadArray([first], rest));\r\n            };\r\n        }\r\n        return wrapper;\r\n    }\r\n    return { marbles: _marbles };\r\n}\r\nexports.configure = configure;\r\nexports.marbles = configure(configuration_1.defaults()).marbles;\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/marbles.ts?");

/***/ }),

/***/ "./source/matcher.ts":
/*!***************************!*\
  !*** ./source/matcher.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\r\nObject.defineProperty(exports, \"__esModule\", { value: true });\r\nexports.observableMatcher = void 0;\r\nvar fast_equals_1 = __webpack_require__(/*! fast-equals */ \"./node_modules/fast-equals/dist/fast-equals.js\");\r\nfunction stringify(x) {\r\n    if (x === undefined) {\r\n        return \"undefined\";\r\n    }\r\n    return JSON.stringify(x, function (key, value) {\r\n        if (Array.isArray(value)) {\r\n            return (\"[\" +\r\n                value.map(function (i) {\r\n                    return \"\\n\\t\" + stringify(i);\r\n                }) +\r\n                \"\\n]\");\r\n        }\r\n        return value;\r\n    })\r\n        .replace(/\\\\\"/g, '\"')\r\n        .replace(/\\\\t/g, \"\\t\")\r\n        .replace(/\\\\n/g, \"\\n\");\r\n}\r\nfunction deleteErrorNotificationStack(marble) {\r\n    var notification = marble.notification;\r\n    if (notification) {\r\n        var kind = notification.kind, error = notification.error;\r\n        if (kind === \"E\" && error instanceof Error) {\r\n            notification.error = { name: error.name, message: error.message };\r\n        }\r\n    }\r\n    return marble;\r\n}\r\nfunction observableMatcher(actual, expected, assert, assertDeepEqual, frameworkMatcher) {\r\n    if (Array.isArray(actual) && Array.isArray(expected)) {\r\n        actual = actual.map(deleteErrorNotificationStack);\r\n        expected = expected.map(deleteErrorNotificationStack);\r\n        if (frameworkMatcher) {\r\n            assertDeepEqual(actual, expected);\r\n        }\r\n        else {\r\n            var passed = fast_equals_1.circularDeepEqual(actual, expected);\r\n            if (passed) {\r\n                assert(true, \"\");\r\n                return;\r\n            }\r\n            var message_1 = \"\\nExpected \\n\";\r\n            actual.forEach(function (x) { return (message_1 += \"\\t\" + stringify(x) + \"\\n\"); });\r\n            message_1 += \"\\t\\nto deep equal \\n\";\r\n            expected.forEach(function (x) { return (message_1 += \"\\t\" + stringify(x) + \"\\n\"); });\r\n            assert(passed, message_1);\r\n        }\r\n    }\r\n    else {\r\n        assertDeepEqual(actual, expected);\r\n    }\r\n}\r\nexports.observableMatcher = observableMatcher;\r\n\n\n//# sourceURL=webpack://rxjsMarbles/./source/matcher.ts?");

/***/ }),

/***/ "rxjs":
/*!************************************************************************************!*\
  !*** external {"root":["rxjs"],"commonjs":"rxjs","commonjs2":"rxjs","amd":"rxjs"} ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = __WEBPACK_EXTERNAL_MODULE_rxjs__;\n\n//# sourceURL=webpack://rxjsMarbles/external_%7B%22root%22:%5B%22rxjs%22%5D,%22commonjs%22:%22rxjs%22,%22commonjs2%22:%22rxjs%22,%22amd%22:%22rxjs%22%7D?");

/***/ }),

/***/ "rxjs/testing":
/*!**********************************************************************************************************************!*\
  !*** external {"root":["rxjs","testing"],"commonjs":"rxjs/testing","commonjs2":"rxjs/testing","amd":"rxjs/testing"} ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = __WEBPACK_EXTERNAL_MODULE_rxjs_testing__;\n\n//# sourceURL=webpack://rxjsMarbles/external_%7B%22root%22:%5B%22rxjs%22,%22testing%22%5D,%22commonjs%22:%22rxjs/testing%22,%22commonjs2%22:%22rxjs/testing%22,%22amd%22:%22rxjs/testing%22%7D?");

/***/ })

/******/ });
});