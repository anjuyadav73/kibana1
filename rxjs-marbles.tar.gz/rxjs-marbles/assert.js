"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertSubscriptions = exports.assertArgs = void 0;
var args_1 = require("./args");
function assertArgs(observable) {
    if (!observable[args_1.argsSymbol]) {
        throw new Error("Expected a hot or cold test observable.");
    }
}
exports.assertArgs = assertArgs;
function assertSubscriptions(observable) {
    if (!observable["subscriptions"]) {
        throw new Error("Expected a hot or cold test observable with subscriptions.");
    }
}
exports.assertSubscriptions = assertSubscriptions;
