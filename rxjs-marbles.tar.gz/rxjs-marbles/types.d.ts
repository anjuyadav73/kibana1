import { Observable } from "rxjs";
import { TestScheduler } from "rxjs/testing";
export interface ExpectHelpers {
    expectObservable: typeof TestScheduler.prototype.expectObservable;
    expectSubscriptions: typeof TestScheduler.prototype.expectSubscriptions;
}
export interface RunHelpers {
    cold: typeof TestScheduler.prototype.createColdObservable;
    expectObservable: typeof TestScheduler.prototype.expectObservable;
    expectSubscriptions: typeof TestScheduler.prototype.expectSubscriptions;
    flush: typeof TestScheduler.prototype.flush;
    hot: typeof TestScheduler.prototype.createHotObservable;
}
export declare type TestObservableLike<T> = Observable<T> & {
    subscriptions: any[];
};
