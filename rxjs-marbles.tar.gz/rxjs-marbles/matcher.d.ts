export declare function observableMatcher(actual: any, expected: any, assert: any, assertDeepEqual: any, frameworkMatcher: any): any;
