import { asapScheduler, asyncScheduler } from "rxjs";
export function fakeSchedulers(fakeTest, now) {
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var hasOwnSchedule = asapScheduler.hasOwnProperty("schedule");
        if (hasOwnSchedule) {
            console.warn("asapScheduler.schedule appears to have been patched outside of fakeSchedulers.");
        }
        var origSchedule = asapScheduler.schedule;
        var origNow = asyncScheduler.now;
        try {
            asapScheduler.schedule = asyncScheduler.schedule.bind(asyncScheduler);
            asyncScheduler.now = now || (function () { return Date.now(); });
            return fakeTest.apply(void 0, args);
        }
        finally {
            if (hasOwnSchedule) {
                asapScheduler.schedule = origSchedule;
            }
            else {
                delete asapScheduler.schedule;
            }
            asyncScheduler.now = origNow;
        }
    };
}
