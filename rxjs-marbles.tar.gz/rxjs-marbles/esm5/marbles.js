var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
import { TestScheduler } from "rxjs/testing";
import { defaults } from "./configuration";
import { DeprecatedContext } from "./context-deprecated";
import { RunContext } from "./context-run";
import { observableMatcher } from "./matcher";
export function configure(configurationOrFactory) {
    function deriveConfiguration() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var explicit = typeof configurationOrFactory === "function"
            ? configurationOrFactory.apply(void 0, args) : configurationOrFactory;
        return __assign(__assign({}, defaults()), explicit);
    }
    function _marbles(func) {
        var wrapper = function () {
            var _this = this;
            var rest = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                rest[_i] = arguments[_i];
            }
            var configuration = deriveConfiguration.apply(void 0, rest);
            if (configuration.run) {
                var scheduler_1 = new TestScheduler(function (actual, expected) {
                    return observableMatcher(actual, expected, configuration.assert, configuration.assertDeepEqual, configuration.frameworkMatcher);
                });
                return scheduler_1.run(function (helpers) {
                    return func.call.apply(func, __spreadArray([_this, new RunContext(scheduler_1, helpers)], rest));
                });
            }
            var context = new DeprecatedContext(configuration);
            try {
                return func.call.apply(func, __spreadArray([this, context], rest));
            }
            finally {
                context.teardown();
            }
        };
        if (func.length > 1) {
            return function (first) {
                var rest = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    rest[_i - 1] = arguments[_i];
                }
                return wrapper.apply(void 0, __spreadArray([first], rest));
            };
        }
        return wrapper;
    }
    return { marbles: _marbles };
}
export var marbles = configure(defaults()).marbles;
