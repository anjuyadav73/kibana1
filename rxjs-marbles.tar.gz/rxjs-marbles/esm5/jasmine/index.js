var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export * from "./observe";
export function configure(configuration) {
    var defaultAssert = defaults().assert;
    var marbles = _configure(__assign(__assign(__assign({}, defaults()), { assert: function (a, m) {
            var expectation = expect(a);
            if (expectation.withContext) {
                expect(a).withContext(m).toBeTruthy();
            }
            else {
                defaultAssert(a, m);
            }
        }, assertDeepEqual: function (a, e) { return expect(a).toEqual(e); } }), configuration)).marbles;
    function cases(name, func, cases) {
        describe(name, function () {
            _cases(function (c) {
                var t = c.only ? fit : c.skip ? xit : it;
                if (func.length > 2) {
                    t(c.name, marbles(function (m, second) {
                        var rest = [];
                        for (var _i = 2; _i < arguments.length; _i++) {
                            rest[_i - 2] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c, second], rest));
                    }));
                }
                else {
                    t(c.name, marbles(function (m) {
                        var rest = [];
                        for (var _i = 1; _i < arguments.length; _i++) {
                            rest[_i - 1] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c], rest));
                    }));
                }
            }, cases);
        });
    }
    return { cases: cases, marbles: marbles };
}
var _a = configure({}), cases = _a.cases, marbles = _a.marbles;
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
