import { fakeAsync, tick } from "@angular/core/testing";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
export function fakeSchedulers(fakeTest) {
    return fakeAsync(_fakeSchedulers(function () {
        return fakeTest(function (milliseconds) {
            console.log("The tick parameter passed to the fakeSchedulers test is deprecated; call the @angular/core/testing tick function instead. See the examples for the intended usage.");
            tick(milliseconds);
        });
    }));
}
