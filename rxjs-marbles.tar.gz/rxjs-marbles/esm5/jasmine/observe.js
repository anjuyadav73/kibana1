import { DoneSubscriber } from "../done-subscriber";
export function observe(observableTest) {
    return function (done) {
        var subscriber = new DoneSubscriber(done.fail, done);
        observableTest().subscribe(subscriber);
    };
}
