import { TestScheduler } from "rxjs/testing";
import { argsSymbol } from "./args";
import { assertArgs, assertSubscriptions } from "./assert";
import { Expect } from "./expect";
var RunContext = (function () {
    function RunContext(scheduler, helpers_) {
        this.scheduler = scheduler;
        this.helpers_ = helpers_;
    }
    Object.defineProperty(RunContext.prototype, "autoFlush", {
        get: function () {
            throw notSupported("autoFlush");
        },
        set: function (value) {
            throw notSupported("autoFlush");
        },
        enumerable: false,
        configurable: true
    });
    RunContext.prototype.bind = function () {
        var schedulers = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            schedulers[_i] = arguments[_i];
        }
        throw notSupported("bind");
    };
    RunContext.prototype.cold = function (marbles, values, error) {
        var helpers_ = this.helpers_;
        var observable = helpers_.cold(marbles, values, error);
        observable[argsSymbol] = { error: error, marbles: marbles, values: values };
        return observable;
    };
    RunContext.prototype.configure = function (configuration) {
        throw notSupported("configure");
    };
    RunContext.prototype.equal = function (actual) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var helpers_ = this.helpers_;
        var a0 = args[0], a1 = args[1], a2 = args[2], a3 = args[3];
        if (a1 && typeof a1 === "string") {
            helpers_.expectObservable(actual, a0).toBe(a1, a2, a3);
        }
        else if (a1 && a1[argsSymbol]) {
            assertArgs(a1);
            var _a = a1[argsSymbol], error = _a.error, marbles = _a.marbles, values = _a.values;
            helpers_.expectObservable(actual, a0).toBe(marbles, values, error);
        }
        else if (typeof a0 === "string") {
            helpers_.expectObservable(actual).toBe(a0, a1, a2);
        }
        else {
            assertArgs(a0);
            var _b = a0[argsSymbol], error = _b.error, marbles = _b.marbles, values = _b.values;
            helpers_.expectObservable(actual).toBe(marbles, values, error);
        }
    };
    RunContext.prototype.expect = function (actual, subscription) {
        var helpers_ = this.helpers_;
        return new Expect(actual, helpers_, subscription);
    };
    RunContext.prototype.flush = function () {
        this.helpers_.flush();
    };
    RunContext.prototype.has = function (actual, expected) {
        assertSubscriptions(actual);
        var helpers_ = this.helpers_;
        helpers_.expectSubscriptions(actual.subscriptions).toBe(expected);
    };
    RunContext.prototype.hot = function (marbles, values, error) {
        var helpers_ = this.helpers_;
        var observable = helpers_.hot(marbles, values, error);
        observable[argsSymbol] = { error: error, marbles: marbles, values: values };
        return observable;
    };
    RunContext.prototype.reframe = function (timePerFrame, maxTime) {
        throw notSupported("reframe");
    };
    RunContext.prototype.teardown = function () {
        throw notSupported("teardown");
    };
    RunContext.prototype.time = function (marbles) {
        var messages = TestScheduler.parseMarbles(marbles, undefined, undefined, undefined, true);
        var complete = messages.find(function (_a) {
            var notification = _a.notification;
            return notification.kind === "C";
        });
        if (complete) {
            return complete.frame;
        }
        return this.scheduler.createTime(marbles);
    };
    return RunContext;
}());
export { RunContext };
function notSupported(name) {
    return new Error(name + " is not supported when using the latest TestScheduler. For the deprecated behaviour, use 'const { marbles } = configure({ run: false })'.");
}
