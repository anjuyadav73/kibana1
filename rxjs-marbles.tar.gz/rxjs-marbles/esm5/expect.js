import { argsSymbol } from "./args";
import { assertArgs, assertSubscriptions } from "./assert";
var Expect = (function () {
    function Expect(actual, helpers, subscription) {
        this.actual = actual;
        this.helpers = helpers;
        this.subscription = subscription;
    }
    Expect.prototype.toBeObservable = function (expected, values, error) {
        var _a = this, actual = _a.actual, helpers = _a.helpers, subscription = _a.subscription;
        if (typeof expected === "string") {
            helpers
                .expectObservable(actual, subscription)
                .toBe(expected, values, error);
        }
        else {
            assertArgs(expected);
            var _b = expected[argsSymbol], error_1 = _b.error, marbles = _b.marbles, values_1 = _b.values;
            helpers
                .expectObservable(actual, subscription)
                .toBe(marbles, values_1, error_1);
        }
    };
    Expect.prototype.toHaveSubscriptions = function (expected) {
        var _a = this, actual = _a.actual, helpers = _a.helpers;
        assertSubscriptions(actual);
        var subscriptions = actual.subscriptions;
        helpers.expectSubscriptions(subscriptions).toBe(expected);
    };
    return Expect;
}());
export { Expect };
