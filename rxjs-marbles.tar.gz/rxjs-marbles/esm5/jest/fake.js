import { fakeSchedulers as _fakeSchedulers } from "../fake";
export function fakeSchedulers(fakeTest) {
    var fakeTime = 0;
    return _fakeSchedulers(function () {
        return fakeTest(function (milliseconds) {
            fakeTime += milliseconds;
            jest.advanceTimersByTime(milliseconds);
        });
    }, function () { return fakeTime; });
}
