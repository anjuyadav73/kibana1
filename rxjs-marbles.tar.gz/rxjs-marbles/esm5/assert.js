import { argsSymbol } from "./args";
export function assertArgs(observable) {
    if (!observable[argsSymbol]) {
        throw new Error("Expected a hot or cold test observable.");
    }
}
export function assertSubscriptions(observable) {
    if (!observable["subscriptions"]) {
        throw new Error("Expected a hot or cold test observable with subscriptions.");
    }
}
