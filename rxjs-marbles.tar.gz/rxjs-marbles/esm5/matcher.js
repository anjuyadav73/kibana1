import { circularDeepEqual } from "fast-equals";
function stringify(x) {
    if (x === undefined) {
        return "undefined";
    }
    return JSON.stringify(x, function (key, value) {
        if (Array.isArray(value)) {
            return ("[" +
                value.map(function (i) {
                    return "\n\t" + stringify(i);
                }) +
                "\n]");
        }
        return value;
    })
        .replace(/\\"/g, '"')
        .replace(/\\t/g, "\t")
        .replace(/\\n/g, "\n");
}
function deleteErrorNotificationStack(marble) {
    var notification = marble.notification;
    if (notification) {
        var kind = notification.kind, error = notification.error;
        if (kind === "E" && error instanceof Error) {
            notification.error = { name: error.name, message: error.message };
        }
    }
    return marble;
}
export function observableMatcher(actual, expected, assert, assertDeepEqual, frameworkMatcher) {
    if (Array.isArray(actual) && Array.isArray(expected)) {
        actual = actual.map(deleteErrorNotificationStack);
        expected = expected.map(deleteErrorNotificationStack);
        if (frameworkMatcher) {
            assertDeepEqual(actual, expected);
        }
        else {
            var passed = circularDeepEqual(actual, expected);
            if (passed) {
                assert(true, "");
                return;
            }
            var message_1 = "\nExpected \n";
            actual.forEach(function (x) { return (message_1 += "\t" + stringify(x) + "\n"); });
            message_1 += "\t\nto deep equal \n";
            expected.forEach(function (x) { return (message_1 += "\t" + stringify(x) + "\n"); });
            assert(passed, message_1);
        }
    }
    else {
        assertDeepEqual(actual, expected);
    }
}
