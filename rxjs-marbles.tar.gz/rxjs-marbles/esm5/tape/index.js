var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as tape from "tape";
import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export function configure(configuration) {
    var factory = function (t) { return ({
        assert: t.ok.bind(t),
        assertDeepEqual: t.deepEqual.bind(t),
    }); };
    var configured = _configure(function (t) { return (__assign(__assign(__assign({}, defaults()), factory(t)), configuration)); });
    var marbles = configured.marbles;
    function cases(name, func, cases) {
        _cases(function (c) {
            var t = c.only ? tape.only : c.skip ? tape.skip : tape;
            t(name + " / " + c.name, marbles(function (m, t) { return func(m, c, t); }));
        }, cases);
    }
    return { cases: cases, marbles: marbles };
}
var _a = configure({}), cases = _a.cases, marbles = _a.marbles;
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
