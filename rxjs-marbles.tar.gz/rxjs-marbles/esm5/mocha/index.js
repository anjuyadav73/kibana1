var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "./observe";
export function configure(configuration) {
    var marbles = _configure(configuration).marbles;
    function cases(name, func, cases) {
        describe(name, function () {
            _cases(function (c) {
                var t = c.only ? it.only : c.skip ? it.skip : it;
                if (func.length > 2) {
                    t(c.name, marbles(function (m, second) {
                        var rest = [];
                        for (var _i = 2; _i < arguments.length; _i++) {
                            rest[_i - 2] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c, second], rest));
                    }));
                }
                else {
                    t(c.name, marbles(function (m) {
                        var rest = [];
                        for (var _i = 1; _i < arguments.length; _i++) {
                            rest[_i - 1] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c], rest));
                    }));
                }
            }, cases);
        });
    }
    return { cases: cases, marbles: marbles };
}
var _a = configure(defaults()), cases = _a.cases, marbles = _a.marbles;
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
