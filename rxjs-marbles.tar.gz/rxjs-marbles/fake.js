"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fakeSchedulers = void 0;
var rxjs_1 = require("rxjs");
function fakeSchedulers(fakeTest, now) {
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var hasOwnSchedule = rxjs_1.asapScheduler.hasOwnProperty("schedule");
        if (hasOwnSchedule) {
            console.warn("asapScheduler.schedule appears to have been patched outside of fakeSchedulers.");
        }
        var origSchedule = rxjs_1.asapScheduler.schedule;
        var origNow = rxjs_1.asyncScheduler.now;
        try {
            rxjs_1.asapScheduler.schedule = rxjs_1.asyncScheduler.schedule.bind(rxjs_1.asyncScheduler);
            rxjs_1.asyncScheduler.now = now || (function () { return Date.now(); });
            return fakeTest.apply(void 0, args);
        }
        finally {
            if (hasOwnSchedule) {
                rxjs_1.asapScheduler.schedule = origSchedule;
            }
            else {
                delete rxjs_1.asapScheduler.schedule;
            }
            rxjs_1.asyncScheduler.now = origNow;
        }
    };
}
exports.fakeSchedulers = fakeSchedulers;
