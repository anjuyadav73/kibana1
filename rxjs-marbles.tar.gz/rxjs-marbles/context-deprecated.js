"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeprecatedContext = void 0;
var rxjs_1 = require("rxjs");
var testing_1 = require("rxjs/testing");
var args_1 = require("./args");
var assert_1 = require("./assert");
var expect_1 = require("./expect");
var matcher_1 = require("./matcher");
var DeprecatedContext = (function () {
    function DeprecatedContext(configuration_) {
        this.configuration_ = configuration_;
        this.autoFlush = true;
        this.bindings_ = [];
        this.frameTimeFactor_ = undefined;
        this.reframable_ = true;
    }
    Object.defineProperty(DeprecatedContext.prototype, "scheduler", {
        get: function () {
            var _this = this;
            if (!this.scheduler_) {
                this.scheduler_ = new testing_1.TestScheduler(function (actual, expected) {
                    return matcher_1.observableMatcher(actual, expected, _this.configuration_.assert, _this.configuration_.assertDeepEqual, _this.configuration_.frameworkMatcher);
                });
            }
            return this.scheduler_;
        },
        enumerable: false,
        configurable: true
    });
    DeprecatedContext.prototype.bind = function () {
        var _this = this;
        var schedulers = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            schedulers[_i] = arguments[_i];
        }
        if (this.bindings_.length !== 0) {
            throw new Error("Schedulers already bound.");
        }
        if (schedulers.length === 0) {
            schedulers = [
                rxjs_1.animationFrameScheduler,
                rxjs_1.asapScheduler,
                rxjs_1.asyncScheduler,
                rxjs_1.queueScheduler,
            ];
        }
        this.bindings_ = schedulers.map(function (instance) {
            var now = instance.hasOwnProperty("now") ? instance.now : undefined;
            instance.now = function () { return _this.scheduler.now(); };
            var schedule = instance.hasOwnProperty("schedule")
                ? instance.schedule
                : undefined;
            instance.schedule = function (work, delay, state) {
                return _this.scheduler.schedule(work, delay, state);
            };
            return { instance: instance, now: now, schedule: schedule };
        });
    };
    DeprecatedContext.prototype.cold = function (marbles, values, error) {
        var scheduler = this.scheduler;
        this.reframable_ = false;
        var observable = scheduler.createColdObservable(marbles, values, error);
        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };
        return observable;
    };
    DeprecatedContext.prototype.configure = function (configuration) {
        if (this.scheduler_) {
            throw new Error("Scheduler already created; call configure before using other context methods and properties.");
        }
        this.configuration_ = __assign(__assign({}, this.configuration_), configuration);
    };
    DeprecatedContext.prototype.equal = function (actual) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var scheduler = this.scheduler;
        var a0 = args[0], a1 = args[1], a2 = args[2], a3 = args[3];
        if (a1 && typeof a1 === "string") {
            scheduler.expectObservable(actual, a0).toBe(a1, a2, a3);
        }
        else if (a1 && a1[args_1.argsSymbol]) {
            assert_1.assertArgs(a1);
            var _a = a1[args_1.argsSymbol], error = _a.error, marbles = _a.marbles, values = _a.values;
            scheduler.expectObservable(actual, a0).toBe(marbles, values, error);
        }
        else if (typeof a0 === "string") {
            scheduler.expectObservable(actual).toBe(a0, a1, a2);
        }
        else {
            assert_1.assertArgs(a0);
            var _b = a0[args_1.argsSymbol], error = _b.error, marbles = _b.marbles, values = _b.values;
            scheduler.expectObservable(actual).toBe(marbles, values, error);
        }
    };
    DeprecatedContext.prototype.expect = function (actual, subscription) {
        var scheduler = this.scheduler;
        return new expect_1.Expect(actual, scheduler, subscription);
    };
    DeprecatedContext.prototype.flush = function () {
        var scheduler = this.scheduler;
        this.reframable_ = false;
        scheduler.flush();
    };
    DeprecatedContext.prototype.has = function (actual, expected) {
        assert_1.assertSubscriptions(actual);
        var scheduler = this.scheduler;
        scheduler.expectSubscriptions(actual.subscriptions).toBe(expected);
    };
    DeprecatedContext.prototype.hot = function (marbles, values, error) {
        var scheduler = this.scheduler;
        this.reframable_ = false;
        var observable = scheduler.createHotObservable(marbles, values, error);
        observable[args_1.argsSymbol] = { error: error, marbles: marbles, values: values };
        return observable;
    };
    DeprecatedContext.prototype.reframe = function (timePerFrame, maxTime) {
        if (!this.reframable_) {
            throw new Error("Cannot reframe; scheduler already used.");
        }
        if (maxTime === undefined) {
            maxTime = timePerFrame * 75;
        }
        this.frameTimeFactor_ =
            rxjs_1.VirtualTimeScheduler.frameTimeFactor ||
                testing_1.TestScheduler.frameTimeFactor;
        rxjs_1.VirtualTimeScheduler.frameTimeFactor = timePerFrame;
        testing_1.TestScheduler.frameTimeFactor = timePerFrame;
        var scheduler = this.scheduler;
        scheduler.maxFrames = maxTime;
    };
    DeprecatedContext.prototype.teardown = function () {
        try {
            if (this.autoFlush) {
                this.scheduler.flush();
            }
        }
        finally {
            this.bindings_.forEach(function (_a) {
                var instance = _a.instance, now = _a.now, schedule = _a.schedule;
                if (now) {
                    instance.now = now;
                }
                else {
                    delete instance.now;
                }
                if (schedule) {
                    instance.schedule = schedule;
                }
                else {
                    delete instance.schedule;
                }
            });
            if (this.frameTimeFactor_) {
                rxjs_1.VirtualTimeScheduler.frameTimeFactor = this.frameTimeFactor_;
                testing_1.TestScheduler.frameTimeFactor = this.frameTimeFactor_;
            }
        }
    };
    DeprecatedContext.prototype.time = function (marbles) {
        var scheduler = this.scheduler;
        this.reframable_ = false;
        return scheduler.createTime(marbles);
    };
    return DeprecatedContext;
}());
exports.DeprecatedContext = DeprecatedContext;
