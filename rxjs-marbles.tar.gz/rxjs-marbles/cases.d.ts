export interface UnnamedCase {
    [key: string]: any;
    only?: boolean;
    skip?: boolean;
}
export interface NamedCase extends UnnamedCase {
    name: string;
}
export declare function _cases<T extends UnnamedCase>(adapter: (_case: NamedCase) => void, cases: {
    [key: string]: T;
}): void;
export declare function _cases<T extends NamedCase>(adapter: (_case: NamedCase) => void, cases: T[]): void;
