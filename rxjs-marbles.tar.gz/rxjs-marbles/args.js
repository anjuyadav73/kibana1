"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.argsSymbol = void 0;
exports.argsSymbol = Symbol("args");
