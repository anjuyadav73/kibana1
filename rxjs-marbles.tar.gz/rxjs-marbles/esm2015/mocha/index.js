import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "./observe";
export function configure(configuration) {
    const { marbles } = _configure(configuration);
    function cases(name, func, cases) {
        describe(name, () => {
            _cases((c) => {
                const t = c.only ? it.only : c.skip ? it.skip : it;
                if (func.length > 2) {
                    t(c.name, marbles((m, second, ...rest) => func(m, c, second, ...rest)));
                }
                else {
                    t(c.name, marbles((m, ...rest) => func(m, c, ...rest)));
                }
            }, cases);
        });
    }
    return { cases, marbles };
}
const { cases, marbles } = configure(defaults());
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
