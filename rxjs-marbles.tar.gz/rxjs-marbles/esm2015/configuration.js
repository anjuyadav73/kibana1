import { circularDeepEqual } from "fast-equals";
const defaultConfiguration = {
    assert: defaultAssert,
    assertDeepEqual: defaultAssertDeepEqual,
    frameworkMatcher: false,
    run: true,
};
export function defaults() {
    return Object.assign({}, defaultConfiguration);
}
function defaultAssert(value, message) {
    if (value) {
        return;
    }
    throw new Error(message);
}
function defaultAssertDeepEqual(a, b) {
    if (circularDeepEqual(a, b)) {
        return;
    }
    throw new Error(`Expected ${toString(a)} to equal ${toString(b)}.`);
}
function toString(value) {
    if (value === null) {
        return "null";
    }
    else if (value === undefined) {
        return "undefined";
    }
    return value.toString();
}
