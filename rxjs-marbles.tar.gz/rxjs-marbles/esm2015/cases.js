const getPrototypeOf = Object.getPrototypeOf ||
    function (obj) {
        return obj.__proto__;
    };
export function _cases(adapter, cases) {
    if (getPrototypeOf(cases) !== Array.prototype) {
        cases = Object.keys(cases).map((key) => (Object.assign(Object.assign({}, cases[key]), { name: key })));
    }
    cases.forEach(adapter);
}
