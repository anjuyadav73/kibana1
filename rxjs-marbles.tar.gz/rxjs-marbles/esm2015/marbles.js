import { TestScheduler } from "rxjs/testing";
import { defaults } from "./configuration";
import { DeprecatedContext } from "./context-deprecated";
import { RunContext } from "./context-run";
import { observableMatcher } from "./matcher";
export function configure(configurationOrFactory) {
    function deriveConfiguration(...args) {
        const explicit = typeof configurationOrFactory === "function"
            ? configurationOrFactory(...args)
            : configurationOrFactory;
        return Object.assign(Object.assign({}, defaults()), explicit);
    }
    function _marbles(func) {
        const wrapper = function (...rest) {
            const configuration = deriveConfiguration(...rest);
            if (configuration.run) {
                const scheduler = new TestScheduler((actual, expected) => observableMatcher(actual, expected, configuration.assert, configuration.assertDeepEqual, configuration.frameworkMatcher));
                return scheduler.run((helpers) => func.call(this, new RunContext(scheduler, helpers), ...rest));
            }
            const context = new DeprecatedContext(configuration);
            try {
                return func.call(this, context, ...rest);
            }
            finally {
                context.teardown();
            }
        };
        if (func.length > 1) {
            return (first, ...rest) => wrapper(first, ...rest);
        }
        return wrapper;
    }
    return { marbles: _marbles };
}
export const { marbles } = configure(defaults());
