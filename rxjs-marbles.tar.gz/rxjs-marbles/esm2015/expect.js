import { argsSymbol } from "./args";
import { assertArgs, assertSubscriptions } from "./assert";
export class Expect {
    constructor(actual, helpers, subscription) {
        this.actual = actual;
        this.helpers = helpers;
        this.subscription = subscription;
    }
    toBeObservable(expected, values, error) {
        const { actual, helpers, subscription } = this;
        if (typeof expected === "string") {
            helpers
                .expectObservable(actual, subscription)
                .toBe(expected, values, error);
        }
        else {
            assertArgs(expected);
            const { error, marbles, values } = expected[argsSymbol];
            helpers
                .expectObservable(actual, subscription)
                .toBe(marbles, values, error);
        }
    }
    toHaveSubscriptions(expected) {
        const { actual, helpers } = this;
        assertSubscriptions(actual);
        const { subscriptions } = actual;
        helpers.expectSubscriptions(subscriptions).toBe(expected);
    }
}
