import { animationFrameScheduler, asapScheduler, asyncScheduler, queueScheduler, VirtualTimeScheduler, } from "rxjs";
import { TestScheduler } from "rxjs/testing";
import { argsSymbol } from "./args";
import { assertArgs, assertSubscriptions } from "./assert";
import { Expect } from "./expect";
import { observableMatcher } from "./matcher";
export class DeprecatedContext {
    constructor(configuration_) {
        this.configuration_ = configuration_;
        this.autoFlush = true;
        this.bindings_ = [];
        this.frameTimeFactor_ = undefined;
        this.reframable_ = true;
    }
    get scheduler() {
        if (!this.scheduler_) {
            this.scheduler_ = new TestScheduler((actual, expected) => observableMatcher(actual, expected, this.configuration_.assert, this.configuration_.assertDeepEqual, this.configuration_.frameworkMatcher));
        }
        return this.scheduler_;
    }
    bind(...schedulers) {
        if (this.bindings_.length !== 0) {
            throw new Error("Schedulers already bound.");
        }
        if (schedulers.length === 0) {
            schedulers = [
                animationFrameScheduler,
                asapScheduler,
                asyncScheduler,
                queueScheduler,
            ];
        }
        this.bindings_ = schedulers.map((instance) => {
            const now = instance.hasOwnProperty("now") ? instance.now : undefined;
            instance.now = () => this.scheduler.now();
            const schedule = instance.hasOwnProperty("schedule")
                ? instance.schedule
                : undefined;
            instance.schedule = (work, delay, state) => this.scheduler.schedule(work, delay, state);
            return { instance, now, schedule };
        });
    }
    cold(marbles, values, error) {
        const { scheduler } = this;
        this.reframable_ = false;
        const observable = scheduler.createColdObservable(marbles, values, error);
        observable[argsSymbol] = { error, marbles, values };
        return observable;
    }
    configure(configuration) {
        if (this.scheduler_) {
            throw new Error("Scheduler already created; call configure before using other context methods and properties.");
        }
        this.configuration_ = Object.assign(Object.assign({}, this.configuration_), configuration);
    }
    equal(actual, ...args) {
        const { scheduler } = this;
        const [a0, a1, a2, a3] = args;
        if (a1 && typeof a1 === "string") {
            scheduler.expectObservable(actual, a0).toBe(a1, a2, a3);
        }
        else if (a1 && a1[argsSymbol]) {
            assertArgs(a1);
            const { error, marbles, values } = a1[argsSymbol];
            scheduler.expectObservable(actual, a0).toBe(marbles, values, error);
        }
        else if (typeof a0 === "string") {
            scheduler.expectObservable(actual).toBe(a0, a1, a2);
        }
        else {
            assertArgs(a0);
            const { error, marbles, values } = a0[argsSymbol];
            scheduler.expectObservable(actual).toBe(marbles, values, error);
        }
    }
    expect(actual, subscription) {
        const { scheduler } = this;
        return new Expect(actual, scheduler, subscription);
    }
    flush() {
        const { scheduler } = this;
        this.reframable_ = false;
        scheduler.flush();
    }
    has(actual, expected) {
        assertSubscriptions(actual);
        const { scheduler } = this;
        scheduler.expectSubscriptions(actual.subscriptions).toBe(expected);
    }
    hot(marbles, values, error) {
        const { scheduler } = this;
        this.reframable_ = false;
        const observable = scheduler.createHotObservable(marbles, values, error);
        observable[argsSymbol] = { error, marbles, values };
        return observable;
    }
    reframe(timePerFrame, maxTime) {
        if (!this.reframable_) {
            throw new Error("Cannot reframe; scheduler already used.");
        }
        if (maxTime === undefined) {
            maxTime = timePerFrame * 75;
        }
        this.frameTimeFactor_ =
            VirtualTimeScheduler.frameTimeFactor ||
                TestScheduler.frameTimeFactor;
        VirtualTimeScheduler.frameTimeFactor = timePerFrame;
        TestScheduler.frameTimeFactor = timePerFrame;
        const { scheduler } = this;
        scheduler.maxFrames = maxTime;
    }
    teardown() {
        try {
            if (this.autoFlush) {
                this.scheduler.flush();
            }
        }
        finally {
            this.bindings_.forEach(({ instance, now, schedule }) => {
                if (now) {
                    instance.now = now;
                }
                else {
                    delete instance.now;
                }
                if (schedule) {
                    instance.schedule = schedule;
                }
                else {
                    delete instance.schedule;
                }
            });
            if (this.frameTimeFactor_) {
                VirtualTimeScheduler.frameTimeFactor = this.frameTimeFactor_;
                TestScheduler.frameTimeFactor = this.frameTimeFactor_;
            }
        }
    }
    time(marbles) {
        const { scheduler } = this;
        this.reframable_ = false;
        return scheduler.createTime(marbles);
    }
}
