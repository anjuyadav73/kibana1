import { asapScheduler, asyncScheduler } from "rxjs";
export function fakeSchedulers(fakeTest, now) {
    return (...args) => {
        const hasOwnSchedule = asapScheduler.hasOwnProperty("schedule");
        if (hasOwnSchedule) {
            console.warn("asapScheduler.schedule appears to have been patched outside of fakeSchedulers.");
        }
        const origSchedule = asapScheduler.schedule;
        const origNow = asyncScheduler.now;
        try {
            asapScheduler.schedule = asyncScheduler.schedule.bind(asyncScheduler);
            asyncScheduler.now = now || (() => Date.now());
            return fakeTest(...args);
        }
        finally {
            if (hasOwnSchedule) {
                asapScheduler.schedule = origSchedule;
            }
            else {
                delete asapScheduler.schedule;
            }
            asyncScheduler.now = origNow;
        }
    };
}
