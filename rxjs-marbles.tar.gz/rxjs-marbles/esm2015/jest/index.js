import { _cases } from "../cases";
import { defaults } from "../configuration";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "./fake";
export * from "./observe";
export function configure(configuration) {
    const { marbles } = _configure(Object.assign(Object.assign(Object.assign({}, defaults()), { assertDeepEqual: (a, e) => expect(a).toStrictEqual(e), frameworkMatcher: true }), configuration));
    function cases(name, func, cases) {
        describe(name, () => {
            _cases((c) => {
                const t = c.only ? test.only : c.skip ? test.skip : test;
                if (func.length > 2) {
                    t(c.name, marbles((m, second, ...rest) => func(m, c, second, ...rest)));
                }
                else {
                    t(c.name, marbles((m, ...rest) => func(m, c, ...rest)));
                }
            }, cases);
        });
    }
    return { cases, marbles };
}
const { cases, marbles } = configure({});
export { cases, marbles };
