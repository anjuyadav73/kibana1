import { fakeSchedulers as _fakeSchedulers } from "../fake";
export function fakeSchedulers(fakeTest) {
    let fakeTime = 0;
    return _fakeSchedulers(() => fakeTest((milliseconds) => {
        fakeTime += milliseconds;
        jest.advanceTimersByTime(milliseconds);
    }), () => fakeTime);
}
