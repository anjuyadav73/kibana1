import { DoneSubscriber } from "../done-subscriber";
export function observe(observableTest) {
    return (done) => {
        const subscriber = new DoneSubscriber(done, done);
        observableTest().subscribe(subscriber);
    };
}
