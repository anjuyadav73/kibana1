import { TestScheduler } from "rxjs/testing";
import { argsSymbol } from "./args";
import { assertArgs, assertSubscriptions } from "./assert";
import { Expect } from "./expect";
export class RunContext {
    constructor(scheduler, helpers_) {
        this.scheduler = scheduler;
        this.helpers_ = helpers_;
    }
    get autoFlush() {
        throw notSupported("autoFlush");
    }
    set autoFlush(value) {
        throw notSupported("autoFlush");
    }
    bind(...schedulers) {
        throw notSupported("bind");
    }
    cold(marbles, values, error) {
        const { helpers_ } = this;
        const observable = helpers_.cold(marbles, values, error);
        observable[argsSymbol] = { error, marbles, values };
        return observable;
    }
    configure(configuration) {
        throw notSupported("configure");
    }
    equal(actual, ...args) {
        const { helpers_ } = this;
        const [a0, a1, a2, a3] = args;
        if (a1 && typeof a1 === "string") {
            helpers_.expectObservable(actual, a0).toBe(a1, a2, a3);
        }
        else if (a1 && a1[argsSymbol]) {
            assertArgs(a1);
            const { error, marbles, values } = a1[argsSymbol];
            helpers_.expectObservable(actual, a0).toBe(marbles, values, error);
        }
        else if (typeof a0 === "string") {
            helpers_.expectObservable(actual).toBe(a0, a1, a2);
        }
        else {
            assertArgs(a0);
            const { error, marbles, values } = a0[argsSymbol];
            helpers_.expectObservable(actual).toBe(marbles, values, error);
        }
    }
    expect(actual, subscription) {
        const { helpers_ } = this;
        return new Expect(actual, helpers_, subscription);
    }
    flush() {
        this.helpers_.flush();
    }
    has(actual, expected) {
        assertSubscriptions(actual);
        const { helpers_ } = this;
        helpers_.expectSubscriptions(actual.subscriptions).toBe(expected);
    }
    hot(marbles, values, error) {
        const { helpers_ } = this;
        const observable = helpers_.hot(marbles, values, error);
        observable[argsSymbol] = { error, marbles, values };
        return observable;
    }
    reframe(timePerFrame, maxTime) {
        throw notSupported("reframe");
    }
    teardown() {
        throw notSupported("teardown");
    }
    time(marbles) {
        const messages = TestScheduler.parseMarbles(marbles, undefined, undefined, undefined, true);
        const complete = messages.find(({ notification }) => notification.kind === "C");
        if (complete) {
            return complete.frame;
        }
        return this.scheduler.createTime(marbles);
    }
}
function notSupported(name) {
    return new Error(`${name} is not supported when using the latest TestScheduler. For the deprecated behaviour, use 'const { marbles } = configure({ run: false })'.`);
}
