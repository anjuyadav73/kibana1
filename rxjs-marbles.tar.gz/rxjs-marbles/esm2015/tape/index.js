import * as tape from "tape";
import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export function configure(configuration) {
    const factory = (t) => ({
        assert: t.ok.bind(t),
        assertDeepEqual: t.deepEqual.bind(t),
    });
    const configured = _configure((t) => (Object.assign(Object.assign(Object.assign({}, defaults()), factory(t)), configuration)));
    const marbles = configured.marbles;
    function cases(name, func, cases) {
        _cases((c) => {
            const t = c.only ? tape.only : c.skip ? tape.skip : tape;
            t(`${name} / ${c.name}`, marbles((m, t) => func(m, c, t)));
        }, cases);
    }
    return { cases, marbles };
}
const { cases, marbles } = configure({});
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
