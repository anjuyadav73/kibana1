import { noop, Subscriber } from "rxjs";
export class DoneSubscriber extends Subscriber {
    constructor(onError, onComplete) {
        super({
            complete: onComplete,
            error: onError,
            next: noop,
        });
        this.onError = onError;
    }
    unsubscribe() {
        try {
            super.unsubscribe();
        }
        catch (error) {
            this.onError(error);
        }
    }
}
