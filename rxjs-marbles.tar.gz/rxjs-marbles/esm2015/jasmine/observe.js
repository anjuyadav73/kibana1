import { DoneSubscriber } from "../done-subscriber";
export function observe(observableTest) {
    return (done) => {
        const subscriber = new DoneSubscriber(done.fail, done);
        observableTest().subscribe(subscriber);
    };
}
