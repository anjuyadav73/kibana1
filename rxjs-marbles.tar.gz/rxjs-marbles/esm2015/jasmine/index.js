import { _cases } from "../cases";
import { defaults } from "../configuration";
import { fakeSchedulers as _fakeSchedulers } from "../fake";
import { configure as _configure } from "../marbles";
export * from "../configuration";
export * from "../context";
export * from "../expect";
export * from "../fake";
export * from "./observe";
export function configure(configuration) {
    const { assert: defaultAssert } = defaults();
    const { marbles } = _configure(Object.assign(Object.assign(Object.assign({}, defaults()), { assert: (a, m) => {
            const expectation = expect(a);
            if (expectation.withContext) {
                expect(a).withContext(m).toBeTruthy();
            }
            else {
                defaultAssert(a, m);
            }
        }, assertDeepEqual: (a, e) => expect(a).toEqual(e) }), configuration));
    function cases(name, func, cases) {
        describe(name, () => {
            _cases((c) => {
                const t = c.only ? fit : c.skip ? xit : it;
                if (func.length > 2) {
                    t(c.name, marbles((m, second, ...rest) => func(m, c, second, ...rest)));
                }
                else {
                    t(c.name, marbles((m, ...rest) => func(m, c, ...rest)));
                }
            }, cases);
        });
    }
    return { cases, marbles };
}
const { cases, marbles } = configure({});
export { cases, marbles };
export function fakeSchedulers(fakeTest) {
    return _fakeSchedulers(fakeTest);
}
