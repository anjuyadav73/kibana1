import { Observable } from "rxjs";
export declare function assertArgs<T>(observable: Observable<T>): void;
export declare function assertSubscriptions<T>(observable: Observable<T>): void;
