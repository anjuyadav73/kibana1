"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fakeSchedulers = exports.marbles = exports.cases = exports.configure = void 0;
var cases_1 = require("../cases");
var configuration_1 = require("../configuration");
var fake_1 = require("../fake");
var marbles_1 = require("../marbles");
__exportStar(require("../configuration"), exports);
__exportStar(require("../context"), exports);
__exportStar(require("../expect"), exports);
__exportStar(require("./observe"), exports);
function configure(configuration) {
    var marbles = marbles_1.configure(configuration).marbles;
    function cases(name, func, cases) {
        describe(name, function () {
            cases_1._cases(function (c) {
                var t = c.only ? it.only : c.skip ? it.skip : it;
                if (func.length > 2) {
                    t(c.name, marbles(function (m, second) {
                        var rest = [];
                        for (var _i = 2; _i < arguments.length; _i++) {
                            rest[_i - 2] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c, second], rest));
                    }));
                }
                else {
                    t(c.name, marbles(function (m) {
                        var rest = [];
                        for (var _i = 1; _i < arguments.length; _i++) {
                            rest[_i - 1] = arguments[_i];
                        }
                        return func.apply(void 0, __spreadArray([m, c], rest));
                    }));
                }
            }, cases);
        });
    }
    return { cases: cases, marbles: marbles };
}
exports.configure = configure;
var _a = configure(configuration_1.defaults()), cases = _a.cases, marbles = _a.marbles;
exports.cases = cases;
exports.marbles = marbles;
function fakeSchedulers(fakeTest) {
    return fake_1.fakeSchedulers(fakeTest);
}
exports.fakeSchedulers = fakeSchedulers;
