import iecst from "refractor/lang/iecst.js";;
export default iecst;
