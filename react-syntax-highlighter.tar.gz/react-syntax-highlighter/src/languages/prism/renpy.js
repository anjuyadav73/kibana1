import renpy from "refractor/lang/renpy.js";;
export default renpy;
