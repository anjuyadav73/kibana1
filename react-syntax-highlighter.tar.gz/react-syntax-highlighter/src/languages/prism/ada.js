import ada from "refractor/lang/ada.js";;
export default ada;
