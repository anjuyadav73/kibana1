import fsharp from "refractor/lang/fsharp.js";;
export default fsharp;
