import coffeescript from "refractor/lang/coffeescript.js";;
export default coffeescript;
