import xmlDoc from "refractor/lang/xml-doc.js";;
export default xmlDoc;
