import arduino from "refractor/lang/arduino.js";;
export default arduino;
