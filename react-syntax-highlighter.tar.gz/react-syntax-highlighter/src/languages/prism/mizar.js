import mizar from "refractor/lang/mizar.js";;
export default mizar;
