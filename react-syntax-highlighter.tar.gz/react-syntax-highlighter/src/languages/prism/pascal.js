import pascal from "refractor/lang/pascal.js";;
export default pascal;
