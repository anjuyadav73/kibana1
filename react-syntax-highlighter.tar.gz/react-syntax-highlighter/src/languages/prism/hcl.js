import hcl from "refractor/lang/hcl.js";;
export default hcl;
