import rest from "refractor/lang/rest.js";;
export default rest;
