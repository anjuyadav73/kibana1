import verilog from "refractor/lang/verilog.js";;
export default verilog;
