import concurnas from "refractor/lang/concurnas.js";;
export default concurnas;
