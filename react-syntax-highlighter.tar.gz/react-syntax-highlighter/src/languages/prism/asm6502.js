import asm6502 from "refractor/lang/asm6502.js";;
export default asm6502;
