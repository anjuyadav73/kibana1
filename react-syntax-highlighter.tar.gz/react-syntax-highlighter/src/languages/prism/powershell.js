import powershell from "refractor/lang/powershell.js";;
export default powershell;
