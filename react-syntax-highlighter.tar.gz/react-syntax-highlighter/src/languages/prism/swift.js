import swift from "refractor/lang/swift.js";;
export default swift;
