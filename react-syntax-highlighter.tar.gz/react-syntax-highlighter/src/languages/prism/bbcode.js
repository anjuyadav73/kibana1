import bbcode from "refractor/lang/bbcode.js";;
export default bbcode;
