import typoscript from "refractor/lang/typoscript.js";;
export default typoscript;
