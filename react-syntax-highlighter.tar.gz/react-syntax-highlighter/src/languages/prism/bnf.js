import bnf from "refractor/lang/bnf.js";;
export default bnf;
