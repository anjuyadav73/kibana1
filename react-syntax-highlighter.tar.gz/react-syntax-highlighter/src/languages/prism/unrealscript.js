import unrealscript from "refractor/lang/unrealscript.js";;
export default unrealscript;
