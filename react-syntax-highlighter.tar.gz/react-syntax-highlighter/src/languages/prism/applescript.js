import applescript from "refractor/lang/applescript.js";;
export default applescript;
