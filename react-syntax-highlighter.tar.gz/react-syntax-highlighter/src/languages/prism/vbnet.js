import vbnet from "refractor/lang/vbnet.js";;
export default vbnet;
