import cypher from "refractor/lang/cypher.js";;
export default cypher;
