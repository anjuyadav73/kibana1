import typescript from "refractor/lang/typescript.js";;
export default typescript;
