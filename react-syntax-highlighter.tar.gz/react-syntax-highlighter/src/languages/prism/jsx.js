import jsx from "refractor/lang/jsx.js";;
export default jsx;
