import latte from "refractor/lang/latte.js";;
export default latte;
