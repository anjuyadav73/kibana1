import powerquery from "refractor/lang/powerquery.js";;
export default powerquery;
