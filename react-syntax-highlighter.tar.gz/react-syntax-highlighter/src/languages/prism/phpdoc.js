import phpdoc from "refractor/lang/phpdoc.js";;
export default phpdoc;
