import soy from "refractor/lang/soy.js";;
export default soy;
