import erb from "refractor/lang/erb.js";;
export default erb;
