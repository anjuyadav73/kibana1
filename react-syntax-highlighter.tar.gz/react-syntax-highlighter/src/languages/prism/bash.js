import bash from "refractor/lang/bash.js";;
export default bash;
