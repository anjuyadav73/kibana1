import objectivec from "refractor/lang/objectivec.js";;
export default objectivec;
