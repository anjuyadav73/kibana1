import qore from "refractor/lang/qore.js";;
export default qore;
