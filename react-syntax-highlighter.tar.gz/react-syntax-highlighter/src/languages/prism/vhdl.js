import vhdl from "refractor/lang/vhdl.js";;
export default vhdl;
