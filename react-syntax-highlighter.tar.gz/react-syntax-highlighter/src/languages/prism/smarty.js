import smarty from "refractor/lang/smarty.js";;
export default smarty;
