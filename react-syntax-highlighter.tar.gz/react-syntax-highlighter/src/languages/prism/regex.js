import regex from "refractor/lang/regex.js";;
export default regex;
