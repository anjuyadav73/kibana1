import inform7 from "refractor/lang/inform7.js";;
export default inform7;
