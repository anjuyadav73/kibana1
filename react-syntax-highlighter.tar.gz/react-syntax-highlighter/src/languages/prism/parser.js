import parser from "refractor/lang/parser.js";;
export default parser;
