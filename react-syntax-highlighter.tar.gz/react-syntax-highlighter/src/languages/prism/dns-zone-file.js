import dnsZoneFile from "refractor/lang/dns-zone-file.js";;
export default dnsZoneFile;
