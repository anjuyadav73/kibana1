import javadoclike from "refractor/lang/javadoclike.js";;
export default javadoclike;
