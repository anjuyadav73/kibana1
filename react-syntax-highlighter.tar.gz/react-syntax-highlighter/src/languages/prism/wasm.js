import wasm from "refractor/lang/wasm.js";;
export default wasm;
