import fortran from "refractor/lang/fortran.js";;
export default fortran;
