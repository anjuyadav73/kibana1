import llvm from "refractor/lang/llvm.js";;
export default llvm;
