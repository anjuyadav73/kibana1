import ruby from "refractor/lang/ruby.js";;
export default ruby;
