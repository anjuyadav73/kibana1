import kotlin from "refractor/lang/kotlin.js";;
export default kotlin;
