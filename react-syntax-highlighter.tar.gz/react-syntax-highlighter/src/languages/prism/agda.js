import agda from "refractor/lang/agda.js";;
export default agda;
