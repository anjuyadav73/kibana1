import opencl from "refractor/lang/opencl.js";;
export default opencl;
