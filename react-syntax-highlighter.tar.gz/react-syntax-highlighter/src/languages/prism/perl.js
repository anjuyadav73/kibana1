import perl from "refractor/lang/perl.js";;
export default perl;
