import bsl from "refractor/lang/bsl.js";;
export default bsl;
