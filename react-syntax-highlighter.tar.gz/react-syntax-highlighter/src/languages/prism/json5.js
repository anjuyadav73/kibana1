import json5 from "refractor/lang/json5.js";;
export default json5;
