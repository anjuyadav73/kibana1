import brainfuck from "refractor/lang/brainfuck.js";;
export default brainfuck;
