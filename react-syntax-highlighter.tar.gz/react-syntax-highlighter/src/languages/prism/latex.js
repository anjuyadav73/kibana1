import latex from "refractor/lang/latex.js";;
export default latex;
