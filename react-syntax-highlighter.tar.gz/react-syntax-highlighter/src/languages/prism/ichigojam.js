import ichigojam from "refractor/lang/ichigojam.js";;
export default ichigojam;
