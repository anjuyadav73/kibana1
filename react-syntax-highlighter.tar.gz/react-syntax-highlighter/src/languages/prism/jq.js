import jq from "refractor/lang/jq.js";;
export default jq;
