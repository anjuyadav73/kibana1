import puppet from "refractor/lang/puppet.js";;
export default puppet;
