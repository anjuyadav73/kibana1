import sqf from "refractor/lang/sqf.js";;
export default sqf;
