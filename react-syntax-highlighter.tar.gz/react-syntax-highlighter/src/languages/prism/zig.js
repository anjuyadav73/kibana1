import zig from "refractor/lang/zig.js";;
export default zig;
