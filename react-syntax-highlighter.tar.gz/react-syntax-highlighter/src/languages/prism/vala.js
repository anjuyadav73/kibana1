import vala from "refractor/lang/vala.js";;
export default vala;
