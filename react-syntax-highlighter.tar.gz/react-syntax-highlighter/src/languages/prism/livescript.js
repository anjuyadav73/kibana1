import livescript from "refractor/lang/livescript.js";;
export default livescript;
