import xquery from "refractor/lang/xquery.js";;
export default xquery;
