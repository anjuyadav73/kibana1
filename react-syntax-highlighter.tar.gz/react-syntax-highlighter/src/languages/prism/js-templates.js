import jsTemplates from "refractor/lang/js-templates.js";;
export default jsTemplates;
