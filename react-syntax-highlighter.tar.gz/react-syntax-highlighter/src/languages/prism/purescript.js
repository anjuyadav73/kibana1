import purescript from "refractor/lang/purescript.js";;
export default purescript;
