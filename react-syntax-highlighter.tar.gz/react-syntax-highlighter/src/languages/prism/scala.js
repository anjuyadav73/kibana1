import scala from "refractor/lang/scala.js";;
export default scala;
