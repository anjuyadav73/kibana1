import clike from "refractor/lang/clike.js";;
export default clike;
