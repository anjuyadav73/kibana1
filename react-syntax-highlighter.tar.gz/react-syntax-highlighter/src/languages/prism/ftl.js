import ftl from "refractor/lang/ftl.js";;
export default ftl;
