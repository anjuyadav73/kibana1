import stylus from "refractor/lang/stylus.js";;
export default stylus;
