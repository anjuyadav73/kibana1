import eiffel from "refractor/lang/eiffel.js";;
export default eiffel;
