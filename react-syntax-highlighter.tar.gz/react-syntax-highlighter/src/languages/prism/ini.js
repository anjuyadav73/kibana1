import ini from "refractor/lang/ini.js";;
export default ini;
