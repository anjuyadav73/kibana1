import q from "refractor/lang/q.js";;
export default q;
