import ignore from "refractor/lang/ignore.js";;
export default ignore;
