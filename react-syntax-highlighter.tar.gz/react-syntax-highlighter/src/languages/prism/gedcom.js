import gedcom from "refractor/lang/gedcom.js";;
export default gedcom;
