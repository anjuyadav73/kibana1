import yang from "refractor/lang/yang.js";;
export default yang;
