import actionscript from "refractor/lang/actionscript.js";;
export default actionscript;
