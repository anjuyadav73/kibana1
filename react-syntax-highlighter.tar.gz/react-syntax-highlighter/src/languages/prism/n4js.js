import n4js from "refractor/lang/n4js.js";;
export default n4js;
