import editorconfig from "refractor/lang/editorconfig.js";;
export default editorconfig;
