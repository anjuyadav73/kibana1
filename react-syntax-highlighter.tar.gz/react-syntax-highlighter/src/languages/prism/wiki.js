import wiki from "refractor/lang/wiki.js";;
export default wiki;
