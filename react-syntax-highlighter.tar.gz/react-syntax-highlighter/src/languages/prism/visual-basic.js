import visualBasic from "refractor/lang/visual-basic.js";;
export default visualBasic;
