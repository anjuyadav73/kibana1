import clojureRepl from "highlight.js/lib/languages/clojure-repl";
export default clojureRepl;
