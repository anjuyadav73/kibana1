import juliaRepl from "highlight.js/lib/languages/julia-repl";
export default juliaRepl;
