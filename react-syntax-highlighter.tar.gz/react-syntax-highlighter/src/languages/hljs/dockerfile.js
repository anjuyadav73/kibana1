import dockerfile from "highlight.js/lib/languages/dockerfile";
export default dockerfile;
