import vhdl from "highlight.js/lib/languages/vhdl";
export default vhdl;
