import vbscriptHtml from "highlight.js/lib/languages/vbscript-html";
export default vbscriptHtml;
