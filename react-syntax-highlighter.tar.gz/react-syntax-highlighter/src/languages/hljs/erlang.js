import erlang from "highlight.js/lib/languages/erlang";
export default erlang;
