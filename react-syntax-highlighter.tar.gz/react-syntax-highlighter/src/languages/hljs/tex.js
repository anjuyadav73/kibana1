import tex from "highlight.js/lib/languages/tex";
export default tex;
