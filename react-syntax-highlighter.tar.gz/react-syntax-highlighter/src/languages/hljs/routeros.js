import routeros from "highlight.js/lib/languages/routeros";
export default routeros;
