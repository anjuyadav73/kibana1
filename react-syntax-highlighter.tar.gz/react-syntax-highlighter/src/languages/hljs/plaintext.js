import plaintext from "highlight.js/lib/languages/plaintext";
export default plaintext;
