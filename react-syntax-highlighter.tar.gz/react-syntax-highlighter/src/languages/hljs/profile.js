import profile from "highlight.js/lib/languages/profile";
export default profile;
