import verilog from "highlight.js/lib/languages/verilog";
export default verilog;
