import gams from "highlight.js/lib/languages/gams";
export default gams;
