import scala from "highlight.js/lib/languages/scala";
export default scala;
