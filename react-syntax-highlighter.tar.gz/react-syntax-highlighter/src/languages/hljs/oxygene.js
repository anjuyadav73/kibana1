import oxygene from "highlight.js/lib/languages/oxygene";
export default oxygene;
