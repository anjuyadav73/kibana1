import groovy from "highlight.js/lib/languages/groovy";
export default groovy;
