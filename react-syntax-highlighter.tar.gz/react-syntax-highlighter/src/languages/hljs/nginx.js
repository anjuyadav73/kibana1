import nginx from "highlight.js/lib/languages/nginx";
export default nginx;
