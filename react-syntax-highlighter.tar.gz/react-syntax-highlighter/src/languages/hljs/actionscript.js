import actionscript from "highlight.js/lib/languages/actionscript";
export default actionscript;
