import mercury from "highlight.js/lib/languages/mercury";
export default mercury;
