import stylus from "highlight.js/lib/languages/stylus";
export default stylus;
