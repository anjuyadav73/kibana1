import processing from "highlight.js/lib/languages/processing";
export default processing;
