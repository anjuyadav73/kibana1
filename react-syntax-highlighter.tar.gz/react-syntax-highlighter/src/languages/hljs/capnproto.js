import capnproto from "highlight.js/lib/languages/capnproto";
export default capnproto;
