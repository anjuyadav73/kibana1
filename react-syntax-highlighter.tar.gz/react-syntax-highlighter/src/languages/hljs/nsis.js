import nsis from "highlight.js/lib/languages/nsis";
export default nsis;
