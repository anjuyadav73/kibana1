import cos from "highlight.js/lib/languages/cos";
export default cos;
