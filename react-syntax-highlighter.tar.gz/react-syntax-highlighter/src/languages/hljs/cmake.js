import cmake from "highlight.js/lib/languages/cmake";
export default cmake;
