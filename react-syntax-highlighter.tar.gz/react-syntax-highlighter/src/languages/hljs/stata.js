import stata from "highlight.js/lib/languages/stata";
export default stata;
