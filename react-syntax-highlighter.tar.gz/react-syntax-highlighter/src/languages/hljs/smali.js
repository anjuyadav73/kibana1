import smali from "highlight.js/lib/languages/smali";
export default smali;
