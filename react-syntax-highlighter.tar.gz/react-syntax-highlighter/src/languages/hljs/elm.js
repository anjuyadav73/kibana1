import elm from "highlight.js/lib/languages/elm";
export default elm;
