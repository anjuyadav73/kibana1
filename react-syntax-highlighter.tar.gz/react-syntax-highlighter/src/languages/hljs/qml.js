import qml from "highlight.js/lib/languages/qml";
export default qml;
