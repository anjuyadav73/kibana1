import abnf from "highlight.js/lib/languages/abnf";
export default abnf;
