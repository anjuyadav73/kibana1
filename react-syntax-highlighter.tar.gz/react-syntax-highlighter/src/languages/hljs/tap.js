import tap from "highlight.js/lib/languages/tap";
export default tap;
