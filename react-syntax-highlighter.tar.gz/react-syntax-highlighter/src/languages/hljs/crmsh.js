import crmsh from "highlight.js/lib/languages/crmsh";
export default crmsh;
