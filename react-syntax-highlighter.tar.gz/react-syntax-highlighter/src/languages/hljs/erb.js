import erb from "highlight.js/lib/languages/erb";
export default erb;
