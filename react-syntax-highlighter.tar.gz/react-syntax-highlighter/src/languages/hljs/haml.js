import haml from "highlight.js/lib/languages/haml";
export default haml;
