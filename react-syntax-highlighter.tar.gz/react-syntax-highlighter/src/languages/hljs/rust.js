import rust from "highlight.js/lib/languages/rust";
export default rust;
