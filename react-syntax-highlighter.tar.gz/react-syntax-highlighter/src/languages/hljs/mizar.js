import mizar from "highlight.js/lib/languages/mizar";
export default mizar;
