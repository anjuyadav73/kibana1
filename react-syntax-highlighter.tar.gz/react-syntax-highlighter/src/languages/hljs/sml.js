import sml from "highlight.js/lib/languages/sml";
export default sml;
