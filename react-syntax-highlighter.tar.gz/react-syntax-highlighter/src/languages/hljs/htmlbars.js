import htmlbars from "highlight.js/lib/languages/htmlbars";
export default htmlbars;
