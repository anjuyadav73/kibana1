import coffeescript from "highlight.js/lib/languages/coffeescript";
export default coffeescript;
