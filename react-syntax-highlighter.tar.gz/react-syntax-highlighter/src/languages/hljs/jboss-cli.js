import jbossCli from "highlight.js/lib/languages/jboss-cli";
export default jbossCli;
