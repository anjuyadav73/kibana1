import lsl from "highlight.js/lib/languages/lsl";
export default lsl;
