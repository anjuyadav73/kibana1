import makefile from "highlight.js/lib/languages/makefile";
export default makefile;
