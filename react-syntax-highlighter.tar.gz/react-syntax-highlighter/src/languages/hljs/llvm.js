import llvm from "highlight.js/lib/languages/llvm";
export default llvm;
