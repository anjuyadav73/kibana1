import pony from "highlight.js/lib/languages/pony";
export default pony;
