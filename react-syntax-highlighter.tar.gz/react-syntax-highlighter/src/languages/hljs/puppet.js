import puppet from "highlight.js/lib/languages/puppet";
export default puppet;
