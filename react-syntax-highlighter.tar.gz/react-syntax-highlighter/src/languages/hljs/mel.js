import mel from "highlight.js/lib/languages/mel";
export default mel;
