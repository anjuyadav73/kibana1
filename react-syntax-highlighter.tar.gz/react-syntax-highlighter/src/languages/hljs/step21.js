import step21 from "highlight.js/lib/languages/step21";
export default step21;
