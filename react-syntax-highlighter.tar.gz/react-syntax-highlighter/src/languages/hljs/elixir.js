import elixir from "highlight.js/lib/languages/elixir";
export default elixir;
