import dos from "highlight.js/lib/languages/dos";
export default dos;
