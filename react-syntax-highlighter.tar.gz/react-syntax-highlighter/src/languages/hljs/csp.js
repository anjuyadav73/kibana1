import csp from "highlight.js/lib/languages/csp";
export default csp;
