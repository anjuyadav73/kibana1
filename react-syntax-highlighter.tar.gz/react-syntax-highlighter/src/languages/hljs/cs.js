import cs from "highlight.js/lib/languages/cs";
export default cs;
