import autohotkey from "highlight.js/lib/languages/autohotkey";
export default autohotkey;
