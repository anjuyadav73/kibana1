import cal from "highlight.js/lib/languages/cal";
export default cal;
