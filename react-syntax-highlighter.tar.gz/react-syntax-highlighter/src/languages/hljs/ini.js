import ini from "highlight.js/lib/languages/ini";
export default ini;
