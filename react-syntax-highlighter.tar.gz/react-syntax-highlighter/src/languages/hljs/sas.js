import sas from "highlight.js/lib/languages/sas";
export default sas;
