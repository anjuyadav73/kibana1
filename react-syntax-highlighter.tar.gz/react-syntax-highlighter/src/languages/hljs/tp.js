import tp from "highlight.js/lib/languages/tp";
export default tp;
