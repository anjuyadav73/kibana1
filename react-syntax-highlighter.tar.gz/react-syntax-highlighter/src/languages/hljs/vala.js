import vala from "highlight.js/lib/languages/vala";
export default vala;
