import rib from "highlight.js/lib/languages/rib";
export default rib;
