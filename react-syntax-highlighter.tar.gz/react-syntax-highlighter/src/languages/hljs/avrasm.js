import avrasm from "highlight.js/lib/languages/avrasm";
export default avrasm;
