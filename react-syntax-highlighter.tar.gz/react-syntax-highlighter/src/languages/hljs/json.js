import json from "highlight.js/lib/languages/json";
export default json;
