declare module 'vega' {
  export * from 'vega-typings';
}
